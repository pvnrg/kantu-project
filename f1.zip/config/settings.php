<?php

return [

    'DEFAULT_LANG' => env('DEFAULT_LANG', 'en'),
    'PER_PAGE_DATA' => 10,
	'date_format' => 'jS M Y g:i A',
	'date_format_mdy' => 'M jS Y',

	'api_parms'=>[
        'connectionuser'=>["id","batch_id","name","email","gender","dob","country_code","phone","city","state","profile_pic","profile_pic_thumb","address"],
        'remove_extra_user_param' => ['profileimg', 'updated_at', 'deleted_at', 'regi_reference', 'parent_id', 'firebase_token', 'device_type', 'device_token', 'otp', 'image','age'],
	],

];
