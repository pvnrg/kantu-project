-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2020 at 12:24 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `safety`
--

-- --------------------------------------------------------

--
-- Table structure for table `badge_approves`
--
-- Error reading structure for table safety.badge_approves: #1932 - Table 'safety.badge_approves' doesn't exist in engine
-- Error reading data for table safety.badge_approves: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`badge_approves`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `billings`
--
-- Error reading structure for table safety.billings: #1932 - Table 'safety.billings' doesn't exist in engine
-- Error reading data for table safety.billings: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`billings`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--
-- Error reading structure for table safety.blogs: #1932 - Table 'safety.blogs' doesn't exist in engine
-- Error reading data for table safety.blogs: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`blogs`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--
-- Error reading structure for table safety.cards: #1932 - Table 'safety.cards' doesn't exist in engine
-- Error reading data for table safety.cards: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`cards`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `connections`
--
-- Error reading structure for table safety.connections: #1932 - Table 'safety.connections' doesn't exist in engine
-- Error reading data for table safety.connections: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`connections`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--
-- Error reading structure for table safety.contact_us: #1932 - Table 'safety.contact_us' doesn't exist in engine
-- Error reading data for table safety.contact_us: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`contact_us`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--
-- Error reading structure for table safety.employees: #1932 - Table 'safety.employees' doesn't exist in engine
-- Error reading data for table safety.employees: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`employees`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `events`
--
-- Error reading structure for table safety.events: #1932 - Table 'safety.events' doesn't exist in engine
-- Error reading data for table safety.events: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`events`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `events_users`
--
-- Error reading structure for table safety.events_users: #1932 - Table 'safety.events_users' doesn't exist in engine
-- Error reading data for table safety.events_users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`events_users`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `event_images`
--
-- Error reading structure for table safety.event_images: #1932 - Table 'safety.event_images' doesn't exist in engine
-- Error reading data for table safety.event_images: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`event_images`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--
-- Error reading structure for table safety.faqs: #1932 - Table 'safety.faqs' doesn't exist in engine
-- Error reading data for table safety.faqs: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`faqs`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `images`
--
-- Error reading structure for table safety.images: #1932 - Table 'safety.images' doesn't exist in engine
-- Error reading data for table safety.images: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`images`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--
-- Error reading structure for table safety.jobs: #1932 - Table 'safety.jobs' doesn't exist in engine
-- Error reading data for table safety.jobs: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`jobs`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--
-- Error reading structure for table safety.languages: #1932 - Table 'safety.languages' doesn't exist in engine
-- Error reading data for table safety.languages: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`languages`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--
-- Error reading structure for table safety.logs: #1932 - Table 'safety.logs' doesn't exist in engine
-- Error reading data for table safety.logs: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`logs`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--
-- Error reading structure for table safety.migrations: #1932 - Table 'safety.migrations' doesn't exist in engine
-- Error reading data for table safety.migrations: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`migrations`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--
-- Error reading structure for table safety.notifications: #1932 - Table 'safety.notifications' doesn't exist in engine
-- Error reading data for table safety.notifications: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`notifications`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--
-- Error reading structure for table safety.orders: #1932 - Table 'safety.orders' doesn't exist in engine
-- Error reading data for table safety.orders: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`orders`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--
-- Error reading structure for table safety.password_resets: #1932 - Table 'safety.password_resets' doesn't exist in engine
-- Error reading data for table safety.password_resets: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`password_resets`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--
-- Error reading structure for table safety.permissions: #1932 - Table 'safety.permissions' doesn't exist in engine
-- Error reading data for table safety.permissions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`permissions`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--
-- Error reading structure for table safety.plans: #1932 - Table 'safety.plans' doesn't exist in engine
-- Error reading data for table safety.plans: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`plans`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `refe_file`
--
-- Error reading structure for table safety.refe_file: #1932 - Table 'safety.refe_file' doesn't exist in engine
-- Error reading data for table safety.refe_file: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`refe_file`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `response_texts`
--
-- Error reading structure for table safety.response_texts: #1932 - Table 'safety.response_texts' doesn't exist in engine
-- Error reading data for table safety.response_texts: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`response_texts`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `rolls`
--
-- Error reading structure for table safety.rolls: #1932 - Table 'safety.rolls' doesn't exist in engine
-- Error reading data for table safety.rolls: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`rolls`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `roll_permissions`
--
-- Error reading structure for table safety.roll_permissions: #1932 - Table 'safety.roll_permissions' doesn't exist in engine
-- Error reading data for table safety.roll_permissions: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`roll_permissions`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `seo_contents`
--
-- Error reading structure for table safety.seo_contents: #1932 - Table 'safety.seo_contents' doesn't exist in engine
-- Error reading data for table safety.seo_contents: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`seo_contents`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--
-- Error reading structure for table safety.settings: #1932 - Table 'safety.settings' doesn't exist in engine
-- Error reading data for table safety.settings: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`settings`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `state_users`
--
-- Error reading structure for table safety.state_users: #1932 - Table 'safety.state_users' doesn't exist in engine
-- Error reading data for table safety.state_users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`state_users`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `transaction_logs`
--
-- Error reading structure for table safety.transaction_logs: #1932 - Table 'safety.transaction_logs' doesn't exist in engine
-- Error reading data for table safety.transaction_logs: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`transaction_logs`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Error reading structure for table safety.users: #1932 - Table 'safety.users' doesn't exist in engine
-- Error reading data for table safety.users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`users`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `user_rolls`
--
-- Error reading structure for table safety.user_rolls: #1932 - Table 'safety.user_rolls' doesn't exist in engine
-- Error reading data for table safety.user_rolls: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`user_rolls`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `verify_users`
--
-- Error reading structure for table safety.verify_users: #1932 - Table 'safety.verify_users' doesn't exist in engine
-- Error reading data for table safety.verify_users: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `safety`.`verify_users`' at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
