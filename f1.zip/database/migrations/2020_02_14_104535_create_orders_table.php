<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('user_id')->nullable()->default(0);
            $table->integer('plan_id')->nullable()->default(0);
            $table->date('start_date')->nullable();
            $table->date('expiry_date')->nullable();
            $table->text('auth_response')->nullable();
            $table->string('order_no')->nullable()->default(0);
            $table->float('one_time_fee')->nullable()->default(0.0);
            $table->string('one_time_charge_id', 100)->nullable();
            $table->longText('one_time_charge_ob')->nullable();
            $table->longText('plan_ob')->nullable();
            $table->double('amount', 16, 2)->nullable()->default(0.0);
            $table->string('trans_status')->nullable();
            $table->string('next_pay')->nullable();
			$table->string('transaction_id')->nullable();
			$table->string('subscription_id')->nullable();
			$table->longText('unsubscription_ob')->nullable();
            $table->string('order_comment', 100)->nullable();
            $table->string('token', 100)->nullable();
            $table->tinyInteger('status')->default(0);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
