<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBlogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('blogs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('image', 100)->nullable();
            $table->string('title')->nullable();
            $table->string('meta_keywords')->nullable();
            $table->string('slug', 100)->nullable();
            $table->longText('detail')->nullable();
            $table->string('short_desc')->nullable();
            $table->enum('type', ['page', 'blog'])->nullable()->default('blog');
            $table->date('post_date')->nullable();
            $table->tinyInteger('status')->default(0);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('blogs');
    }
}
