<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEventsUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('events_users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('events_id')->foreign('events_id')->references('id')->on('events');
			$table->integer('request_by')->nullable()->default(0);
			$table->integer('users_id')->foreign('users_id')->references('id')->on('users');
			$table->integer('safe_id')->nullable()->default(0);
			$table->integer('unsafe_id')->nullable()->default(0);
			
			$table->enum('user_role', ['creator', 'user','other'])->nullable()->default('creator');
			$table->enum('approval_status', ['request', 'accept','decline','joined','left','complete'])->nullable()->default('request');
			
			
			$table->text('approval_note')->nullable();
			$table->text('user_review_detail')->nullable();
			$table->integer('user_review')->nullable()->default(0);
			
			
            $table->timestamps();
			$table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('events_users');
    }
}
