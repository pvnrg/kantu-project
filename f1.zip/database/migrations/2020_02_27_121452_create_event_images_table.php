<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEventImagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('event_images', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('event_id')->nullable()->default(0);
            $table->integer('user_id')->nullable()->default(0);
            $table->integer('safe_image_id')->nullable()->default(0);
            $table->integer('unsafe_image_id')->nullable()->default(0);
            $table->string('status')->nullable();
            $table->integer('choosen_image_id')->nullable()->default(0);
            $table->date('choosen_image_on')->nullable()->default(null);
            $table->string('user_status')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('event_images');
    }
}
