<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBillingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('billings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('plan_id')->unsigned()->nullable()->default(0);
            $table->integer('order_id')->unsigned()->nullable()->default(0);
            $table->integer('user_id')->unsigned()->nullable()->default(0);
            $table->string('invoice_id')->nullable();
            $table->string('charge_id')->nullable();
            $table->double('amount_paid', 16, 2)->nullable()->default(0.0);
            $table->float('discount')->nullable()->default(0);
            $table->enum('price_currency', ['USD'])->nullable()->default('USD');
            $table->enum('billing_type', ['paypal', 'stripe', 'trial'])->nullable()->default('stripe');
            $table->longText('billing_ob')->nullable();
            $table->longText('package_ob')->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('billings');
    }
}
