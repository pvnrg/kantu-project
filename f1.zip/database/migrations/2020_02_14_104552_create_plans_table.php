<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('plans', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('title')->nullable();
            $table->text('description')->nullable();
            $table->text('features')->nullable();
            $table->enum('type', ['free', 'yearly', 'monthly', 'daily', 'weekly', 'special_yearly', 'special_lifetime'])->nullable();
            $table->float('actual_amount')->nullable()->default(0.0);
            $table->float('show_amount')->nullable()->default(0.0);
            $table->string('stripe_product_id', 100)->nullable();
            $table->string('plan_uid', 100)->nullable();
            $table->string('currency', 100)->nullable();
            $table->tinyInteger('status')->default(0);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('plans');
    }
}
