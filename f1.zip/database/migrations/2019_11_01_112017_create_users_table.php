<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('batch_id')->nullable();
            $table->string('name')->nullable();
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('gender')->nullable();
            $table->date('dob')->nullable();
            $table->string('country_code', 10)->nullable()->default('+1');
            $table->string('phone', 100)->nullable();
            $table->string('city',100)->nullable();
            $table->string('state', 100)->nullable();
            $table->enum('badge_status', ['approved', 'in-progress','disapproved'])->nullable()->default('in-progress');
            $table->string('stripe_id', 100)->nullable();
            $table->enum('stripe_account_type', ['live', 'staging', 'local'])->nullable()->default('local');
            $table->string('otp', 20)->nullable();
            $table->string('device_type')->nullable();
            $table->string('device_token')->nullable();
            $table->string('firebase_token')->nullable();
            $table->string('remember_token')->nullable();
            $table->enum('status', ['active', 'inactive'])->nullable()->default('active');
            $table->tinyInteger('phone_verified')->default(0);
            $table->integer('badge_approved_by')->default(0);
            $table->enum('regi_reference', ['site', 'special_link'])->default('site');
			$table->longText('address')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
