<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;

class Blog extends BaseModel
{
    //
    use SoftDeletes;
    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    // public $timestamps = false;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'blogs';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $fillable = ['image', 'title', 'detail', 'short_desc', 'type', 'status', 'slug', 'post_date'];

    protected $appends = ['created','previous_slug','next_slug', 'image_url', 'thumb_image_url'];

    public function blog_img()
    {
        return $this->hasOne('App\Refefile', 'refe_field_id', 'id')
		->where('refe_table_name', $this->getTable())
		->where('file_type', "blog_single_image")
		->orderby("priority","DESC")
		->orderby("created_at","DESC");
    }

    public function getImageUrlAttribute()
    {
		if($this->blog_img && $this->blog_img->file_url){
			return $this->blog_img->file_url;
		}else{
			return asset('/app-assets/img/profile_pic_type.png');
		}
    }

    public function getThumbImageUrlAttribute()
    {
		if($this->blog_img && $this->blog_img->file_thumb_url){
			return $this->blog_img->file_thumb_url;
		}else{
			return asset('/app-assets/img/profile_pic_type.png');
		}
    }

    public function getPostDateAttribute($value)
    {
        if($value != ""){
            return \Carbon\Carbon::parse($value)->format(session('setting.date_format','M j, Y'));
        }
        return $value;
    }

    public function setPostDateAttribute($value)
    {
        if($value != ""){
            if(date('Y', strtotime($value))  == 1970){
                $dates = explode('-',$value);
                return $this->attributes['post_date'] = $dates[2].'-'.$dates[0].'-'.$dates[1];
            }else{
                return $this->attributes['post_date'] = \Carbon\Carbon::parse($value)->format('Y-m-d');
            }
        }
    }
    public function getCreatedAttribute()
    {
        if($this->created_at != ""){
            return \Carbon\Carbon::parse($this->created_at)->format('M j, Y');
        }
        return $this->created_at;
    }
    public function getPreviousSlugAttribute()
    {
        $previous_slug="";
        if($this->id != ""){
            $blog_previous_id = Blog::where('id', '<', $this->id)->where('type','=',$this->type)->where('status','=',1)->max('id');
            if($blog_previous_id != null)
            {
                $previous_slug=Blog::find($blog_previous_id);
                return $previous_slug->slug;
            }
            else
            {
                return $previous_slug;
            }

        }
        return $this->id;
    }
    public function getNextSlugAttribute()
    {
        $next_slug="";
        if($this->id != ""){
            $blog_next_id = Blog::where('id', '>', $this->id)->where('type','=',$this->type)->where('status','=',1)->min('id');
            if($blog_next_id != null)
            {
                $next_slug=Blog::find($blog_next_id);
                return $next_slug->slug;
            }
            else
            {
                return $next_slug;
            }

        }
        return $this->id;
    }
}
