<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\BaseModel;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Carbon\Carbon;
use DB;

class User extends Authenticatable implements JWTSubject
{
    use Notifiable; use HasRoles; use SoftDeletes ;


    const BADGE_APPROVE = 'approved';
    const BADGE_DISAPPROVE = 'disapproved';
    const BADGE_PROGRESS = 'in-progress';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'users' ;
    protected $fillable = [
        'batch_id', 'name', 'first_name', 'last_name', 'email', 'email_verified_at', 'password', 'gender', 'dob', 'country_code', 'username', 'pan_number', 'phone', 'city', 'state', 'badge_status', 'stripe_id', 'stripe_account_type', 'otp', 'device_type', 'device_token', 'firebase_token', 'status', 'phone_verified', 'badge_approved_by', 'regi_reference','address'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    protected $appends = ['name','profile_pic','profile_pic_thumb', 'my_total_orders'];


    public function rolls()
    {
        return $this->hasMany('App\Userrolls', 'user_id', 'id');
    }
	public function profileimg()
    {
        return $this->hasOne('App\Refefile', 'refe_field_id', 'id')
		->where('refe_table_name', $this->getTable())
		->where('file_type', "profile_pic_type")
		->orderby("priority","DESC")
		->orderby("created_at","DESC");
    }
	// public function documents()
    // {
    //     return $this->hasMany('App\Refefile', 'refe_field_id', 'id')
	// 	->where('refe_table_name', $this->getTable())
	// 	->where('file_type', "document_type")
	// 	->orderby("priority","DESC")
	// 	->orderby("created_at","DESC");
    // }

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function getAgeAttribute()
    {
        if($this->dob != "")
        {
            $date = Carbon::createFromFormat('Y-m-d',$this->dob);
            return Carbon::parse($date)->age;
        }
        return $this->dob;
    }

    public function getProfilePicThumbAttribute()
    {
		if($this->profileimg && $this->profileimg->file_thumb_url){
			return $this->profileimg->file_thumb_url;
		}else{
			return asset('/app-assets/img/profile_pic_type.png');
		}
    }

	public function getProfilePicAttribute()
    {
		if($this->profileimg && $this->profileimg->file_url){
			return $this->profileimg->file_url;
		}else{
			return asset('/app-assets/img/profile_pic_type.png');
		}
	}


	public function getNameAttribute()
    {
		return $this->first_name." ".$this->last_name;
	}


    public function getBatchIdAttribute()
    {
        if($this->status == "active" && $this->badge_status == "approved")
        {
			return $this->attributes['batch_id'];
        }
		return "N/A";
    }

	public function orders()
    {
        return $this->hasMany('App\Orders', 'user_id', 'id');
	}
	public function refefile()
    {
        return $this->hasMany('App\Refefile', 'refe_field_id', 'id')->where('refe_table_name', 'users');
    }
	public function cards()
    {
        return $this->hasMany('App\Cards','stripe_id', 'stripe_id');
    }
	public function verifyUser()
    {
        return $this->hasMany('App\VerifyUser');
    }

	public function employee()
    {
        return $this->hasOne('App\Employee');
    }
	public function approver()
    {
        return $this->belongsTo('App\User', 'badge_approve_by');
    }

    // public function events()
    // {
    //     return $this->hasMany('App\Events','created_by', 'id');
    // }

    // public function invite_events()
    // {
    //     return $this->belongsToMany('App\Events',  'events_users', 'users_id');
    // }

    // public function connect_from() {
    //     return $this->hasMany('App\Connection', 'from_id')->where('status',Connection::STATUS_CONNECTED);
    // }

    // public function connect_to() {
    //     return $this->hasMany('App\Connection', 'to_id')->where('status',Connection::STATUS_CONNECTED);
    // }

    public function notifications()
    {
        return $this->hasMany('App\Notification', 'receiver_id');
    }

    // public function getMyTotalEventsAttribute(){
    //     return $this->events()->count() +  $this->invite_events()->where('approval_status','accept')->get()->count() ;
    // }

    // public function getMyTotalConnectionsAttribute(){
    //     return $this->connect_from()->count() +  $this->connect_to()->count() ;
    // }

    public function getMyTotalOrdersAttribute(){
        return $this->orders()->count() ;
    }

}
