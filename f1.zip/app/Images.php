<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;

class Images extends BaseModel
{
    //

    use SoftDeletes;

	  protected $table = 'images';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $fillable = [ ''];

    protected $appends = ['image_url', 'thumb_image_url'];

    const TYPE_SAFE = 'safe';
    const TYPE_UNSAFE = 'unsafe';

    public function safety_img()
    {
        return $this->hasOne('App\Refefile', 'refe_field_id', 'id')
		->where('refe_table_name', $this->getTable())
		->where('file_type', "images_single_image")
		->orderby("priority","DESC")
		->orderby("created_at","DESC");
    }

    public function getImageUrlAttribute()
    {
		if($this->safety_img && $this->safety_img->file_url){
			return $this->safety_img->file_url;
		}else{
			return asset('/app-assets/img/profile_pic_type.png');
		}
    }

    public function getThumbImageUrlAttribute()
    {
		if($this->safety_img && $this->safety_img->file_thumb_url){
			return $this->safety_img->file_thumb_url;
		}else{
			return asset('/app-assets/img/profile_pic_type.png');
		}
    }


}
