<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Employee extends Model
{
    //
    use SoftDeletes;

	protected $table = 'employees';


    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $fillable = ['user_id', 'email', 'token', 'try_count', 'is_setup', 'approved_count', 'approve_count_total'];

    protected $appends = ['user_name'] ;

	public function user()
    {
        return $this->belongsTo('App\User', 'user_id');
    }
	public function approvedlist()
    {
        return $this->hasMany('App\Badgeapprove', 'badge_approve_by','user_id');
    }

    public function getUserNameAttribute()
    {
        return ($this->user) ? $this->user->name : "" ;
    }

}
