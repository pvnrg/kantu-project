<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;

class Logs extends BaseModel
{
    //
    use SoftDeletes;

    protected $table = 'logs';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $fillable = ['log_type', 'status_code', 'total_count', 'created_at', 'slug'];

}
