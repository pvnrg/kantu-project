<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;

class ResponseText extends Model
{
	use SoftDeletes;
    
    protected $table = 'response_texts';

    protected $primaryKey = 'id';

	protected $guarded = ['id'];

	protected $fillable = ['response_type', 'slug', 'desc'];


	public static function rtext($slug){

		$rtext=Responsetext::whereSlug($slug)->first();
		if($rtext){
			$value =  $rtext->desc;
		}else{
			 $value = "";
			$lang = \Lang::get('api.responce_msg');
			if(isset($lang[$slug])){
				 $value =  \Lang::get('api.responce_msg.'.$slug);
			}
            if(!$value){
                $value = str_replace( '_', ' ', ucfirst($slug) );
            }
		}
        return $value ;
	}
}
