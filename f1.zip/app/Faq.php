<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\BaseModel;

class Faq extends BaseModel
{
    //
    use SoftDeletes;
    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    // public $timestamps = false;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'faqs';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $fillable = ['question', 'answer', 'status'];
}
