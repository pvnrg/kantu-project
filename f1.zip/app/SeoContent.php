<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\BaseModel;

class SeoContent extends BaseModel
{
    //
    protected $table = 'seo_contents';


    protected $primaryKey = 'id';

	protected $guarded = ['id'];
	
	protected $fillable = ['page_name', 'title', 'keywords', 'description'];

	function getTitleAttribute(){
		$def=Seocontent::where("page_name","default")->first();
		if((!$this->attributes['title'] || $this->attributes['title'] == "") && $def){
			return $def->title;
		}else{
			return $this->attributes['title'];
		}

    }

	function getKeywordsAttribute(){
		$def=Seocontent::where("page_name","default")->first();
		if((!$this->attributes['keywords'] || $this->attributes['keywords'] == "") && $def){
			return $def->keywords;
		}else{
			return $this->attributes['keywords'];
		}

    }

	function getDescriptionAttribute(){
		$def=Seocontent::where("page_name","default")->first();
		if((!$this->attributes['description'] || $this->attributes['description'] == "") && $def){
			return $def->description;
		}else{
			return $this->attributes['description'];
		}

    }
}
