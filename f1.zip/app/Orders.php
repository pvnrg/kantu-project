<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;

class Orders extends BaseModel
{
    //
    use SoftDeletes;
    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    // public $timestamps = false;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'orders';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];


	protected $appends = ['order_created','start_date_formated','expiry_date_formated','expiry_no_date','user_name'];

    public function getOrderCreatedAttribute()
    {
        if($this->created_at != ""){
            return \Carbon\Carbon::parse($this->created_at)->format(session('setting.date_format',\config('admin.setting.date_format_on_app')));
        }
		return $this->created_at;
    }
	public function getStartDateFormatedAttribute()
    {
        if($this->start_date != "" && $this->start_date){
            return \Carbon\Carbon::parse($this->start_date)->format(session('setting.date_format',\config('admin.setting.date_format_on_app')));
        }
        return $this->start_date;
    }
	public function getExpiryNoDateAttribute($value)
    {
        if(!$value || $value == ""){
            return "Lifetime";
        }
        return $value;
    }
	public function getExpiryDateFormatedAttribute()
    {
        if($this->expiry_date != "" && $this->expiry_date){
            return \Carbon\Carbon::parse($this->expiry_date)->format(session('setting.date_format',\config('admin.setting.date_format_on_app')));
        }
        return "Lifetime";
    }
	public function plan()
    {
        return $this->hasOne('App\Plan', 'id', 'plan_id');
    }
	public function cplan()
    {
		$res = [];
        if($this->plan_ob && $this->plan_ob != ""){
			$res = json_decode($this->plan_ob);
		}
		if(isset($res->id)){
			return $res;
		}else{
			return $this->plan;
		}

    }
	public function billing()
    {
        return $this->hasMany('App\Billing', 'order_id', 'id');
    }

	public function user()
    {
        return $this->hasOne('App\User', 'id', 'user_id');
    }

	public static function getNextOrderNumber()
    {
        // Get the last created order
        $lastOrder =Orders::orderBy('created_at', 'desc')->first();

        if ($lastOrder != null)
            $number = $lastOrder->id;
        else
            $number =0;

        return 'PO' . sprintf('%05d', intval($number) + 1);
    }

    public function getUserNameAttribute()
    {
        return ($this->user) ? $this->user->name : "" ;
    }


}
