<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EventsImages extends Model
{
    //
    protected $table = 'event_images';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $appends = ['user_name'] ;


    public function getUserNameAttribute()
    {
        return ($this->user) ? $this->user->name : "" ;
    }

    public function event()
    {
        return $this->belongsTo('App\Events', 'event_id');
    }

    public function user()
    {
        return $this->belongsTo('App\User', 'user_id');
    }

    public function safe_image()
    {
        return $this->belongsTo('App\Images', 'safe_image_id');
    }

    public function unsafe_image()
    {
        return $this->belongsTo('App\Images', 'unsafe_image_id');
    }

    public function choosen_image()
    {
        return $this->belongsTo('App\Images', 'choosen_image_id');
    }




}
