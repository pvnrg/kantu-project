<?php

namespace App;
use App\BaseModel;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Carbon\Carbon ;

class Events extends BaseModel
{
    //
    use SoftDeletes;

	protected $table = 'events';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $appends = ['created_by_name', 'location'] ;

    const STATUS_NEW = 'new';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';
    const STATUS_INPROGRESS = 'in-progress' ;
    const STATUS_AWAITING = 'awaiting' ;
    const STATUS_SCHEDULED = 'scheduled' ;

    public function getCreatedByNameAttribute()
    {
        return ($this->user) ? $this->user->name : "" ;
    }

    public function user()
    {
        return $this->hasOne('App\User', 'id', 'created_by');
    }

    public function events_users()
    {
        return $this->hasOne('App\EventsUsers','events_id', 'id');
    }

    public function events_images()
    {
        return $this->hasMany('App\EventsImages','event_id', 'id');
    }

    public function getLocationAttribute(){
        $add = $this->address ;
        if($this->city != ''){
            $add =  $add.", ".$this->city ;
        }
        if($this->state != ''){
            $add =  $add.", ".$this->state ;
        }
        return $add ;
    }

    public function getEventTimeAttribute(){
        $time= '';
        if( $this->start_time != '' && $this->end_time != ""){
            $time= Carbon::parse($this->start_time)->format('H:i A') ." - ".Carbon::parse($this->end_time)->format('H:i A') ;
        }
        return $time ;
    }

    public function getEventDateAttribute(){
        $date= '';
        if( $this->start_date != '' && $this->end_date != ""){
            $date = Carbon::parse($this->start_date)->format('d M Y') ." - ".Carbon::parse($this->end_date)->format('d M Y') ;
        }
        return $date ;
    }

    public function event_status($uid){
        $event_status = '';
        if($this->status == Events::STATUS_NEW ){
            if($this->events_users){
                if( $this->events_users->approval_status  == EventsUsers::STATUS_REQUEST ){
                    if( $this->created_by == $uid || $uid == 1){
                        $event_status = Events::STATUS_AWAITING ;
                    }else{
                        $event_status = EventsUsers::STATUS_REQUEST ;
                    }
                }elseif($this->events_users->approval_status  == EventsUsers::STATUS_ACCEPT  ){
                    $event_status = Events::STATUS_SCHEDULED ;
                }elseif($this->events_users->approval_status  == EventsUsers::STATUS_DECLINE ){
                    $event_status = Events::STATUS_CANCELLED ;
                }
            }else{
                $event_status = Events::STATUS_AWAITING ;
            }
        }else{
            $event_status =  Events::STATUS_COMPLETED ;
        }
        return  $event_status ;
    }

}
