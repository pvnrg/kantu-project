<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EventsUsers extends Model
{
    //
    protected $table = 'events_users';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $appends = ['user_name'] ;

    const STATUS_REQUEST = 'request';
    const STATUS_ACCEPT = 'accept';
    const STATUS_DECLINE = 'decline';
    const STATUS_JOINED = 'joined' ;
    const STATUS_LEFT = 'left';
    const STATUS_COMPLETE = 'complete';

    public function getUserNameAttribute()
    {
        return ($this->connected_user) ? $this->connected_user->first_name : "" ;
    }

    public function event()
    {
        return $this->belongsTo('App\Events', 'events_id');
    }

    public function user()
    {
        return $this->belongsTo('App\User', 'request_by');
    }

    public function connected_user()
    {
        return $this->belongsTo('App\User', 'users_id');
    }

}
