<?php

namespace App\Libraries\Fields;
use App\Libraries\Fields\Fields;

class Text extends Fields  
{
    protected $type;
    protected $name;
    protected $attributes;

    public function construct() {
        parent::__construct();
    }

    
    public static function rander(){
          
        
         
    }


}

?> 