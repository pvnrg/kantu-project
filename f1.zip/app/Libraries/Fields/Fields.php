<?php

namespace App\Libraries\Fields;

class Fields  
{
    protected $type;
    protected $name;
    protected $attributes;

    public function construct() {
        
    }

    public static function rander(){
        return false;
    }
}

?> 