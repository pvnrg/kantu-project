<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Notification extends Model
{
    //
    use SoftDeletes;

    const CONN_REQUEST_RECEIVED = 'connection_request_received' ;
    const CONN_REQUEST_ACTION = 'connection_request_action' ;
    const EVENT_INVITE_RECEIVED = 'event_invite_received';
    const EVENT_INVITE_ACTION = 'event_invite_action';

    protected $table = 'notifications';

	protected $primaryKey = 'id';

    protected $fillable = ['sender_id','receiver_id', 'data' ,'message','type','read_flag'];

    public function sender()
    {
        return $this->hasOne('App\User', 'id', 'sender_id')->select(["first_name","last_name","gender","id","username","image","batch_id","dob"]);
    }
    public function receiver()
    {
        return $this->hasOne('App\User', 'id', 'receiver_id')->select(["first_name","last_name","gender","id","username","image","batch_id","dob"]);
    }
}
