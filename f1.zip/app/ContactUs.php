<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;

class ContactUs extends BaseModel
{
    use SoftDeletes;

    protected $table = 'contact_us';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $appends = ['user_name'] ;

    public function user(){
        return $this->belongsTo('App\User', 'user_id');
    }

    public function getUserNameAttribute()
    {
        return ($this->user) ? $this->user->name : "" ;
    }
}
