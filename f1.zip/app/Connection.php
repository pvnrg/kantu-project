<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Connection extends BaseModel
{
    //

    use SoftDeletes;

	protected $table = 'connections';

    protected $primaryKey = 'id';

    protected $guarded = ['id'];

    protected $appends = ['from_user_name', 'to_user_name', 'status_name'] ;

    const STATUS_REQUEST = 'request';
    const STATUS_CONNECTED = 'connected';
    const STATUS_DECLINE = 'decline' ;
    const STATUS_BLOCK = 'block' ;
    const STATUS_CANCELLED = 'cancelled';
    const STATUS_ACCEPT = 'accept';
    const STATUS_REQUEST_SEND = 'send_request';
    const STATUS_REQUEST_RECEIVED = 'received_request';
    const STATUS_DECLINE_SEND = 'send_decline';
    const STATUS_DECLINE_RECEIVED = 'received_decline';


	public function sender()
    {
        return $this->hasOne('App\User', 'id', 'from_id');
    }
	public function receiver()
    {
        return $this->hasOne('App\User', 'id', 'to_id');
    }

    public function getFromUserNameAttribute()
    {
        return $this->sender ? $this->sender->name : "";
    }
    public function getToUserNameAttribute()
    {
        return $this->receiver ? $this->receiver->name : "";
    }
    public function connected_user($id)
    {
        return ( $this->from_id == $id ) ? $this->receiver :  $this->sender ;
    }

    public function getStatusNameAttribute() {
        switch ($this->status) {
            case 'request':
                return 'Pending' ;
                break;
            case 'connected':
                return 'Connected' ;
                break;
            case 'decline':
                return 'Declined' ;
                break;
            case 'block':
                return 'Blocked' ;
                break;
            case 'cancelled':
                return 'Cancelled' ;
                break;
            case 'accept':
                return 'Connected' ;
                break;
            default:
                return 'Pending' ;
                break;
        }
    }
}
