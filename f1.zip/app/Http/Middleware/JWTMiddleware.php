<?php

namespace App\Http\Middleware;

use Closure;
use JWTAuth;
use Exception;
use Tymon\JWTAuth\Http\Middleware\BaseMiddleware;

class JwtMiddleware extends BaseMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $result = ["message"=>"","code"=> 401 ,"status"=> false ] ;
        try {
            $user = JWTAuth::parseToken()->authenticate();
			if(!$user){
                $result["message"] = 'Authorization Token not found' ;
                return response()->json($result);
			}
        }
        catch (Exception $e) {
            if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenInvalidException)
            {
                $result["message"] = 'Token is Invalid' ;
                return response()->json($result);
            }
            else if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenExpiredException)
            {
                $result["message"] = 'Token is Expired' ;
                return response()->json($result);
            }
            else {
                $result["message"] = 'Authorization Token not found' ;
                return response()->json($result);
            }
        }

        return $next($request);
    }
}
