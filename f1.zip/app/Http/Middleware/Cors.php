<?php

namespace App\Http\Middleware;

use Closure;

class Cors
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $domains = ['http://localhost:8080', 'http://127.0.0.1:8080'];
        if (isset($request->server()['HTTP_ORIGIN'])) {
            $origin = $request->server()['HTTP_ORIGIN'];
            if (in_array($origin, $domains)){
                header('Access-Control-Allow-Origin: ' . $origin);
                header('Access-Control-Allow-Headers: Origin, Content-Type, Authorization');
                header('Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, PATCH, DELETE');
            }
        }
        return $next($request);
    }

    public function terminate($request, $response)
    {
        // dd($response);
        $response = $response
            ->header('Access-Control-Allow-Origin', 'http://localhost:8080')
            ->header('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
            ->header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
            ->header('Access-Control-Allow-Credentials', 'true');
        return $response;
        // return $next($request)
        // ->header('Access-Control-Allow-Credentials', 'true')
        // ->header('Access-Control-Allow-Origin', 'http://localhost:4200')
        // ->header('Access-Control-Allow-Methods', '*')
        // ->header('Access-Control-Max-Age', '3600')
        // ->header('Access-Control-Allow-Headers', 'X-Requested-With, Origin, X-Csrftoken, Content-Type, Accept, Authorization');
    }
}
