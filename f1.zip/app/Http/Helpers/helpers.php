<?php

use App\Languages;
use App\Permissions;
use App\Settings;
use App\Rollpermissions;
use App\Seos;
use App\User;
use Edujugon\PushNotification\Facades\PushNotification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\URL;


function getSetting($module,$key){
    return \Cache::remember($module.'_'.$key, 60*24, function () use ($module,$key) {
        return @Settings::select('fvalue')->where('fkey','default_title')->where('module',$module)->first()->fvalue;
    });
}

function canAccess($module,$action){
    $pass = false;
    $user = Auth::user();
    $permissions = Cache::tags(['permission'])->get('user_permission_'.$user->id);

    $permissionObj = Cache::remember('Permissions_'.$action, 60*24, function () use ($action) {
        return Permissions::select('id')->where('title',$action)->first();
    });
    if($permissionObj){
        $found = false;
        if($permissions){
            foreach($permissions as $permission) {
                if(isset($permission[$module])){
                    if(isset($permission[$module][$permissionObj->id])){
                        if($permission[$module][$permissionObj->id] == 1){
                            $pass = true;
                        }
                        $found = true;
                    }
                }
            }
        }


        if(!$found){
            if($permissions){
                foreach($permissions as $permission) {
                    if(isset($permission['global'])){
                        if(isset($permission['global'][$permissionObj->id]) && $permission['global'][$permissionObj->id] == 1){
                            $pass = true;
                        }
                    }
                }
            }
        }
    }

    if(!$pass){

        //return redirect()->route('admin.dashboard')->with('message', 'Do Not have access');
    }
    return  $pass;


    // if($user){
    //     $rolls = $user->rolls;
    //     if(count($rolls)>0){
    //         foreach($rolls as $roll){
    //             $rollpermissions = $roll->rollpermissions()->where('module',$module)->get();
    //             if(count($rollpermissions)>0){
    //                 foreach($rollpermissions as $rollpermission){
    //                     $title = $rollpermission->permission->title;
    //                     if( strtolower($title)  == strtolower($action) && $rollpermission->value == 1 ){
    //                         $pass = true;
    //                     }
    //                 }
    //             }else{
    //                 $rollpermissions = $roll->rollpermissions()->where('module','global')->get();
    //                 if(count($rollpermissions)>0){
    //                     foreach($rollpermissions as $rollpermission){
    //                         $title = $rollpermission->permission->title;
    //                         if( strtolower($title)  == strtolower($action) && $rollpermission->value == 1 ){
    //                             $pass = true;
    //                         }
    //                     }
    //                 }
    //             }

    //         }
    //     }

    // }

    //return $pass;
}


function renderAdminMenu($items, $sub = false){


    if(count($items) > 0){
        if($sub){
            $output = '<ul class="menu-content">';
        }else{
            $output = '<ul id="main-menu-navigation" data-menu="menu-navigation" data-scroll-to-active="true" class="navigation navigation-main">';
        }
        foreach($items as $item){
        //  dd($item->children);
        $active = false;
        $url = URL::current();
        if(strpos($url,$item->href)!== false){
            $active = true;
        }

            if($sub){
                $output .= ' <li class="'. ( ( isset($item->children) && count($item->children) > 0) ? 'has-sub': '' ) . '">';
            }else{
                $output .= ' <li class=" nav-item '. ( ( isset($item->children) && count($item->children) > 0) ? 'has-sub': '' ) . ' '.($active ? 'active' : '' ).' ">';
            }
            if($sub){
                if ( isset($item->children) && count($item->children) > 0){
                    $output .='<a href="#" >';
                }else{
                    $output .='<a href="'.url('/').$item->href.'" target="'.$item->target.'" title="'.$item->title.'" class="menu-item" >';
                }
            }else{
                if ( isset($item->children) && count($item->children) > 0){
                    $output .='<a href="#" >';
                }else{
                    $output .='<a href="'.url('/').$item->href.'" target="'.$item->target.'" title="'.$item->title.'" >';
                }
            }
            $output .='<i class="'.$item->icon.'"></i><span data-i18n="" class="menu-title">'.$item->text.'</span>';
            $output .='</a>';
            if(isset($item->children) && count($item->children) > 0){
                $output .= renderAdminMenu($item->children , true);
            }
            $output .='</li>';
        }
        $output .= '</ul>';
    }
    return $output;
}

function Text($text, $values = null){
    $text = strtoupper(Str::slug($text,'_'));
   // dd($text);
}

function getLangs(){
    return Languages::get();
}

// function setSettings($fkey, $value){
//     $context = env('APP_KEY');
//     session([$context.'.'.$fkey => $value]);
// }

function setSession($fkey, $value){
    $context = env('APP_KEY');
    Cache::tags(['settings'])->put($fkey, $value, 1440);
    session([$context.'.'.$fkey => $value]);
}

// function getSettings($fkey,  $default = null){
//     $context = env('APP_KEY');
//         if(( session($context.'.'.$fkey)) !== false && ( session($context.'.'.$fkey)) !== null ){
//             $return =  session($context.'.'.$fkey);
//         }else{
//             $setting = Settings::where('fkey',$fkey)->first();
//             if($setting){
//                 session([$context.'.'.$fkey => $setting->fvalue]);
//                 $return =  $setting->fvalue;
//             }else{
//                 session([$context.'.'.$fkey => $default]);
//                 $return =  $default;
//             }
//         }
//     return $return ;
// }
function getSess($fkey,  $default = null){
    $context = env('APP_KEY');



    // if(( session($context.'.'.$fkey)) !== false && ( session($context.'.'.$fkey)) !== null ){
    //     $return =  session($context.'.'.$fkey);
    // }else{
    //     session([$context.'.'.$fkey => $default]);
    //     $return =  $default;
    // }

    $return = Cache::tags(['settings'])->get($fkey);
    if($return == null){
        Cache::tags(['settings'])->put($fkey, $default, 1440);
        $return = $default;
    }

    return $return ;
}
function getSession($fkey,  $default = null){
    $context = env('APP_KEY');
        // if(( session($context.'.'.$fkey)) !== false && ( session($context.'.'.$fkey)) !== null ){
        //     $return =  session($context.'.'.$fkey);
        // }else{
        //     $setting = Settings::where('fkey',$fkey)->first();
        //     if($setting){
        //         session([$context.'.'.$fkey => $setting->fvalue]);
        //         $return =  $setting->fvalue;
        //     }else{
        //         session([$context.'.'.$fkey => $default]);
        //         $return =  $default;
        //     }
        // }


        $return = Cache::remember( $fkey , 1440, function () use($fkey, $default) {

            $setting = Settings::where('fkey',$fkey)->first();

            if($setting){
                return $setting->fvalue;
            }else{
                return $default;
            }
        });




        // $return = Cache::tags(['settings'])->get($fkey);


        // if($return == null){
        //     $setting = Settings::where('fkey',$fkey)->first();
        //     if($setting){
        //         Cache::tags(['settings'])->put($fkey, $setting->fvalue, 1440);
        //         $return =  $setting->fvalue;
        //     }else{
        //         Cache::tags(['settings'])->put($fkey, $default, 1440);
        //         $return = $default;
        //     }
        // }
    return $return ;
}
function checkpermission($roll, $permission, $module){
    $context = env('APP_KEY');
    //$fkey = $module."_roll_".$roll."_permission_".$permission;
    $fkey = $module.".roll_".$roll.".permission_".$permission;

    if(( session($context.'.'.$fkey)) !== false && ( session($context.'.'.$fkey)) !== null ){
        $return =  session($context.'.'.$fkey);
    }else{
        $rollpermission = Rollpermissions::where('roll_id',$roll)->where('permission_id',$permission)->where('module',$module)->first();
        if($rollpermission){
            if($rollpermission->value == 1){
                session([$context.'.'.$fkey => true]);
                $return =  true;
            }else{
                //session([$context.'.'.$fkey => false]);
                $return =  false;
            }
        }else{
            if($module != 'global'){
                $rollpermission = Rollpermissions::where('roll_id',$roll)->where('permission_id',$permission)->where('module','global')->first();
                if($rollpermission){
                    if($rollpermission->value == 1){
                        session([$context.'.'.$fkey => true]);
                        $return =  true;
                    }else{
                        //session([$context.'.'.$fkey => false]);
                        $return =  false;
                    }
                }else{
                    //session([$context.'.'.$fkey => false]);
                    $return =  false;
                }
            }else{
                //session([$context.'.'.$fkey => false]);
                $return =  false;
            }
        }
    }
    return $return ;
}

function make_null($value){
    $value = $value->toArray();
    array_walk_recursive($value, function (&$item, $key) {
        $item =  $item === null ? "" : $item;
    });
    return $value;
}

function uploadImage($image, $path, $imageName ,$height , $width )
{
    $image = Image::make($image->getRealPath());

    $path = public_path() .'/'. $path;

    File::exists($path) or mkdir($path, 0777, true);

    $image->fit($width, $height, function ($constraint) {
            $constraint->aspectRatio();
        })->save($path.'/'.$imageName);

    return $imageName;
}

function uploadBase64($files,$item,$type,$imgs_priority)
{
    $path = 'uploads/'.$item->getTable().'/'.$item->id;
    $upath = public_path('storage') . '/'.$path;

    $path_thumb = $upath.'/thumb';
    \File::exists($path_thumb) or mkdir($path_thumb, 0777, true);

    $name = uniqid()."_".$item->id.'.png';
    $imgob = str_replace('data:image/png;base64,','',$files);

    \File::put($upath.'/'. $name, base64_decode($imgob));

    if(filesize($upath.'/'. $name) > 0){

        $img = Image::make($upath.'/'. $name,array(

            'width' => 100,
            'height' => 100,
            'grayscale' => false
        ));

        $img->save($path_thumb.'/'.$name);

        $requestData = array();
        $requestData['refe_file_path'] = $path;
        $requestData['refe_file_name'] = $name;
        $requestData['file_real_name'] = $name;
        $requestData['priority'] =  0;
        $requestData['refe_field_id'] = $item->id;
        $requestData['refe_table_name'] = $item->getTable();
        $requestData['file_type'] = $type;
        \App\Refefile::create($requestData);

    }else{
        if (\File::exists($path.'/'. $name)) {
            unlink($path.'/'. $name);
        }
    }
    return 1;
}
function uploadModalReferenceFile($files,$item,$type ,$imgs_priority, $multiple = true )
{
    $path = 'uploads/'.$item->getTable().'/'.$item->id;
    $upath = public_path('storage') . '/'.$path;
    $path_thumb = $upath.'/thumb';
    \File::exists($path_thumb) or mkdir($path_thumb, 0777, true);

    $upload = 0;

    foreach ($files as $i => $file) {

        $timestamp = uniqid();
        $real_name = $file->getClientOriginalName();
        $extension = $file->getClientOriginalExtension();
        $name = $timestamp."_".$item->id.".".$extension;

        if(in_array($extension,['jpg','jpeg','png','PNG','JPEG','JPG'])){

            $img = Image::make($file->getRealPath(),array(
                'width' => 100,
                'height' => 100,
                'grayscale' => false
            ));

            $img->save($path_thumb.'/'.$name);

        }
        $file->move($upath,$name);

        $requestData = array();
        $requestData['refe_file_path'] = $path;
        $requestData['refe_file_name'] = $name;
        $requestData['file_real_name'] = $real_name;
        $requestData['priority'] = (isset($imgs_priority[$real_name]))? $imgs_priority[$real_name] : 0;
        $requestData['refe_field_id'] = $item->id;
        $requestData['refe_table_name'] = $item->getTable();
        $requestData['file_type'] = $type;
        $Refefile = \App\Refefile::create($requestData);


        if(!$multiple){
            $refes = \App\Refefile::where('refe_file_path',$path)->where('file_type',$type)->where('id','!=',$Refefile->id)->get();
            foreach($refes as $refe){
                removeRefeImage($refe);
            }
        }

        $upload++;
    }
    return $upload;

}


function removeRefeImage($refe)
{
    if($refe){

        $path = public_path('storage');

        if ($refe->refe_file_name && $refe->refe_file_name !="" && \File::exists($path."/".$refe->refe_file_path."/".$refe->refe_file_name)) {
            unlink($path."/".$refe->refe_file_path."/".$refe->refe_file_name);
        }
        if ($refe->refe_file_name && $refe->refe_file_name !="" && \File::exists($path."/".$refe->refe_file_path."/thumb/".$refe->refe_file_name)) {
            unlink($path."/".$refe->refe_file_path."/thumb/".$refe->refe_file_name);
        }

    $refe->delete();
    }
}


function get_api_data($data)
{
    if($data != null)
    {
        return $data;
    }
    return 0;
}
function make_lang($data ,$isArray=1, $intersect){

	if($isArray ==1){
        return array_map(function($v) use($intersect) {
            if(!empty($intersect)){
                return array_intersect_key( $v , array_flip( $intersect ) );
            }else{
                return $v;
            }
        }, $data);
    }else{
        if(!empty($intersect)){
            return array_intersect_key( $data , array_flip( $intersect ) );
        }else{
            return $data;
        }
    }

}



 function send_notification($device_token = "", $message = [] ){

    if($device_token){

        // $message = [ 'title' => $title,
        // 'body' => $body,
        // 'sound' => 'default' ,
        //'myCustomVAlue' => 'value'] ;
        try {
            $push = PushNotification::setService('fcm')->setMessage([
                'notification' => $message ,
                'data' => [ 'extraPayLoad' => 'payload_data' ]
                ])
            ->setDevicesToken([$device_token])
            ->send()->getFeedback();

            if($push && $push->success == 1){
                return true ;
            }
        } catch (\Throwable $th) {
            add_logs("error","exception_"."send_notification",$th->getMessage(),$th->getCode(),$th->getLine(),$th->getFile());
            \Log::error($th);
            \Log::info("message not sent to {$device_token} ");
        }
        return false;

    }
    return false ;

}




// function send_notification($to,$device_type,$message)
// {
// 	try{

// 		$notification =  [
// 			"body"=>$message['body'],
// 			"title"=>$message['title'],
// 		];

//     // Firebase notification  allow in both type
//     if($device_type == 'android' || $device_type == 'ios')
//     {

//         // Set POST variables
//         $url = 'https://fcm.googleapis.com/fcm/send';
//         $FIREBASE_KEY = 'AIzaSyDJQssjjeNikbacA7FZsx_LR6n_X_oj_dQ';

//         $field = array(

// 			"to" => $to,
// 			"collapse_key" => "type_a",
// 			"notification" => $notification,
// 			"data" => $message
// 		);

// 		$headers = array(
//             'Authorization: key=' . $FIREBASE_KEY,
//             'Content-Type: application/json'
//         );

//         //Initializing curl to open a connection
//         $ch = curl_init();

//         //Setting the curl url
//         curl_setopt($ch, CURLOPT_URL, $url);

//         //setting the method as post
//         curl_setopt($ch, CURLOPT_POST, true);

//         //adding headers
//         curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
//         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

//         //disabling ssl support
//         curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

//         //adding the fields in json format
//         curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($field));

//         //finally executing the curl request
//         $result = curl_exec($ch);
//         if ($result === false) {
//             die('Curl failed: ' . curl_error($ch));
//         }

//         //Now close the connection
//         curl_close($ch);

//         //and return the result
//         return $result;



//     }
//     elseif($device_type == 'ios')
//     {
//         /*Notification Code*/


//         $deviceid = $to;
//         $certificate_path = public_path()."/gochiso_push.pem";


//         $app_is_live = 0;
//         $tHost = 'gateway.sandbox.push.apple.com';

//         $tPort = 2195;

//         // Provide the Certificate and Key Data.

//         $tCert = $certificate_path;

//         // Provide the Private Key Passphrase (alternatively you can keep this secrete

//         // and enter the key manually on the terminal -> remove relevant line from code).

//         // Replace XXXXX with your Passphrase

//         $tPassphrase = 'xxxxxx';

//         // Provide the Device Identifier (Ensure that the Identifier does not have spaces in it).

//         // Replace this token with the token of the iOS device that is to receive the notification.

//         $tToken = $deviceid;

//         // The Badge Number for the Application Icon (integer >=0).

//         $tBadge = 1;

//         // Audible Notification Option.

//         $tSound = 'default';


//         // Create the message content that is to be sent to the device.

//       /*  $tBody['aps'] = array (

// 			'alert' => $message['message'],
// 			'badge' => $tBadge,
// 			'sound' => $tSound,
// 			'tagert_screen' => $message['target_screen'],
//         );*/

//         $tBody['aps'] =  $message;
//         $tBody['aps']['alert'] = $message['title'];
//         $tBody['aps']['badge'] = $tBadge;
//         $tBody['aps']['sound'] = $tSound;

//         $tBody = json_encode ($tBody);

//         // Create the Socket Stream.

//         $tContext = stream_context_create ();

//         stream_context_set_option ($tContext, 'ssl', 'local_cert', $tCert);

//         // Remove this line if you would like to enter the Private Key Passphrase manually.

//         stream_context_set_option ($tContext, 'ssl', 'passphrase', $tPassphrase);
// 		//return 'Ok';
//         if ($app_is_live == '1') {
//         $tHost = "gateway.push.apple.com";
//         } else {
//         $tHost = "gateway.sandbox.push.apple.com";
//         }
//         // Open the Connection to the APNS Server.

//         $tSocket = stream_socket_client ('ssl://'.$tHost.':'.$tPort, $error, $errstr, 30, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $tContext);

//         // Check if we were able to open a socket.

//         if (!$tSocket)

//         exit ("APNS Connection Failed: $error $errstr" . PHP_EOL);

//         // Build the Binary Notification.

//         $tMsg = chr (0) . chr (0) . chr (32) . pack ('H*', $tToken) . pack ('n', strlen ($tBody)) . $tBody;

//         // Send the Notification to the Server.

//         $tResult = fwrite ($tSocket, $tMsg, strlen ($tMsg));

//         if ($tResult){

//         $data_response = 'Delivered Message to APNS' . PHP_EOL;

//         }else

//         $data_response = 'Could not Deliver Message to APNS' . PHP_EOL;

//         // Close the Connection to the Server.

//         fclose ($tSocket);
//         return  $data_response;


//     }

// 	}catch(\Exception $exception){
//            return  $exception->getMessage();
//     }
// }

function send_sms($country_code,$number , $msg)
{
    if(!$number || $number == ""){
        return false;
    }

    if(!$country_code || $country_code == ""){ $country_code = "+1"; }

    if (count(explode('+', $number)) <= 1) {
       $number = $country_code.$number;
    }


    $sid = \config('admin.twilio.SID'); // Your Account SID from www.twilio.com/console
    $token = \config('admin.twilio.TOKEN'); // Your Auth Token from www.twilio.com/console

    $client = new \Twilio\Rest\Client($sid, $token);
    $message = $client->messages->create(
    $number, // Text this number
    array(
        'from' => \config('admin.twilio.FROM'), // From a valid Twilio number
        'body' => $msg
    )
    );

    return $message->sid;
}
function add_logs($log_type,$slug,$desc,$code,$line_no,$file_name)
{


    $ob = \App\Logs::where("line_no",$line_no)->where("file_name",$file_name)->first();
    if($ob){
        $ob->total_count =  $ob->total_count + 1;
        $ob->desc =  $desc;
        $ob->slug =  $slug;
        $ob->save();
    }else{
        \App\Logs::create(['log_type'=>$log_type,'slug'=>$slug,'desc'=>$desc,'status_code'=>$code,'total_count'=>1,'line_no'=>$line_no,'file_name'=>$file_name]);
    }
}

function getTableColumnAndTypeList($tableName = 'users', $fullType = false){
    $fieldAndTypeList = [];
    foreach (DB::select( "describe $tableName")  as $field){
        $type = ($fullType || !str_contains($field->Type, '('))? $field->Type: substr($field->Type, 0, strpos($field->Type, '('));
        $fieldAndTypeList[$field->Field] = $type;
    }
    return $fieldAndTypeList;
}

?>
