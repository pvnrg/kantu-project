<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Tymon\JWTAuth\Exceptions\JWTException;
use JWTAuth;
use Hash;
use Session;
use Carbon\Carbon;
use App\User;
use App\Settings;
use App\ResponseText as RT;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        $result = [] ;
        $message = "" ;
        $status = true ;
        $code = 200 ;

        $rules = array(
            'email' => 'required|email',
            'password'=>'required',
            'user_type' => 'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $message = reset($msgArr)[0];
            $status = false;
            $code = 400;

            return response()->json([
                    'message' => $message,
                    'success' => $status,
                    'result' => $result,
                    'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
        }

        if (isset($request->email) && isset($request->password) && isset($request->user_type)) {
            $input = $request->only('email', 'password');
            $jwt_token = null;
            $user = User::where("email", $request->email)->withTrashed()->with('roles')->first();

            if ($user) {
                if ($request->has('firebase_token')) {
                    $user->firebase_token = $request->firebase_token;
                }
                if ($request->has('device_type')) {
                    $user->device_type = $request->device_type;
                }
                $user->save();

                if ($user->hasRole($request->user_type)) {
                    if (Hash::check($request->password, $user->password)) {
                        if ($user->status == 1 && $jwt_token = JWTAuth::attempt($input, ['exp' =>Carbon::now()->addDays(7)->timestamp])) {
                            if ($request->user_type == 'User') {
                                $user = JWTAuth::user();
                                $path = url("/")."/"."uploads/user/";
                                $user->thumb_image = ($user->image)?$path."thumbnail/".$user->image:'';
                                $user->image = ($user->image)?$path.$user->image:'';
                                $user['token']=$jwt_token;
                                $result=make_null($user);
                                //$result = collect($user)->only('id','name','email','token','firebase_token');

                                $message = RT::rtext("success_login") ;
                            } else {
                                $message = 'Please Enter Correct User Type.' ;
                                $status = false ;
                                $code = 401 ;
                            }
                        } else {
                            $message = RT::rtext('warning_your_account_not_activated_yet') ;
                            $status = false ;
                            $code = 401 ;
                        }
                    } else {
                        $message = RT::rtext('warning_incorrect_email_or_password') ;
                        $status = false ;
                        $code = 401 ;
                    }
                } else {
                    $message = 'Please select the correct user type.' ;
                    $status = false ;
                    $code = 401 ;
                }
            } else {
                $message = RT::rtext('email_is_not_registered') ;
                $status = false ;
                $code = 401 ;
            }
        } else {
            $message = 'Invalid Parameter' ;
            $status = false ;
            $code = 400 ;
        }

        return response()->json([
            'message' => $message,
            'success' => $status,
            'result' => $result,
            'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
    }

    public function logout(Request $request)
    {
        $result = [] ;
        $message = "" ;
        $status = true ;
        $code = 200 ;

        $rules = array(
            'user_type' => 'required|in:User',
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $message = reset($msgArr)[0];
            $status = false;
            $code = 400;

            return response()->json([
                    'message' => $message,
                    'success' => $status,
                    'result' => $result,
                    'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
        }

        if ($request->header('authorization') != null) {
            try {
                JWTAuth::invalidate($request->header('authorization'));
                $message =  RT::rtext('success_logout') ;
            } catch (JWTException $exception) {
                $message = 'Sorry, the user cannot be logged out.' ;
                $status = false ;
                $code = 400 ;
            }
        } else {
            $message = 'Invalid Parameter.' ;
            $status = false ;
            $code = 400 ;
        }
        return response()->json([
            'message' => $message,
            'success' => $status,
            'result' => $result,
            'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
    }


    public function forgotPassword(Request $request)
    {
        $result = [] ;
        $message = "" ;
        $status = true ;
        $code = 200 ;

        if (isset($request->email)) {
            $user=User::where('email', $request->email)->first();
            if ($user) {
                $otp = substr(number_format(time() * rand(), 0, '', ''), 0, 6);
                $user->otp = $otp;
                $user->save();

                $subject = RT::rtext('mail_subject_reset_password');
                \Mail::send('email.forgot-password', compact('user'), function ($message) use ($user, $subject) {
                    $message->to($user->email)->subject($subject);
                });

                $result = [ 'email' => $user->email ] ;
                $message = RT::rtext('password_reset_otp_has_been_sent_to_email') ;
            } else {
                $message = RT::rtext("your_have_entered_worng_otp") ;
                $status = false ;
                $code = 400 ;
            }
        } else {
            $message = RT::rtext("warning_user_data_not_found") ;
            $status = false ;
            $code = 400 ;
        }
        return response()->json([
            'message' => $message,
            'success' => $status,
            'result' => $result,
            'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
    }

    public function confirmOTP(Request $request)
    {
        $result = [] ;
        $message = "" ;
        $status = true ;
        $code = 200 ;

        $rules = array(
            'otp'=>'required',
            'email' => 'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $message = reset($msgArr)[0];
            $status = false;
            $code = 400;

            return response()->json([
                    'message' => $message,
                    'success' => $status,
                    'result' => $result,
                    'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
        }

        $user=User::where('email', $request->email)->first();
        if ($user) {
            if ($user->otp === $request->otp) {
                $result= [
                    'email' => $user->email ,
                    'otp' => $user->otp
                ];
                $message =  RT::rtext("success") ;
            } else {
                $message = RT::rtext("your_have_entered_worng_otp") ;
                $status = false ;
                $code = 400 ;
            }
        } else {
            $message = RT::rtext("warning_user_data_not_found") ;
            $status = false ;
            $code = 400 ;
        }

        return response()->json([
            'message' => $message,
            'success' => $status,
            'result' => $result,
            'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
    }

    public function resetPassword(Request $request)
    {
        $result = [] ;
        $message = "" ;
        $status = true ;
        $code = 200 ;

        $rules = array(
            'email' => 'required',
            'otp'=>'required',
            'password'=>'required|same:confirm_password',
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $message = reset($msgArr)[0];
            $status = false;
            $code = 400;

            return response()->json([
                    'message' => $message,
                    'success' => $status,
                    'result' => $result,
                    'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
        }

        $user=User::where('email', $request->email)->first();

        if ($user) {
            if ($user->otp === $request->otp) {
                $user->otp = null;
                $user->password = bcrypt($request->password);
                $user->save();
                // $result=make_null($user);
                $message =  RT::rtext("success_password_changed") ;
            } else {
                $message = RT::rtext("your_have_entered_worng_otp") ;
                $status = false ;
                $code = 400 ;
            }
        } else {
            $message = RT::rtext("warning_user_data_not_found") ;
            $status = false ;
            $code = 400 ;
        }

        return response()->json([
            'message' => $message,
            'success' => $status,
            'result' => $result,
            'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
    }

    public function changePassword(Request $request)
    {
        $result = [] ;
        $message = "" ;
        $status = true ;
        $code = 200 ;

        $rules = array(
            'email' => 'required|email',
            'password'=>'required|same:confirm_password',
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $message = reset($msgArr)[0];
            $status = false;
            $code = 400;

            return response()->json([
                    'message' => $message,
                    'success' => $status,
                    'result' => $result,
                    'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
        }

        $user=JWTAuth::touser($request->header('authorization'));

        if ($user != null && $user->email == $request->email) {
            $user->password=Hash::make($request->password);
            $user->save();
            // $result=make_null($user);
            // $result['token']=$request->header('authorization');
            $message =  RT::rtext("success_password_changed") ;
        } else {
            $message =  RT::rtext("warning_user_data_not_found") ;
            $status = false ;
            $code = 400 ;
        }

        return response()->json([
            'message' => $message,
            'success' => $status,
            'result' => $result,
            'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
    }
}
