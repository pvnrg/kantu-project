<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Rolls;
use App\User;
use App\Orders;
use App\Setting;
use App\Plan;
use App\Cards;
use App\Billing;
use Illuminate\Support\Facades\Hash;
use JWTAuth;
use Carbon\Carbon as Carbon;
use DB;
use App\Notification;
use App\Connection;

use App\Jobs\SendEmailJob;
use App\ResponseText as RT;

class RegisterController extends Controller
{

	public function register(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;
		$user = null;
		$plan = Plan::where("type","free")->first();

        $rules = array(
            'email' => 'required|email|unique:users',
            'password'=>'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'phone' => 'required|regex:/^(?=.*[0-9])[ +()0-9]+$/|unique:users,phone',
			'username' => 'required|unique:users',
			'pan_number' => 'required|min:10|max:10',
            'gender'=>'required|in:male,female',
            'dob'=>'required|date_format:Y-m-d|before:'.Carbon::parse($request->get('dob'))->startOfDay()->gte(Carbon::now()->subYears(15)),
        );
		$val_msg = [
            'phone.unique'=> RT::rtext("warning_require_unique_phone_number"),
            'dob.before' => "Age must be atleast 15 years old"
		];
        $validator = \Validator::make($request->all(), $rules, $val_msg);

		try {
			if (!$plan) {
				$result['message'] = "No free plan or package exist!";
			} else if (!$validator->fails()) {
				$userinput = $request->all();
				$userinput['name'] = $request->first_name." ".$request->last_name ;
				$userinput['password'] = Hash::make($request->password);
				$userinput['badge_status'] = "in-progress";
				$userinput['status'] = "active";
				$userinput['regi_reference'] = $request->get('regi_reference','site');
				// if ($request->has('card_holder_name') && strpos($request->card_holder_name, 'local') !== false) {
				// 	$userinput['stripe_account_type'] = "local";
				// 	$SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
				// } else if(\config('admin.stripe.SECRET_KEY') == \config('admin.stripe_citrus.SECRET_KEY')) {
				// 	$userinput['stripe_account_type'] = "local";
				// 	$SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
				// } else {
				// 	$userinput['stripe_account_type'] = "live";
				// 	$SECRET_KEY = \config('admin.stripe.SECRET_KEY');
				// }
				// $userinput['otp'] = substr(number_format(time() * rand(),0,'',''),0,6);
				$user=User::create($userinput);
				
				$files = $request->file();
				if($files){
					foreach($files as $fkey=>$file) {
						if(is_array($file)) {
							$ufile = $request->file($fkey);
							uploadModalReferenceFile($ufile,$user,'document_type',[]);
						} else {
							$ufile = [$request->file($fkey)];
						    uploadModalReferenceFile($ufile,$user,'profile_pic_type',[],false);
						}
					}
				}

				$role=Rolls::where('title','User')->first();
				$user->roles()->attach($role);
				$result = ["message"=>"Registration Successfully.","code"=>200,"data"=>[]] ;
				// $customer = $this->createStripCustomer($SECRET_KEY, $user);

				// if ($customer['code'] != 200) {
				// 	$result['message'] = $customer['message'];
				// } else {
				// 	$card = $this->createStripCard($SECRET_KEY, $user, $request->token_id);
				// 	if ($card['code'] != 200) {
				// 		$result['message'] = $card['message'];
				// 	} else {
				// 		$payment = $this->createStripFirstPayment($SECRET_KEY,$user);
				// 		if ($payment['code'] != 200) {
				// 			$result['message'] = $payment['message'];
				// 		} else {
				// 			$subject = RT::rtext("mail_subject_register_welcome");
				// 			$mdata = ['action'=>'parent_registration','subject'=>$subject,'user'=>$user,'view'=>'email.parent-registration','to'=>$user->email];
				// 			SendEmailJob::dispatch($mdata)->onConnection('database')->onQueue('emails');

				// 			$subject = RT::rtext('mail_subject_email_verification');
				// 			\Mail::send('email.email-verification', compact('user'), function ($message) use ($user, $subject) {
				// 				$message->to($user->email)->subject($subject);
				// 			});
				// 			$result['message'] = RT::rtext("success_register") ;
				// 			$result['code'] = 200;
				// 			$result['data'] = make_null($user);
				// 		}
				// 	}
				// }
			} else {
				$validation = $validator;
				$msgArr = $validator->messages()->toArray();
				$result['message'] = reset($msgArr)[0];
			}
		
		}catch(\Exception $e){
			if($user){
				$user->forceDelete();
			}
			$result['message'] = $e->getMessage();
		}

		return $this->JsonResponse($result);

    }


    public function profile(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));
        if(!$user){
            $result['message'] = RT::rtext("warning_user_data_not_found");
        }else{
            $user = collect($user)->except(\config('settings.api_parms.remove_extra_user_param'));
            $result['data'] = make_null($user);
            $result['code'] = 200;
        }

        return $this->JsonResponse($result);
    }

    public function updateProfile(Request $request)
    {


        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'user_id' => 'required',
            'phone'=>'regex:/^(?=.*[0-9])[ +()0-9]+$/|unique:users,phone,'.$user->id,
            'gender'=>'nullable|in:male,female',
            'dob'=>'nullable|date_format:Y-m-d',
        );
		$val_msg = [
			'phone.unique'=>RT::rtext("warning_require_unique_phone_number")
		];
        $validator = \Validator::make($request->all(), $rules,$val_msg);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];

        }else if ($user->id == $request->user_id) {

            $input['first_name']=($request->first_name)?$request->first_name:$user->first_name;
            $input['last_name']=($request->last_name)?$request->last_name:$user->last_name;
            $input['name']=$input['first_name']." ".$input['last_name'] ;
            $input['city']=($request->city)?$request->city:$user->city;
            $input['state']=($request->state)?$request->state:$user->state;
            $input['gender']=($request->gender)?$request->gender:$user->gender;
            $input['dob']=($request->dob)?$request->dob:$user->dob;
            if($request->phone && $request->phone !=  $user->phone ){
                $input['phone'] = $request->phone ;
            }

            // $image = ($request->image)?$request->image:'';
            // if ($image) {
            //     $files= [$image];
            //     uploadModalReferenceFile($files,$user,'profile_pic_type',[],false);
            // }
            $change_phone = 0;
            if ($user->phone != $request->phone) {
                $change_phone = 1;
            }
            if ($request->has('country_code') && $request->get('country_code') != "" && $user->country_code != $request->country_code) {
                $change_phone = 1;
                $input['country_code'] = $request->country_code;
            }
            if ($change_phone == 1) {
                $input['phone_verified'] = 0;
            }
            $user->update($input);

            $user = collect($user)->except(\config('settings.api_parms.remove_extra_user_param'));

            $result['data'] = make_null($user);
            $result['code'] = 200;
			$result['message'] = RT::rtext("success_profile_updated") ;

        }else{
            $result['message'] =  RT::rtext("warning_user_data_not_found") ;
        }

		return $this->JsonResponse($result);
    }

	public function uniqueField($field , Request $request)
    {
		$res = ["message"=>"","code"=>400,'data'=>""];

		if( $field == "parent_mob_no"){
			$field = "phone";
		}
        $user = User::where($field,$request->field_value)->first();

		$on_exist = false;

		if($request->has('on_exist') && $request->get('on_exist') != "" && $request->get('on_exist') != "false" ){
			$on_exist = true;
		}

		if($user)
        {
			if($on_exist){
				$res = ["message"=>"Suceess","code"=>200,'data'=>$user];
			}else{
				$res = ["message"=>RT::rtext("warning_require_unique_field"),"code"=>400,'data'=>$user];
			}

        }
        else
        {
            if(!$on_exist){
				$res = ["message"=>"Suceess","code"=>200,'data'=>[]];
			}else{
				$res = ["message"=>"No data found","code"=>400,'data'=>[]];
			}
        }

		return $this->JsonResponse($res);
    }

	public function verifyEmail(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

		$user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'otp'=>'required',
            'email' => 'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else{

			if ($user->email == $request->email) {
				if ($user->otp == $request->otp && $user->otp && $user->otp !="" ) {
					$user->email_verified_at = Carbon::now();
					$user->save();
					$result['data']['user'] =  collect($user)->except(\config('settings.api_parms.remove_extra_user_param'));
                    $result['message'] =  RT::rtext("your_email_verified") ;
                    $result['code'] = 200 ;
				} else {
					$result['message'] = RT::rtext("your_have_entered_worng_otp") ;
				}
			} else {
				$result['message'] = RT::rtext("warning_user_data_not_found") ;
			}
		}

        return $this->JsonResponse($result);
	}

	public function verifyEmailResend(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

		$user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'email' => 'required|email'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else{
			$user->email_verified_at = null; $user->save();
			if (!$user->email_verified_at || $user->email_verified_at == "") {

				$user->otp = substr(number_format(time() * rand(),0,'',''),0,6);
				if ($user->email != $request->email) {
					$user->email = $request->email;
				}
				$user->save();

				$subject = RT::rtext('mail_subject_email_verification');
				\Mail::send('email.email-verification', compact('user'), function ($message) use ($user, $subject) {
					$message->to($user->email)->subject($subject);
				});

                $result['message'] =  RT::rtext("success_verfication_email_send") ;
                $result['code'] = 200;

			} else {
				$result['message'] = RT::rtext("warning_user_data_not_found") ;
			}
		}

        return $this->JsonResponse($result);
	}



	/**********************STRIPE******************/

	public function createStripFirstPayment($SECRET_KEY,$user)
    {
		$res = ["message"=>"","code"=>400,'data'=>""];
		$stripe=\Stripe::make($SECRET_KEY);
		$onetime_charge = \config('admin.one_time_fee');

		try {
                $charge = $stripe->charges()->create([
                    'customer' => $user->stripe_id,
                    'currency' => 'USD',
                    'amount'   => $onetime_charge,
                ]);
				$plan = Plan::where("type","free")->first();

				$subscription['id']=0;
                $subscription['status']="active";

				$order['user_id'] = $user->id;
                $order['plan_id'] = $plan->id;
                $order['start_date'] = Carbon::now()->format('Y-m-d');
                $date = null;
                if($plan->type == "monthly"){
                    $date = Carbon::now()->addMonths(1);
                }elseif($plan->type == "yearly"){
                    $date = Carbon::now()->addYears(1);
                }elseif($plan->type == "daily"){
                    $date = Carbon::now()->addDays(1);
                }elseif($plan->type == "weekly"){
                    $date = Carbon::now()->addWeeks(1);
                }
                elseif($plan->type == "free"){
                    $date = Carbon::now()->addDays(\config('admin.free_trial_duration'));
                }
                $order['expiry_date'] = $date->subDays(1)->format('Y-m-d');
                $order['next_pay'] = $date->addDays(1)->format('Y-m-d');
                $order['auth_response'] = json_encode($subscription);
                $order['plan_ob'] = json_encode($plan);
                $order['order_no'] = Orders::getNextOrderNumber();
                $order['amount'] = $plan->actual_amount;
                $order['subscription_id'] = $subscription['id'];
                $order['trans_status'] = $subscription['status'];
                $order['token'] = "";
                $order['status'] = 1;
				$order['one_time_fee'] = $onetime_charge;
				$order['one_time_charge_id'] = $charge['id'];
				$order['one_time_charge_ob'] = json_encode($charge);

                $result = Orders::create($order);

				$res['code'] = 200;
				$res['data'] = $result;


         } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
            add_logs("error","exception_"."createStripFirstPayment",$e->getMessage(),$e->getCode(),$e->getLine(),$e->getFile());
				$res['message'] =  $e->getMessage();
                $stripe->customers()->delete($user->stripe_id);
                $user->cards()->forceDelete();
                $user->forceDelete();
		}

		return $res;
	}

	public function createStripCard($SECRET_KEY,$user,$token)
    {
		$res = ["message"=>"","code"=>400,'data'=>""];
		$stripe=\Stripe::make($SECRET_KEY);

		try {

		   $cardRes = $stripe->cards()->create($user->stripe_id, $token);
		   $res['code'] = 200;
		   $res['data'] = $cardRes;

		   $customerupdate = $stripe->customers()->update($user->stripe_id, ['default_source' => $cardRes['id']]);

		    $cardRes['default'] = 1;
			$user->cards()->update(['default'=>0]);
			$saved_card = Cards::saveCard($cardRes, $user->stripe_id);

        } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
                $res['message'] =  $e->getMessage();
                add_logs("error","exception_"."createStripCard",$e->getMessage(),$e->getCode(),$e->getLine(),$e->getFile());
                $stripe->customers()->delete($user->stripe_id);
                $user->forceDelete();
		}

		return $res;
	}

	public function createStripCustomer($SECRET_KEY,$user)
    {
		$res = ["message"=>"","code"=>400,'data'=>""];
		$stripe=\Stripe::make($SECRET_KEY);

		try {
            $customer = $stripe->customers()->create([
                'email' => $user->email,
            ]);

			$user->stripe_id = $customer['id'];
			$user->save();

			$res['code'] = 200;
			$res['data'] = $customer;

        } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
            add_logs("error","exception_"."createStripCustomer",$e->getMessage(),$e->getCode(),$e->getLine(),$e->getFile());
			$res['message'] = $e->getMessage();
			$user->forceDelete();
		}

		return $res;
	}


}
