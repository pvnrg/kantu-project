<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use JWTAuth;
use DB;
use Carbon\Carbon as Carbon;
use App\Role;
use App\User;
use App\OrderUser;
use App\Order;
use App\PlanUser;
use App\Payment;
use App\PlanOrder;
use App\Setting;
use App\Plan;
use App\Subscription;
use App\Billing;
use App\Cards;
use App\Notification;
use App\ResponseText as RT;
use App\Jobs\SendEmailJob;

class CardsController extends Controller
{

    public function getMyCards(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));
        $cards = $user->cards()->get();
        $total = $cards->count();

        if ($total == 0) {
            $result['message'] = "No Cards Found " ;
        } else {
            $res= ['cards' => make_null($cards) , 'total' => $total];
			$result['data'] = $res ;
            $result['message'] = "Cards List" ;
			$result['code'] = 200;
        }

		 return $this->JsonResponse($result);
    }
    public function addCard(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'user_id'=>'required',
            'token_id'=>'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else if ($user && $user->id == $request->user_id) {

            $SECRET_KEY = \config('admin.stripe.SECRET_KEY');
            if ($user->stripe_account_type == "local") {
                $SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
            }
            $stripe=\Stripe::make($SECRET_KEY);

            if (!$user->stripe_id || $user->stripe_id == "") {
                $customer = $this->createStripCustomer($SECRET_KEY,$user);

				if($customer['code'] != 200){
					$result['message'] = $customer['message'];
				}
            }

			if($user->stripe_id){
				$card = $this->createStripCard($SECRET_KEY,$user,$request->token_id);
				if($card['code'] != 200){
					$result['message'] = $card['message'];
				}else{
					$result['code'] = 200 ;
					$result['data'] = $card['data'] ;
					$result['message'] = RT::rtext("success_card_added");
				}
			}

        } else {
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }

        return $this->JsonResponse($result);
    }


    public function setDefaultCard(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'user_id'=>'required',
            'card_id'=>'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else if ($user && $user->id == $request->user_id) {


			$SECRET_KEY = \config('admin.stripe.SECRET_KEY');
            if ($user->stripe_account_type == "local") {
                $SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
            }

			$savecard = $user->cards()->where("id", $request->card_id)->first();

            if($savecard) {
				$stripe=\Stripe::make($SECRET_KEY);
				 try {
                    $cardRes = $stripe->customers()->update($user->stripe_id, [
                        'default_source' => $savecard->card_id
                    ]);

					if (isset($cardRes) && $cardRes) {
						$user->cards()->update(['default'=>0]);
						$savecard->update(['default'=>1]);

						$result['message'] = RT::rtext("success_card_updated");
						$result['data']= $savecard ;
						$result['code'] = 200;
					} else {
						$result['message'] = RT::rtext("error_default");
					}

                } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
                    add_logs("error","exception_".$request->path(),$e->getMessage(),$e->getCode(),$e->getLine(),$e->getFile());
                    $result['message'] = $e->getMessage();

                }
			}else{
				$result['message'] = RT::rtext("warning_card_does_not_belongs_to_user");
			}
		}else{
			$result['message'] = RT::rtext("warning_user_data_not_found") ;
		}

		return $this->JsonResponse($result);
    }

    public function removeCard(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;
        $user= JWTAuth::touser($request->header('authorization'));
        $rules = array(
            'user_id'=>'required',
            'card_id'=>'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else if($user && $user->id == $request->user_id) {


			$SECRET_KEY = \config('admin.stripe.SECRET_KEY');
            if ($user->stripe_account_type == "local") {
                $SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
            }

			$savecard = $user->cards()->where("id", $request->card_id)->first();

            if($savecard) {
				$stripe=\Stripe::make($SECRET_KEY);
				 try {
                    $cardRes = $stripe->cards()->delete($user->stripe_id, $savecard->card_id);

					if (isset($cardRes) && $cardRes) {
						$savecard->delete();

						$result['message'] = RT::rtext("success_card_removed");
						$result['code'] = 200;
					} else {
						$result['message'] = RT::rtext("error_default");
					}

                } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
                    add_logs("error","exception_".$request->path(),$e->getMessage(),$e->getCode(),$e->getLine(),$e->getFile());
                    $result['message'] = $e->getMessage();

                }
			}else{
				$result['message'] = RT::rtext("card_does_not_belongs_to_user");
			}
		}else{
			$result['message'] = RT::rtext("warning_user_data_not_found") ;
		}


        return $this->JsonResponse($result);
    }





	//Strip functions


	public function createStripCard($SECRET_KEY,$user,$token)
    {
		$res = ["message"=>"","code"=>400,'data'=>""];
		$stripe=\Stripe::make($SECRET_KEY);

		try {

		   $cardRes = $stripe->cards()->create($user->stripe_id, $token);
		   $res['code'] = 200;


		   $customerupdate = $stripe->customers()->update($user->stripe_id, ['default_source' => $cardRes['id']]);

		    $cardRes['default'] = 1;
			$user->cards()->update(['default'=>0]);
            $saved_card = Cards::saveCard($cardRes, $user->stripe_id);
            $res['data'] = $saved_card;

        } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
            add_logs("error","exception_"."createStripCard",$e->getMessage(),$e->getCode(),$e->getLine(),$e->getFile());
                $res['message'] =  $e->getMessage();

                $stripe->customers()->delete($user->stripe_id);
                $user->forceDelete();
		}

		return $res;
	}

	public function createStripCustomer($SECRET_KEY,$user)
    {
		$res = ["message"=>"","code"=>400,'data'=>""];
		$stripe=\Stripe::make($SECRET_KEY);

		try {
            $customer = $stripe->customers()->create([
                'email' => $user->email,
            ]);

			$user->stripe_id = $customer['id'];
			$user->save();

			$res['code'] = 200;
			$res['data'] = $customer;

        } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
            add_logs("error","exception_"."createStripCustomer",$e->getMessage(),$e->getCode(),$e->getLine(),$e->getFile());
			$res['message'] = $e->getMessage();
			$user->forceDelete();
		}

		return $res;
	}


}
