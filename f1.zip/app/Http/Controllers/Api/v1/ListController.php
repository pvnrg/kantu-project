<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use JWTAuth;
use App\Images;
use App\Blog;
use App\Faq;
use App\Plan;
use PushNotification;
use App\Notification ;
use App\ResponseText as RT;

class ListController extends Controller
{
    //


    public function testNotification(Request $request){

        $data = [];
        $message = "";
        $status = true;
        $validation = [];
        $code = 200;

        if($request->has('device_token') &&  $request->device_token != ""){

            $push = PushNotification::setService('fcm')->setMessage([
                'notification' => [
                    'title' => $request->title,
                    'body' => $request->body,
                        'sound' => 'default',
                        ],
                'data' => [ 'extraPayLoad' => $request->payload ]
                ])
            ->setDevicesToken([$request->device_token])
            ->send()
            ->getFeedback();


            $data = $push ;
            if($push->success == 1){

                $message = "Notification sent successfully!";
            }
        }

        return response()->json(['status'=> $status,'data' => $data, 'message' => $message, 'validation' => $validation,'code'=>$code]);
        exit;
    }

    public function getImageList(Request $request){

        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $images = Images::all()->makeHidden('safety_img');

        $result['data'] =  [ 'safety_images' => $images  ] ;
        $result['code'] = 200 ;

        return $this->JsonResponse($result);
    }

    public function getBlogList(Request $request){

        $result = ["message"=>"","code"=>400 ,"data"=>[]] ;

        $per_page = ( $request->has('per_page') && $request->per_page != "" && $request->per_page > 0 ) ?  $request->per_page : \config('settings.PER_PAGE_DATA') ;

        $blogs = Blog::whereStatus(1)->whereType('blog')->whereHas('blog_img')->orderBy('id',$request->get('order_by','DESC'))->paginate($per_page );

        if( count($blogs) == 0 ){
            $result['message'] = RT::rtext("warning_no_data_found") ;
        }else{
            $result['data'] =  $blogs ;
            $result['message'] = 'Blogs list' ;
            $result['code'] = 200;
        }

        return $this->JsonResponse($result);
    }

    public function getBlog(Request $request, $slug){

        $result = ["message"=>"","code"=>400 ,"data"=>[]] ;

        $blog=Blog::whereSlug($slug)->whereType('blog')->first();

        if($blog)
        {
            $result['data'] =  make_null($blog);
            $result['code'] = 200;
            $result['message'] = RT::rtext("success_default") ;
        }else{
            $result['message'] = RT::rtext("warning_no_data_found") ;
        }

        return $this->JsonResponse($result);
    }

    public function getPageList(Request $request){

        $result = ["message"=>"","code"=>400 ,"data"=>[]] ;

        $per_page = ( $request->has('per_page') && $request->per_page != "" && $request->per_page > 0 ) ?  $request->per_page : \config('settings.PER_PAGE_DATA') ;

        $pages = Blog::whereStatus(1)->whereType('page')->whereHas('blog_img')->paginate($per_page);

        if( count($pages) == 0 ){
            $result['message'] = RT::rtext("warning_no_data_found") ;
        }else{
            $result['data'] =  $pages ;
            $result['message'] = RT::rtext("success_default") ;
            $result['code'] = 200;
        }

        return $this->JsonResponse($result);
    }

    public function getPage(Request $request, $slug){

        $result = ["message"=>"","code"=>400 ,"data"=>[]] ;

        $page=Blog::whereSlug($slug)->whereType('page')->first();

        if($page)
        {
            $result['data'] =  make_null($page); ;
            $result['code'] = 200;
            $result['message'] = RT::rtext("success_default") ;
        }else{
            $result['message'] = RT::rtext("warning_no_data_found") ;
        }

        return $this->JsonResponse($result);
    }


    public function getFaqList(Request $request){

        $result = ["message"=>"","code"=>400 ,"data"=>[]] ;

        $per_page = ( $request->has('per_page') && $request->per_page != "" && $request->per_page > 0 ) ?  $request->per_page : \config('settings.PER_PAGE_DATA') ;

        $faqs = Faq::whereStatus('active')->orderby("display_order","ASC")->paginate($per_page);

        if( count($faqs) == 0 ){
            $result['message'] = RT::rtext("warning_no_data_found") ;
        }else{
            $result['data'] =  $faqs ;
            $result['message'] = RT::rtext("success_default") ;
            $result['code'] = 200;
        }

        return $this->JsonResponse($result);
    }

    public function getPlanList(Request $request){

        $result = ["message"=>"","code"=>400 ,"data"=>[]] ;

        $per_page = ( $request->has('per_page') && $request->per_page != "" && $request->per_page > 0 ) ?  $request->per_page : \config('settings.PER_PAGE_DATA') ;

        $plans = Plan::whereStatus(1)->paginate($per_page);

        if( count($plans) == 0 ){
            $result['message'] = RT::rtext("warning_no_data_found") ;
        }else{
            $result['data'] =  $plans ;
            $result['message'] = RT::rtext("success_default");
            $result['code'] = 200;
        }

        return $this->JsonResponse($result);
    }

    public function getNotificationList(Request $request){

        $result = ["message"=>"","code"=>400 ,"data"=>[]] ;

        $per_page = ( $request->has('per_page') && $request->per_page != "" && $request->per_page > 0 ) ?  $request->per_page : \config('settings.PER_PAGE_DATA') ;

        $user= JWTAuth::touser($request->header('authorization'));

        if(!$user){
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }else{

            $notifications = $user->notifications()->paginate($per_page);

            if( count($notifications) == 0 ){
                $result['message'] = RT::rtext("warning_no_data_found") ;
            }else{
                $result['data'] =  $notifications ;
                $result['message'] = RT::rtext("success_default");
                $result['code'] = 200;
            }

        }
        return $this->JsonResponse($result);
    }

    public function updateNotification(Request $request ){

        $result = ["message"=>"","code"=>400 ,"data"=>[]] ;

        $rules = array(
            'notification_id' => 'required',
        );

        $validator = \Validator::make($request->all(), $rules,[]);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else{

            $user= JWTAuth::touser($request->header('authorization'));

            if(!$user){
                $result['message'] = RT::rtext("warning_user_data_not_found") ;
            }else{

                $update = false ;
                $ids = explode(",",$request->notification_id);
                if( $ids ){
                    $user->notifications()->whereIn('id', $ids)->update(['read_flag' => 1]) ? $update = true : $update = false ;
                }
                if( $request->notification_id == "all" ){
                    $user->notifications()->update(['read_flag' => 1]) ? $update = true : $update = false ;
                }

                if(!$update){
                    $result['message'] = RT::rtext("error_default");
                }else{
                    $result['message'] = RT::rtext("success_default");
                }
                $result['code'] = 200;

            }

        }

        return $this->JsonResponse($result);
    }
}
