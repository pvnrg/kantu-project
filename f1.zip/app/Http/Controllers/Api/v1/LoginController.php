<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Tymon\JWTAuth\Exceptions\JWTException;
use JWTAuth;
use Hash;
use Session;
use Carbon\Carbon;
use App\User;
use App\Settings;
use App\ResponseText as RT;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[] ] ;

        $rules = array(
            'email' => 'required|email',
            'password'=>'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else {
            $input = $request->only('email', 'password');
            $jwt_token = null;
            $user = User::where("email", $request->email)->withTrashed()->with('roles')->first();

            if ($user) {
                if ($user->hasRole("User")) {
                    if (Hash::check($request->password, $user->password)) {
						if ($request->has('firebase_token')) {
							$user->firebase_token = $request->firebase_token;
                        }
                        if ($request->has('device_token')) {
							$user->device_token = $request->device_token;
						}
						if ($request->has('device_type')) {
							$user->device_type = $request->device_type;
						}
						$user->save();
						$jwt_token = JWTAuth::attempt($input, ['exp' =>Carbon::now()->addDays(7)->timestamp]);

                        $user['token']=$jwt_token;

                        $user = collect($user)->except(array_merge(['roles'],\config('settings.api_parms.remove_extra_user_param')));

                        $user = make_null($user);

                        if ($user['status'] == "active" && $jwt_token) {
                            	$result['data'] = $user;
                                $result['code'] = 200;

                                $result['message'] = RT::rtext("success_login") ;

                        } else {
							// Web user
							if(RESPONSE_ERROR_CODE == 400){
								$result['data'] = $user;
                                $result['code'] = 200;
							}
                            $result['message'] = RT::rtext('warning_your_account_not_activated_yet') ;
                        }
                    } else {
                        $result['message'] = RT::rtext('warning_incorrect_email_or_password') ;
                    }
                } else {
                    $result['message'] = 'User has not app profile.' ;
                }
            } else {
                $result['message'] = RT::rtext('email_is_not_registered') ;
            }
        }

        return $this->JsonResponse($result);
    }

    public function logout(Request $request)
    {
		$result = ["message"=>"","code"=>400,"data"=>[]] ;

        try {
            JWTAuth::invalidate($request->header('authorization'));
            $result['message'] =  RT::rtext('success_logout') ;
			$result['code'] = 200;
        } catch (JWTException $exception) {
            $result['message'] = 'Sorry, the user cannot be logged out.' ;
            $result['code'] = 200;
        }

        return $this->JsonResponse($result);
    }


    public function forgotPassword(Request $request) 
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        if (isset($request->email)) {
            $user=User::where('email', $request->email)->first();
            if ($user) {
                $otp = substr(number_format(time() * rand(), 0, '', ''), 0, 6);
                $user->otp = $otp;
                $user->save();

                // $subject = RT::rtext('mail_subject_reset_password');
                // \Mail::send('email.forgot-password', compact('user'), function ($message) use ($user, $subject) {
                //     $message->to($user->email)->subject($subject);
                // });

                $result['data'] = [ 'email' => $user->email, 'otp' => $otp ] ;
				$result['code'] = 200;
                $result['message'] = RT::rtext('password_reset_otp_has_been_sent_to_email') ;
            } else {
                $result['message'] = RT::rtext("your_have_entered_worng_otp") ;
            }
        } else {
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }

        return $this->JsonResponse($result);
    }

    public function confirmOTP(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $rules = array(
            'otp'=>'required',
            'email' => 'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        } else {
			$user=User::where('email', $request->email)->first();
			if ($user) {
				if ($user->otp == $request->otp) {
					$result['data']= [
						'email' => $user->email ,
						'otp' => $user->otp
					];
                    $result['message'] =  RT::rtext("Confirmation Success!") ;
                    $result['code'] = 200 ;
				} else {
					$result['message'] = RT::rtext("your_have_entered_worng_otp") ;
				}
			} else {
				$result['message'] = RT::rtext("warning_user_data_not_found") ;
			}
		}

        return $this->JsonResponse($result);
	}

    public function resetPassword(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $rules = array(
            'email' => 'required',
            'otp'=>'required',
            'password'=>'required',
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else{
			$user=User::where('email', $request->email)->first();

			if ($user) {
				if ($user->otp === $request->otp) {
					$user->otp = null;
					$user->password = bcrypt($request->password);
					$user->save();
					$result['code'] = 200;
					$result['message'] =  RT::rtext("success_password_changed") ;
				} else {
					$result['message'] = RT::rtext("your_have_entered_worng_otp") ;
				}
			} else {
				$result['message'] = RT::rtext("warning_user_data_not_found") ;
			}
		}

        return $this->JsonResponse($result);
    }

    public function changePassword(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $rules = array(
            'email' => 'required|email',
            'password'=>'required|same:confirm_password',
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else{

			$user=JWTAuth::touser($request->header('authorization'));

			if ($user != null && $user->email == $request->email) {
				$user->password=Hash::make($request->password);
				$user->save();

				$result['code'] = 200;
				$result['message'] =  RT::rtext("success_password_changed") ;
			} else {
				$result['message'] =  RT::rtext("warning_user_data_not_found") ;
			}
		}

        return $this->JsonResponse($result);
    }
}
