<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Rolls;
use App\User;
use App\Setting;
use App\Plan;
use JWTAuth;
use Carbon\Carbon as Carbon;
use DB;
use App\Connection;
use App\Notification;

use App\Jobs\SendEmailJob;
use App\ResponseText as RT;

class ConnectionController extends Controller
{
	public function sendRequset(Request $request){
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

    	$rules = array(
            'batch_id' => 'required',
        );

        $validator = \Validator::make($request->all(), $rules, []);
        $user= JWTAuth::touser($request->header('authorization'));

        if ($validator->fails())
        {
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else if($user->batch_id == $request->batch_id){
            $result['message'] = RT::rtext("warning_user_not_found_for_given_badge");
        }else{
            $touser = User::where('batch_id',$request->batch_id)->first();
            if(!$touser){
                $result['message'] = RT::rtext("warning_user_not_found_for_given_badge");
            }else{

                $exist_count = Connection::where('from_id',$user->id)->where('to_id',$touser->id)->where('status', Connection::STATUS_CONNECTED )->first();
				$exist_count2 = Connection::where('from_id',$touser->id)->where('to_id',$user->id)->where('status',Connection::STATUS_CONNECTED )->first();
                $already_request = Connection::where('from_id',$touser->id)->where('to_id',$user->id)->where('status', Connection::STATUS_REQUEST )->first();

                if($exist_count){
                    $result['message'] = "You have already connected with ".$touser->name;
                }elseif($exist_count2){
                    $result['message'] = "You have already connected with ".$touser->name;
                }elseif($already_request){
                    $result['message'] = "You have already pending connection request from ".$touser->name;
                }else{

                    $message = [ 'title' => $touser->name,
                                'body' => "Badge Request from ".$user->name,
                                'sound' => 'default',
                                "target_screen" => "user_profile",
                                "user_id" => $user->id
                               // "other"=>["sender"=>$user,"receiver"=>$touser],
                                ] ;

                    if( ($user->device_type == "android" || $user->device_type == "ios" ) && $user->device_token != ""){
                        send_notification($user->device_token, $message );
                    }
                    Notification::create([
                        'sender_id' => $user->id ,
                        'receiver_id' => $touser->id,
                        'type' => Notification::CONN_REQUEST_RECEIVED ,
                        'message' => $message['body'],
                        'data' => json_encode( [ 'user_id' => $message['user_id'] ] )
                    ]);

                    $delete = Connection::where('from_id',$user->id)->where('to_id',$touser->id)->delete();
					$delete2 = Connection::where('from_id',$touser->id)->where('to_id',$user->id)->delete();

                    $new = [
                        "from_id"=>$user->id,
                        "to_id"=>$touser->id,
                        "status"=> Connection::STATUS_REQUEST
                    ];

                    $con = Connection::create($new);

					$mdata = ['action'=>'new_connection','connection'=>$con];
					SendEmailJob::dispatch($mdata)->onConnection('database')->onQueue('emails');

                    try{


                      //  send_sms($touser->country_code,$touser->phone,RT::rtext("sms_child_you_receive_badge_request"));
                      //  send_sms($user->country_code,$user->phone,RT::rtext("sms_child_you_just_request_for_badge"));
                    }catch(\Exception $exception){
                        $message = $exception->getMessage()." -------- AT LINE : ".$exception->getLine()."--------- IN FILE : ". $exception->getFile()."--------Request Url : ".\Request::capture()->getUri();
                        add_logs("error","exception_".$request->path(),$message,$exception->getCode(),$exception->getLine(),$exception->getFile());
                    }

                    $result['message'] = "You have send connection request to ".$touser->name;
                    $result['code'] = 200;
                }



            }
        }

        return $this->JsonResponse($result);
    }

	public function myConnection(Request $request){
        $result = ["message"=>"","code"=>400,"data"=>[]] ;
		$perpage = $request->get('per_page',\config('settings.PER_PAGE_DATA'));

        $user= JWTAuth::touser($request->header('authorization'));

		$connections = Connection::with(["sender","receiver"]);

		if($request->has('status') && $request->status == Connection::STATUS_CONNECTED ){
			$connections->where('connections.status', Connection::STATUS_CONNECTED );
		}
		if($request->has('status') && $request->status == Connection::STATUS_REQUEST_SEND ){
			$connections->where('from_id',$user->id);
			$connections->where('connections.status', Connection::STATUS_REQUEST );
		}
		if($request->has('status') && $request->status == Connection::STATUS_REQUEST_RECEIVED ){
			$connections->where('to_id',$user->id);
			$connections->where('connections.status',Connection::STATUS_REQUEST );
		}
		if($request->has('status') && $request->status == Connection::STATUS_DECLINE_SEND ){
			$connections->where('from_id',$user->id);
			$connections->where('connections.status',Connection::STATUS_DECLINE);
		}
		if($request->has('status') && $request->status == Connection::STATUS_DECLINE_RECEIVED ){
			$connections->where('to_id',$user->id);
			$connections->where('connections.status', Connection::STATUS_DECLINE );
        }

        $connections = $connections->where(function($q)use($user){
            $q->where('from_id',$user->id)->orWhere('to_id',$user->id) ;
        })->paginate($perpage);

		$connections = make_null($connections);
        $cusers = $connections['data'];

        $remove_param = ['updated_at', 'deleted_at', 'status' ] ;

		for($i = 0; $i<count($cusers); $i++){

			if($cusers[$i]['status'] == Connection::STATUS_CONNECTED ){
				$cusers[$i]['connection_status'] = Connection::STATUS_CONNECTED ;
			}
			if($cusers[$i]['status'] == "request" && $cusers[$i]['from_id'] == $user->id){
				$cusers[$i]['connection_status'] = Connection::STATUS_REQUEST_SEND ;
			}
			if($cusers[$i]['status'] == "request" && $cusers[$i]['to_id'] == $user->id){
				$cusers[$i]['connection_status'] = Connection::STATUS_REQUEST_RECEIVED ;
			}
			if($cusers[$i]['status'] == "decline" && $cusers[$i]['from_id'] == $user->id){
				$cusers[$i]['connection_status'] = Connection::STATUS_DECLINE_SEND  ;
			}
            if ($cusers[$i]['status'] == "decline" && $cusers[$i]['to_id'] == $user->id) {
                $cusers[$i]['connection_status'] = Connection::STATUS_DECLINE_RECEIVED ;
            }

            $cusers[$i] =  collect($cusers[$i])->except($remove_param);
            $sender =  collect($cusers[$i]['sender'])->only(\config('settings.api_parms.connectionuser'));
            $receiver =  collect($cusers[$i]['receiver'])->only(\config('settings.api_parms.connectionuser'));

            // if($request->has('status') && ( $request->status == Connection::STATUS_CONNECTED || $request->status == Connection::STATUS_REQUEST_RECEIVED  ) ){
                $cusers[$i]['user'] =  ( $cusers[$i]['from_id'] ==  $user->id ) ? $receiver : $sender ;
                $cusers[$i] =  collect($cusers[$i])->except(['sender','receiver']);
            // }else{
            //     $cusers[$i]['sender'] = $sender ;
            //     $cusers[$i]['receiver'] = $receiver ;
            // }

		}

		$connections['data'] = $cusers;

		$result['data'] = $connections;
        $result['message'] = "";
        $result['code'] = 200;


        return $this->JsonResponse($result);
    }
	public function myConnectionDetail(Request $request){
        $result = ["message"=>"","code"=>400,"data"=>[]] ;
		$user= JWTAuth::touser($request->header('authorization'));

		$rules = array(
            'connection_id' => 'required',
        );

        $validator = \Validator::make($request->all(), $rules, []);
        $user= JWTAuth::touser($request->header('authorization'));

        if ($validator->fails())
        {
            $msgArr = $validator->messages()->toArray();
			$result['message'] = reset($msgArr)[0];
		}else{

			$connection = Connection::with(["sender","receiver"])->where("id",$request->connection_id)->where(function($q)use($user){
                $q->where('from_id',$user->id)->orWhere('to_id',$user->id);
            })->first();

			if($connection){
				$connection = make_null($connection);

				if($connection['status'] == Connection::STATUS_CONNECTED ){
					$connection['connection_status'] = Connection::STATUS_CONNECTED  ;
				}
				if($connection['status'] == "request" && $connection['from_id'] == $user->id){
					$connection['connection_status'] = Connection::STATUS_REQUEST_SEND ;
				}
				if($connection['status'] == "request" && $connection['to_id'] == $user->id){
					$connection['connection_status'] = Connection::STATUS_REQUEST_RECEIVED ;
				}
				if($connection['status'] == "decline" && $connection['from_id'] == $user->id){
					$connection['connection_status'] = Connection::STATUS_DECLINE_SEND ;
				}
				if($connection['status'] == "decline" && $connection['to_id'] == $user->id){
					$connection['connection_status'] = Connection::STATUS_DECLINE_RECEIVED  ;
				}

				$connection['sender'] = collect($connection['sender'])->only(\config('settings.api_parms.connectionuser'));
				$connection['receiver'] = collect($connection['receiver'])->only(\config('settings.api_parms.connectionuser'));

				$result['data'] = $connection;
				$result['code'] = 200;
			}else{
				$result['message'] = RT::rtext("warning_no_data_found");
			}
		}

		return $this->JsonResponse($result);
    }

	public function actionOnRequest(Request $request){
		$result = ["message"=>"","code"=>400,"data"=>[]] ;

		$rules = array(
            'connection_id' => 'required',
            'action' => 'required|in:'.Connection::STATUS_ACCEPT.','.Connection::STATUS_DECLINE.','.Connection::STATUS_CANCELLED,
        );

        $validator = \Validator::make($request->all(), $rules, []);
        $user= JWTAuth::touser($request->header('authorization'));

        if ($validator->fails())
        {
            $msgArr = $validator->messages()->toArray();
			$result['message'] = reset($msgArr)[0];
		}else{
            $connection = Connection::with(["sender","receiver"])->where("id",$request->connection_id)
            ->where(function($q)use($user){
                $q->where('from_id',$user->id)->orWhere('to_id',$user->id);
            })->first();
			if($connection){

				if($connection->to_id == $user->id && $request->action == Connection::STATUS_ACCEPT && $connection->status == Connection::STATUS_REQUEST ){
					$connection->status = Connection::STATUS_CONNECTED ;
                    $result['message'] = RT::rtext("success_you_have_accepted_request");


				}else if($connection->to_id == $user->id && $request->action == Connection::STATUS_DECLINE && $connection->status == Connection::STATUS_REQUEST ){
					$connection->status = Connection::STATUS_DECLINE ;
                    $result['message'] = RT::rtext("success_you_have_declined_request");

				}
				else if($connection->from_id == $user->id && $request->action == Connection::STATUS_CANCELLED && $connection->status == Connection::STATUS_REQUEST ){
					$connection->status = Connection::STATUS_CANCELLED ;
                    $result['message'] = RT::rtext("success_you_have_cancelled_request");


				}
				if($result['message'] != ""){
					$mdata = ['action'=>'action_connection','connection'=>$connection];
                    SendEmailJob::dispatch($mdata)->onConnection('database')->onQueue('emails');

                    if($connection->to_id == $user->id && $connection->sender ){

                         // notify to sender user
                        $message = [ 'title' => $connection->sender->name,
                            'body' => "Badge Request has been {$request->action}ed by {$connection->receiver->name}",
                            'sound' => 'default',
                            "target_screen" => "user_profile",
                            "user_id" => $connection->receiver->id
                        ] ;

                        if (($connection->sender->device_type == "android" || $connection->sender->device_type == "ios") && $connection->sender->device_token != "") {
                            send_notification($connection->sender->device_token, $message);
                        }
                        Notification::create([
                            'sender_id' => $connection->receiver->id ,
                            'receiver_id' =>  $connection->sender->id,
                            'type' => Notification::CONN_REQUEST_ACTION ,
                            'message' => $message['body'],
                            'data' => json_encode( [ 'user_id' => $message['user_id'] ] )
                        ]);

                    }

                    $result['code'] = 200;
				    $connection->save();
				}else{
                    $result['message'] = 'Connection is already '.$connection->status;
                }

			}else{
				$result['message'] = RT::rtext("warning_no_data_found");
			}
		}

		return $this->JsonResponse($result);
    }

    public function getConnectedUserProfile(Request $request,$id)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user = JWTAuth::touser($request->header('authorization'));

        if(!$user){
            $result['message'] = RT::rtext("warning_user_data_not_found");
        }else{
            $connection = $user->connect_to()->with('sender')->whereHas('sender')->where('from_id',$id)->first();
            if(!$connection){
                $connection = $user->connect_from()->with('receiver')->whereHas('receiver')->where('to_id',$id)->first() ;
            }
            if(!$connection){
                $result['message'] = RT::rtext("warning_no_data_found");
            }else{
                $connected_user = $connection->connected_user($user->id) ;
                $connected_user = collect($connected_user)->except(\config('settings.api_parms.remove_extra_user_param'));
                $result['data'] = make_null($connected_user);
                $result['code'] = 200;
            }
        }

        return $this->JsonResponse($result);
    }



}
