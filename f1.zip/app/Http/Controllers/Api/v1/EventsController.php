<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Tymon\JWTAuth\Exceptions\JWTException;
use JWTAuth;
use App\Events ;
use App\EventsUsers ;
use App\ResponseText as RT;
use Carbon\Carbon;
use App\Images ;
use App\EventsImages;
use App\User;
use App\Notification;

class EventsController extends Controller
{
    //
    public function add(Request $request){


        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'user_id' => 'required',
            'title' => 'required|max:255',
            'description' => 'required',
            'start_date' => 'required|date_format:Y-m-d|after:'.Carbon::now()->format('Y-m-d'),
            'end_date' => 'required|date_format:Y-m-d|after:'.Carbon::parse($request->start_date)->subDay(1),
            'address' => 'required|max:255',
            'invite_user_id' => 'required'
        );

        if( Carbon::parse($request->start_date)->eq(Carbon::parse($request->end_date)) ){
            $rules['start_time'] =  'required|date_format:H:i' ;
            $rules['end_time'] = 'required|date_format:H:i|after:start_time' ;
        }

        $validator = \Validator::make($request->all(), $rules,[]);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else if($user && $user->id == $request->user_id) {

            $insert_data = $request->except('user_id','invite_user_id') ;
            $insert_data['status'] = Events::STATUS_NEW ;
            $event = Events::create($insert_data);
            if($event){
                if($request->has('invite_user_id') && $request->get('invite_user_id') != ""){
                    $invite_user_id = explode(',',$request->get('invite_user_id'));
                    foreach($invite_user_id as $users_id){

                        EventsUsers::create([
                            'events_id' => $event->id ,
                            'request_by' => $event->created_by ,
                            'users_id' => $users_id ,
                            'user_role' => 'user',
                            'approval_status' => EventsUsers::STATUS_REQUEST,
                        ]);

                        // send notification to user about event invite
                        $notify_user = User::find($users_id);
                        if($notify_user ){

                            $message = [ 'title' => $notify_user->name,
                                'body' => "{$user->name} has sent you an event invite.",
                                'sound' => 'default',
                                "target_screen" => "event_detail",
                                "event_id" => $event->id
                            ];

                            if(($notify_user->device_type == "android" || $notify_user->device_type == "ios") && $notify_user->device_token != ""){
                                send_notification($notify_user->device_token, $message);
                            }
                            Notification::create([
                                'sender_id' =>  $user->id ,
                                'receiver_id' =>  $notify_user->id ,
                                'type' => Notification::EVENT_INVITE_RECEIVED ,
                                'message' => $message['body'],
                                'data' => json_encode( [ 'event_id' => $message['event_id'] ] )
                            ]);

                        }


                    }
                }


                $result['data'] = [ 'event_id' => $event->id ];
                $result['code'] = 200;
                $result['message'] = RT::rtext("success_event_created") ;
            }else{
                $result['message'] = RT::rtext("warning_event_not_created") ;
            }
		}else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }

		return $this->JsonResponse($result);

    }

    public function incoming(Request $request){

        $result = ["message"=>"","code"=>400,"data"=>[]] ;
        $per_page = ( $request->has('per_page') && $request->per_page != "" && $request->per_page > 0 ) ?  $request->per_page : \config('settings.PER_PAGE_DATA') ;
        $user= JWTAuth::touser($request->header('authorization'));
        if($user){

            $events = Events::where('status', Events::STATUS_NEW )->whereHas('user')->whereHas('events_users', function($q)use($user){
                $q->where('users_id', $user->id)->orWhere('request_by', $user->id);
            })->latest()->paginate($per_page);

            $data = [] ; $i = 0 ;  $dates = [];
            foreach($events as $event){
                $date = $event->created_at->format('m-d-Y');
                $event_array = [
                    'event_id' => $event->id ,
                    'event_title' =>  $event->title ,
                    'location' => $event->location ,
                    'created_by' => $event->created_by ,
                    'created_by_name' => $event->user->first_name ,
                    'user_id' => $event->events_users->users_id ,
                    'user_name' => $event->events_users->user_name ,
                    'time' => $event->event_time  ,
                    'date' => $event->event_date ,
                    'event_status' =>  $event->event_status($user->id) ,
                    'mark_complete' => $event->events_images()->where('user_id', $user->id)->where('status', Events::STATUS_COMPLETED )->first() ?  true : false
                ];
                if(isset($dates[$date])){
                    $data[$dates[$date]]['data'][] = $event_array ;
                }else{
                    $dates[$date] = $i;
                    $data[$i]['title'] = $date;
                    $data[$i]['data'][] = $event_array ;
                    $i++;
                }
            }

            $result['data'] = make_null($events) ;
            if(isset($result['data']['data'])){
                 $result['data']['incoming_events'] = $data;
                unset($result['data']['data']);
            }

            $result['message'] = "Incoming events list" ;
            $result['code'] = 200;
        }else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }
        return $this->JsonResponse($result);

    }

    public function completed(Request $request){

        $result = ["message"=>"","code"=>400,"data"=>[]] ;
        $per_page = ( $request->has('per_page') && $request->per_page != "" && $request->per_page > 0 ) ?  $request->per_page : \config('settings.PER_PAGE_DATA') ;
        $user= JWTAuth::touser($request->header('authorization'));
        if($user){
            $events = Events::where('status', Events::STATUS_COMPLETED )->whereHas('user')->whereHas('events_users', function($q)use($user){
                $q->where('users_id', $user->id)->orWhere('request_by', $user->id);
            })->latest()->paginate($per_page);
            $data = [] ; $i = 0 ; $dates = [];
            foreach($events as $event){
                $date = $event->created_at->format('m-d-Y');
                $event_array = [
                    'event_id' => $event->id ,
                    'event_title' =>  $event->title ,
                    'location' => $event->location ,
                    'created_by' => $event->created_by ,
                    'created_by_name' => $event->user->first_name ,
                    'user_id' => $event->events_users->users_id ,
                    'user_name' => $event->events_users->user_name ,
                    'time' => $event->event_time  ,
                    'date' => $event->event_date ,
                    'event_status' =>  $event->event_status($user->id) ,
                    'mark_complete' =>  $event->events_images()->where('user_id', $user->id)->where('status', Events::STATUS_COMPLETED )->first() ? true : false
                ];
                if(isset($dates[$date])){
                    $data[$dates[$date]]['data'][] = $event_array ;
                }else{
                    $dates[$date] = $i;
                    $data[$i]['title'] = $date;
                    $data[$i]['data'][] = $event_array ;
                    $i++;
                }
            }

            $result['data'] = make_null($events) ;
            if(isset($result['data']['data'])){
                 $result['data']['completed_events'] = $data;
                unset($result['data']['data']);
            }

            $result['message'] = "Completed events list" ;
            $result['code'] = 200;
        }else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }
        return $this->JsonResponse($result);

    }

    public function all(Request $request){

        $result = ["message"=>"","code"=>400,"data"=>[]] ;
        $per_page = ( $request->has('per_page') && $request->per_page != "" && $request->per_page > 0 ) ?  $request->per_page : \config('settings.PER_PAGE_DATA') ;
        $user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'selected_date'=>'date_format:Y-m-d'
        );

        $validator = \Validator::make($request->all(), $rules,[]);

        if ($validator->fails()) {

            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];

        }elseif($user){

            $selected_date = ( $request->has('selected_date') && $request->selected_date != '' ) ? $request->selected_date : null ;

            $connected_user_id = ( $request->has('connected_user_id') && $request->connected_user_id != '' ) ? $request->connected_user_id : null ;

            $events = Events::whereHas('user')->whereHas('events_users', function($q)use($user){
                $q->where('users_id', $user->id)->orWhere('request_by', $user->id);
            });

            if( $selected_date ){
                $events = $events->where(function($q1)use($selected_date){
                    $q1->where('start_date', $selected_date )
                    ->orWhere('end_date', $selected_date );
                });
            }
            if($connected_user_id){
                $events = $events->whereHas('events_users',function($q2)use($connected_user_id){
                    $q2->where('users_id',$connected_user_id)->orWhere('request_by',$connected_user_id);
                });
            }

            $events =  $events->latest()->paginate($per_page);
            $event_array = [] ;  $selected_date_events = [];  $connected_user_events = [] ;
            $data = [] ; $i = 0 ; $dates = [];
            foreach($events as $event){
                $date = $event->created_at->format('m-d-Y');
                $event_array = [
                    'event_id' => $event->id ,
                    'event_title' =>  $event->title ,
                    'location' => $event->location ,
                    'created_by' => $event->created_by ,
                    'created_by_name' => $event->user->first_name ,
                    'user_id' => $event->events_users->users_id ,
                    'user_name' => $event->events_users->user_name ,
                    'time' => $event->event_time  ,
                    'date' => $event->event_date ,
                    'event_status' =>  $event->event_status($user->id) ,
                    'mark_complete' =>  $event->events_images()->where('user_id', $user->id)->where('status', Events::STATUS_COMPLETED )->first() ? true : false
                ];
                if(isset($dates[$date])){
                    $data[$dates[$date]]['data'][] = $event_array ;
                }else{
                    $dates[$date] = $i;
                    $data[$i]['title'] = $date;
                    $data[$i]['data'][] = $event_array ;
                    $i++;
                }
                $selected_date ? $selected_date_events[] = $event_array : '' ;
                $connected_user_id ? $connected_user_events[] = $event_array : '' ;
            }

            $result['data'] = make_null($events) ;
            if(isset($result['data']['data'])){
                $result['data']['events'] = $selected_date ? $selected_date_events : ($connected_user_id ? $connected_user_events : $data) ;
                unset($result['data']['data']);
            }
            $result['message'] = "All events list" ;
            $result['code'] = 200;
        }else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }
        return $this->JsonResponse($result);

    }

    public function update(Request $request, $id){

        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'title' => 'max:255',
            'start_date' => 'required|date_format:Y-m-d',
            'end_date' => 'required|date_format:Y-m-d|after:'.Carbon::parse($request->start_date)->subDay(1),
            'address' => 'max:255',
        );

        if( Carbon::parse($request->start_date)->eq(Carbon::parse($request->end_date)) ){
            $rules['start_time'] =  'required|date_format:H:i' ;
            $rules['end_time'] = 'required|date_format:H:i|after:start_time' ;
        }

        $validator = \Validator::make($request->all(), $rules,[]);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else if($user ) {
            $event = $user->events()->whereId($id)->first();
            if($event){

                $update['title'] = ($request->title)?$request->title:$event->title ;
                $update['description'] = ($request->description)?$request->description:$event->description ;
                $update['start_time'] = ($request->start_time)?$request->start_time:$event->start_time ;
                $update['end_time'] = ($request->end_time)?$request->end_time:$event->end_time ;
                $update['start_date'] = ($request->start_date)?$request->start_date:$event->start_date ;
                $update['end_date'] = ($request->end_date)?$request->end_date:$event->end_date ;
                $update['address'] = ($request->address)?$request->address:$event->address ;
                $update['city'] = ($request->city)?$request->city:$event->city ;
                $update['state'] = ($request->state)?$request->state:$event->state ;
                $update['updated_by'] = $user->id  ;
                $event->update($update);

                $result['data'] = [ 'event_id' => $event->id ];
                $result['code'] = 200;
                $result['message'] = RT::rtext("success_event_updated") ;
            }else{
                $result['message'] = RT::rtext("warning_event_not_found_might_be_deleted") ;
            }
		}else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }

		return $this->JsonResponse($result);

    }

    public function view(Request $request, $event_id){

        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));

        if($user){

            $event = $user->events()->where('id',$event_id)->whereHas('events_users')->first();
            if(!$event){
                $event = $user->invite_events()->where('events_id',$event_id)->first() ;
            }
            if(!$event){
                $result['message'] = RT::rtext("warning_event_not_found_might_be_deleted");
            }else{
                $event->user_id =  $event->events_users->users_id  ;
                $event->user_name =  $event->events_users->user_name ;
                $event->user_batch = $event->events_users->connected_user ? $event->events_users->connected_user->batch_id : '' ;
                $event->user_profile_image = $event->events_users->connected_user->profile_pic ? : '' ;
                $event->user_location = $event->events_users->connected_user->location ? : '' ;
                $event->user_connection_time = $event->events_users->created_at ;
                $event->time = $event->event_time  ;
                $event->date = $event->event_date ;
                $event->status =  $event->event_status($user->id) ;
                $event = collect($event)->except(['pivot', 'events_users', 'updated_at', 'updated_by' , 'deleted_at']);
                $result['data'] = make_null($event);
                $result['code'] = 200;
                $result['message'] = RT::rtext("success_default") ;
            }
        }else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }

        return $this->JsonResponse($result);

    }

    public function acceptInvite(Request $request, $event_id){

        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'approval_status'=>'required|in:'.EventsUsers::STATUS_ACCEPT.','.EventsUsers::STATUS_DECLINE,
        );

        $validator = \Validator::make($request->all(), $rules,[]);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }elseif($user){

            $event = $user->invite_events()->where('events_id',$event_id)->first() ;

            if(!$event){

                $result['message'] = RT::rtext("warning_event_not_found_might_be_deleted");

            }elseif($event && $event->events_users && $event->events_users->approval_status == EventsUsers::STATUS_REQUEST ){

                $event->events_users->update([ 'approval_status' => $request->approval_status  ]);

                // send notification to user about event invite
                $notify_user = $event->user ;
                if($notify_user){

                    $message = [ 'title' => $notify_user->name,
                        'body' => "{$user->name} has {$request->approval_status}ed your event invite.",
                        'sound' => 'default',
                        "target_screen" => "event_detail",
                        "event_id" => $event->id
                    ];

                    if( ($notify_user->device_type == "android" || $notify_user->device_type == "ios") && $notify_user->device_token != "" ){
                        send_notification($notify_user->device_token, $message);
                    }
                    Notification::create([
                        'sender_id' =>  $user->id ,
                        'receiver_id' =>  $notify_user->id ,
                        'type' => Notification::EVENT_INVITE_ACTION ,
                        'message' => $message['body'],
                        'data' => json_encode( [ 'event_id' => $message['event_id'] ] )
                    ]);

                }

                $result['data'] = [ 'event_id' => $event_id ];
                $result['code'] = 200;
                $result['message'] = RT::rtext("success_default") ;

            }else{
                $result['message'] = RT::rtext("error_default") ;
            }
        }else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }

        return $this->JsonResponse($result);

    }

    public function setEventImage(Request $request, $event_id){

        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'safe_image_id'=>'required',
            'unsafe_image_id'=>'required',
            'user_id' => 'required'
        );

        $validator = \Validator::make($request->all(), $rules,[]);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }elseif($user && $user->id == $request->user_id ){

            $event = $user->events()->where('id',$event_id)->whereHas('events_users')->first();
            $safe_image = Images::find($request->safe_image_id);
            $unsafe_image = Images::find($request->unsafe_image_id);
            if(!$event){
                $event = $user->invite_events()->where('approval_status', EventsUsers::STATUS_ACCEPT )->where('events_id',$event_id)->first() ;
            }
            if(!$event){
                $result['message'] = RT::rtext("warning_event_not_found_might_be_deleted");

            }if(!$safe_image || !$unsafe_image ){
                $result['message'] = RT::rtext("warning_not_valid_image");

            }elseif($event && $safe_image && $unsafe_image ){

                // check for already exist entry
                EventsImages::where('event_id', $event_id )->where('user_id', $user->id)->delete() ;
                EventsImages::create([
                    'event_id' => $event_id ,
                    'user_id' => $user->id ,
                    'safe_image_id' => $safe_image->id,
                    'unsafe_image_id' => $unsafe_image->id,
                    'status' => 'new'
                ]);
                $result['data'] = [ 'event_id' => $event_id ];
                $result['code'] = 200;
                $result['message'] = RT::rtext("success_default") ;

            }else{
                $result['message'] = RT::rtext("error_default") ;
            }
        }else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }

        return $this->JsonResponse($result);

    }

    public function invites(Request $request){

        $result = ["message"=>"","code"=>400,"data"=>[]] ;
        $per_page = ( $request->has('per_page') && $request->per_page != "" && $request->per_page > 0 ) ?  $request->per_page : \config('settings.PER_PAGE_DATA') ;
        $user= JWTAuth::touser($request->header('authorization'));
        if($user){
            $events = Events::where('status', Events::STATUS_NEW)->whereHas('user')->whereHas('events_users', function($q)use($user){
                $q->where('users_id', $user->id)->where('approval_status', EventsUsers::STATUS_REQUEST);
            })->latest()->paginate($per_page);
            $event_array = [] ;
            foreach($events as $event){
                $event_array[] = [
                    'event_id' => $event->id ,
                    'event_title' =>  $event->title ,
                    'location' => $event->location ,
                    'created_by' => $event->created_by ,
                    'created_by_name' => $event->user->first_name ,
                    'user_id' =>  $event->events_users->users_id ,
                    'user_name' =>  $event->events_users->user_name ,
                    'time' => $event->event_time  ,
                    'date' => $event->event_date ,
                    'event_status' =>  $event->event_status($user->id) ,
                ];
            }
            $result['data'] = make_null($events) ;
            if(isset($result['data']['data'])){
                 $result['data']['events'] = $event_array;
                unset($result['data']['data']);
            }
            $result['message'] = "My invite events list" ;
            $result['code'] = 200;
        }else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }
        return $this->JsonResponse($result);

    }


    public function markComplete(Request $request, $event_id){

        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'image_id'=>'required',
            'user_id' => 'required'
        );

        $validator = \Validator::make($request->all(), $rules,[]);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }elseif($user){

            $event = $user->events()->where('id',$event_id)->whereHas('events_users')->first();
            if(!$event){
                $event = $user->invite_events()->where('approval_status', EventsUsers::STATUS_ACCEPT )->where('events_id',$event_id)->first() ;
            }
            if(!$event){
                $result['message'] = RT::rtext("warning_event_not_found_might_be_deleted");

            }elseif($event && $event->event_status($user->id) == Events::STATUS_SCHEDULED  ){

                $image_data = $event->events_images()->where('user_id', $user->id)->first();

                if( $image_data ){

                    $user_status = 'not-matched' ;
                    if($request->image_id == $image_data->safe_image_id){
                        $user_status = 'safe' ;
                    }elseif($request->image_id == $image_data->unsafe_image_id){
                        $user_status = 'unsafe' ;
                    }

                    $image_data->update([
                                'choosen_image_id' => $request->image_id,
                                'choosen_image_on' => Carbon::now(),
                                'user_status'=> $user_status ,
                                'status' => Events::STATUS_COMPLETED
                            ]);

                    if($event->events_images()->where('status', Events::STATUS_COMPLETED)->count()  == 2 ){
                        $event->update( ['status' => Events::STATUS_COMPLETED ]) ;
                    }

                    $result['data'] = [ 'event_id' => $event->id , 'user_status'=>  $image_data->user_status  ];
                    $result['code'] = 200;
                    $result['message'] = RT::rtext("success_event_marked_as_completed") ;

                }else{
                    $result['message'] = RT::rtext("warning_selected_image_data_not_found") ;
                }
            }else{
                $result['message'] = RT::rtext("warning_event_not_scheduled_yet");
            }
        }else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }

        return $this->JsonResponse($result);

    }

    public function calendarEvents(Request $request){

        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'month'=>'integer|between:1,12',
            'year' => 'integer|between:1900,2100'
        );

        $validator = \Validator::make($request->all(), $rules,[]);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];

        }elseif($user){

            $month = $request->has('month') && ( $request->get('month') != ''  ) ?  $request->month : Carbon::now()->month ;

            $year = $request->has('year') && ( $request->get('year') != '' ) ?  $request->year : Carbon::now()->year ;

            $month_name = \DateTime::createFromFormat('!m', $month)->format('F');

            $start = Carbon::createFromFormat('m-Y', $month.'-'.$year)->startOfMonth()->format('Y-m-d')  ;

            $end = Carbon::createFromFormat('m-Y', $month.'-'.$year)->endOfMonth()->format('Y-m-d');

            $dates= [] ;  $colour = 'blue' ;
            $events = Events::whereHas('events_users', function($q)use($user){
                $q->where('users_id', $user->id)->orWhere('request_by', $user->id);
            })->where(function($q1)use($start, $end){
                $q1->whereBetween('start_date', [$start, $end] )
                ->orwhereBetween('end_date', [$start, $end] );
            })->get();

            foreach($events->groupBy('start_date')  as $start_date => $date_events){
                //start date
                $dates[] =  [ $start_date => [ 'selected'=> true, 'marked'=> true, 'selectedColor' => $colour ] ];
            }
            foreach($events->groupBy('end_date')  as $end_date => $date_events){
                //end date
                $dates[] =  [ $end_date => [ 'selected'=> true, 'marked'=> true, 'selectedColor' => $colour ] ];
            }

            if( count($dates) == 0 ){
                $result['message'] = RT::rtext("warning_no_data_found") ;
            }else{
                $result['data'] =  $dates ;
                $result['message'] = RT::rtext("success_default") ;
                $result['code'] = 200;
            }
        }else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }
        return $this->JsonResponse($result);
    }


}
