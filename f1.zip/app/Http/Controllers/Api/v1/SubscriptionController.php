<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use JWTAuth;
use DB;
use Carbon\Carbon as Carbon;
use App\User;
use App\Orders;
use App\Plan;
use App\Subscription;
use App\ResponseText as RT;
use App\Jobs\SendEmailJob;


class SubscriptionController extends Controller
{
    //
    public function upgradeSubscription(Request $request)
    {
        $result = ["message"=>"","code"=>400,"data"=>[]] ;

        $user= JWTAuth::touser($request->header('authorization'));

        $rules = array(
            'user_id'=>'required',
            'plan_id' => 'required'
        );

        $validator = \Validator::make($request->all(), $rules,[]);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $result['message'] = reset($msgArr)[0];
        }else if($user && $user->id == $request->user_id) {

            $plan = Plan::find($request->plan_id);

            if (!$plan) {
                $result['message']  = RT::rtext("warning_no_data_found");
            }else{

                $SECRET_KEY = \config('admin.stripe.SECRET_KEY');
                if ($user->stripe_acount_type == "local") {
                    $SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
                    $plan = Plan::where("plan_uid", "MY_SAFETY_19")->first();
                }

                $stripe=\Stripe::make($SECRET_KEY);

                $planid = $plan->plan_uid;
                if ($planid == "" || !$planid) {
                    $planid = $plan->id;
                }
                try {
                    $subscription = $stripe->subscriptions()->create($user->stripe_id, ['plan' => $planid]);
                } catch (\Throwable $th) {
                    add_logs("error","exception_".$request->path(),$th->getMessage(),$th->getCode(),$th->getLine(),$th->getFile());
                    $result['message'] = $th->getMessage();
                    return $this->JsonResponse($result);
                }
                if (isset($subscription) &&  $subscription && isset($subscription['id'])) {

                    $user->status == 0 ? $user->update(['status'=>1]) : '' ;

                    if ($plan->type == "monthly") {
                        $date = Carbon::now()->addMonths(1);
                    } elseif ($plan->type == "yearly") {
                        $date = Carbon::now()->addYears(1);
                    } elseif ($plan->type == "daily") {
                        $date = Carbon::now()->addDays(1);
                    } elseif ($plan->type == "weekly") {
                        $date = Carbon::now()->addWeek(1);
                    } elseif ($plan->type == "free") {
                        $date = Carbon::now()->addDays(\config('admin.free_trial_duration'));
                    }

                    $order['user_id'] = $user->id;
                    $order['plan_id'] = $plan->id;
                    $order['start_date'] = Carbon::now()->format('Y-m-d');
                    $order['expiry_date'] = $date->subDays(1)->format('Y-m-d');
                    $order['next_pay'] = $date->addDays(1)->format('Y-m-d');
                    $order['auth_response'] = json_encode($subscription);
                    $order['plan_ob'] = json_encode($plan);
                    $order['order_no'] = Orders::getNextOrderNumber();
                    $order['amount'] = $plan->actual_amount;
                    $order['subscription_id'] = $subscription['id'];
                    $order['trans_status'] = $subscription['status'];
                    $order['token'] = "";
                    $order['status'] = 1;
                    $order = Orders::create($order);

                    $this->unsubscribeCurrentPlanByUserId($user->id, $order->id);

                    \DB::commit();

                    $plan = json_decode($order->plan_ob);
                    $subject = RT::rtext("mail_subject_upgrate_plan_success");
                    $user = $order->user;
                    if ($user && $plan) {
                        $mdata = ['action'=>'subscription_upgrated','user'=>$user,'subject'=>$subject,'order'=>$order,'plan'=>$plan,'view'=>'email.billing.upgrade-plan-success','to'=>$user->email];
                        SendEmailJob::dispatch($mdata)->onConnection('database')->onQueue('emails');

                        $mdata = ['action'=>'get_invoice','order'=>$order,'view'=>'','to'=>"","subject"=>""];
                        SendEmailJob::dispatch($mdata)->onConnection('database')->onQueue('emails');
                    }
                    $result['data']['order_no'] = $order['order_no'] ;
                    $result['message'] = RT::rtext("success_your_subscription_plan_has_been_upgraded") ;
                    $result['code'] = 200 ;

                } else {
                    $result['message'] = 'Credential is invalid';

                }
            }

		}else{
            $result['message'] = RT::rtext("warning_user_data_not_found") ;
        }

        return $this->JsonResponse($result);


    }


    public function unsubscribeCurrentPlanByUserId($user_id, $except_id)
    {
        $orders=Orders::where('user_id', $user_id)->where("trans_status", 'active')->get();

        foreach ($orders as $key => $order) {
            if ($order && $order->user && $order->id != $except_id) {
                $user = $order->user;

                if ($order->subscription_id === 0 || $order->subscription_id == "" || $order->subscription_id == "0" || !$order->subscription_id) {
                } else {
                    $SECRET_KEY = \config('admin.stripe.SECRET_KEY');
                    if ($user->stripe_acount_type == "local") {
                        $SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
                    }
                    $stripe=\Stripe::make($SECRET_KEY);

                    try {
                        $subscription = $stripe->subscriptions()->cancel($user->stripe_id, $order->subscription_id, true);
                        $order->unsubscription_ob = json_encode($subscription);
                    } catch (\Throwable $th) {
                        add_logs("error","exception_"."unsubscribeCurrentPlanByUserId",$th->getMessage(),$th->getCode(),$th->getLine(),$th->getFile());
                        \Log::error($th);
                        \Log::info("{$order->subscription_id} not cancelled for user {$user->id}");
                    }
                }

                $order->status=0;
                $order->trans_status="cancelled";
                $order->save();

                $plan = json_decode($order->plan_ob);
                $subject = RT::rtext("mail_subject_stop_subscription_success");
                $user = $order->user;
                if ($user && $plan) {
                    $mdata = ['action'=>'unsubscription_success','user'=>$user,'subject'=>$subject,'order'=>$order,'plan'=>$plan,'view'=>'email.billing.unsubscribe-success','to'=>$user->email];
                    SendEmailJob::dispatch($mdata)->onConnection('database')->onQueue('emails');
                }
            }
        }
    }
}
