<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use JWTAuth;
use DB;
use Carbon\Carbon as Carbon;
use App\Role;
use App\User;
use App\OrderUser;
use App\Order;
use App\PlanUser;
use App\Payment;
use App\PlanOrder;
use App\Setting;
use App\Plan;
use App\Subscription;
use App\Billing;
use App\Cards;
use App\Notification;
use App\ResponseText as RT;
use App\Jobs\SendEmailJob;

class SubscriptionController extends Controller
{
    public function upgradeSubscription(Request $request)
    {
        try {
            $code = 200;
            $message = "";
            $result =[];

            $rules = array(
            'child_id'=>'required',
            'plan_id' => 'required'
        );

            $validator = \Validator::make($request->all(), $rules, []);

            if ($validator->fails()) {
                $msgArr = $validator->messages()->toArray();
                $message = reset($msgArr)[0];
                $code = 400;
            } else {
                $user= JWTAuth::touser($request->header('authorization'));
                $child = User::where('id', $request->child_id)->where('parent_id', $user->id)->first();
                $plan = Plan::find($request->plan_id);

                if (!$user || !$child || !$plan) {
                    $code = 400;
                    $message = RT::rtext("warning_user_data_not_found");
                }
            }

            if ($code != 400) {
                $SECRET_KEY = \config('admin.stripe.SECRET_KEY');
                if ($child->stripe_acount_type == "local") {
                    $SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
                    $plan = Plan::where("plan_uid", "MY_SAFETY_19")->first();
                }

                $stripe=\Stripe::make($SECRET_KEY);



                $planid = $plan->plan_uid;
                if ($planid == "" || !$planid) {
                    $planid = $plan->id;
                }
                $subscription = $stripe->subscriptions()->create($child->stripe_id, ['plan' => $planid]);


                //echo "<pre>"; print_r($subscription);
                if ($subscription && isset($subscription['id'])) {
                    if ($child->status == 0) {
                        $child->status = 1;
                    }

                    $child->save();

                    if ($plan->type == "monthly") {
                        $date = Carbon::now()->addMonths(1);
                    } elseif ($plan->type == "yearly") {
                        $date = Carbon::now()->addYears(1);
                    } elseif ($plan->type == "daily") {
                        $date = Carbon::now()->addDays(1);
                    } elseif ($plan->type == "weekly") {
                        $date = Carbon::now()->addWeek(1);
                    } elseif ($plan->type == "free") {
                        $date = Carbon::now()->addDays(\config('admin.free_trial_duration'));
                    }

                    $order['parent_id'] = $user->id;
                    $order['child_id'] = $child->id;
                    $order['plan_id'] = $plan->id;

                    $order['start_date'] = Carbon::now()->format('Y-m-d');
                    $order['expiry_date'] = $date->subDays(1)->format('Y-m-d');
                    $order['next_pay'] = $date->addDays(1)->format('Y-m-d');
                    $order['auth_response'] = json_encode($subscription);
                    $order['plan_ob'] = json_encode($plan);
                    $order['order_no'] = Order::getNextOrderNumber();
                    $order['amount'] = $plan->actual_amount;
                    $order['subscription_id'] = $subscription['id'];
                    $order['trans_status'] = $subscription['status'];
                    $order['token'] = "";
                    $order['status'] = 1;
                    $result = Order::create($order);

                    //echo "<pre>"; print_r($order);
                    $this->unsubscribeCurrentPlanByUserId($child->id, $result->id);

                    \DB::commit();

                    $message = RT::rtext("success_plan_upgration");
                    $code = 200;

                    $plan = json_decode($result->plan_ob);
                    $subject = RT::rtext("mail_subject_upgrate_plan_success");
                    $user = $result->parent;
                    if ($user && $plan) {
                        $mdata = ['action'=>'subscription_upgrated','user'=>$user,'subject'=>$subject,'order'=>$result,'plan'=>$plan,'view'=>'email.billing.upgrade-plan-success','to'=>$user->email];
                        SendEmailJob::dispatch($mdata)->onConnection('database')->onQueue('emails');

                        $mdata = ['action'=>'get_invoice','order'=>$result,'view'=>'','to'=>"","subject"=>""];
                        SendEmailJob::dispatch($mdata)->onConnection('database')->onQueue('emails');
                    }
                } else {
                    $message = 'Credential is invalid';
                    $code = 400;
                }
            }
        } catch (\Exception $e) {
            $message = $e->getMessage();
            $code = 400;
        }

        $res_code = 200;
        $status = true;
        if ($code != 200) {
            $res_code = RESPONSE_ERROR_CODE;
            $status = false;
        }

        return response()->json([
            'result' => $result,
            'message' => $message,
            'success' => $status,
            'status' => $code,
        ], $res_code);
    }

    public function setDefaultCard(Request $request)
    {
        $result = [] ;
        $message = "" ;
        $status = true ;
        $code = 200 ;

        $rules = array(
            'user_id'=>'required',
            'card_id'=>'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $message = reset($msgArr)[0];
            $status = false;
            $code = 400;

            return response()->json([
                    'message' => $message,
                    'success' => $status,
                    'result' => $result,
                    'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
        }

        $user= JWTAuth::touser($request->header('authorization'));

        if ($user->id == $request->user_id) {
            $SECRET_KEY = \config('admin.stripe.SECRET_KEY');
            if ($user->stripe_account_type == "local") {
                $SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
            }
            $stripe=\Stripe::make($SECRET_KEY);

            $savecard = $user->cards()->where("id", $request->card_id)->first();

            if ($savecard) {
                try {
                    $cardRes = $stripe->customers()->update($user->stripe_id, [
                        'default_source' => $savecard->card_id
                    ]);
                } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
                    $message = $e->getMessage();
                    $status = false ;
                    $code = $e->getCode();

                    return response()->json([
                        'message' => $message,
                        'success' => $status,
                        'result' => $result,
                        'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
                }

                if (isset($cardRes) && $cardRes) {
                    $user->cards()->update(['default'=>0]);
                    $savecard->update(['default'=>1]);

                    // $result = User::select(['id','username','first_name','last_name','stripe_id','stripe_acount_type'])
                    // ->with('cards')
                    // ->where('id',$child->id)->orderby('created_at','DESC')->first();

                    $result = $savecard  ;
                    $message = RT::rtext("success_card_updated");
                    $status = true;
                    $code = 200;
                } else {
                    $message = RT::rtext("error_default");
                    $status = true;
                    $code = 400;
                }
            } else {
                $message = RT::rtext("card_does_not_belongs_to_user");
                $status = true;
                $code = 400;
            }
        } else {
            $message = RT::rtext("warning_user_data_not_found") ;
            $status = false ;
            $code = 400 ;
        }

        return response()->json([
            'message' => $message,
            'success' => $status,
            'result' => $result,
            'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
    }

    public function removeCard(Request $request)
    {
        $result = [] ;
        $message = "" ;
        $status = true ;
        $code = 200 ;

        $rules = array(
            'user_id'=>'required',
            'card_id'=>'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $message = reset($msgArr)[0];
            $status = false;
            $code = 400;

            return response()->json([
                    'message' => $message,
                    'success' => $status,
                    'result' => $result,
                    'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
        }

        $user= JWTAuth::touser($request->header('authorization'));

        if ($user->id == $request->user_id) {
            $SECRET_KEY = \config('admin.stripe.SECRET_KEY');
            if ($user->stripe_account_type == "local") {
                $SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
            }
            $stripe=\Stripe::make($SECRET_KEY);

            $savecard = $user->cards()->where("id", $request->card_id)->first();

            if ($savecard) {
                try {
                    $cardRes = $stripe->cards()->delete($user->stripe_id, $savecard->card_id);
                } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
                    $message = $e->getMessage();
                    $status = false ;
                    $code = $e->getCode();

                    return response()->json([
                        'message' => $message,
                        'success' => $status,
                        'result' => $result,
                        'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
                }
                if (isset($cardRes) && $cardRes) {
                    $savecard->delete();

                    // $result = User::select(['id','username','first_name','last_name','stripe_id','stripe_acount_type'])
                    // ->with('cards')
                    // ->where('id',$child->id)->orderby('created_at','DESC')->first();

                    $message = RT::rtext("success_card_removed");
                    $status = true;
                    $code = 200;
                } else {
                    $message = RT::rtext("error_default");
                    $status = true;
                    $code = 400;
                }
            } else {
                $message = RT::rtext("card_does_not_belongs_to_user");
                $status = true;
                $code = 400;
            }
        } else {
            $message = RT::rtext("warning_user_data_not_found") ;
            $status = false ;
            $code = 400 ;
        }

        return response()->json([
            'message' => $message,
            'success' => $status,
            'result' => $result,
            'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
    }
    public function getMyCards(Request $request)
    {
        $result = [] ;
        $message = "Success" ;
        $status = true ;
        $code = 200 ;
        $user= JWTAuth::touser($request->header('authorization'));
        $cards = $user->cards()->get();
        $total = $cards->count();
        if ($total == 0) {
            $message = "No Cards Found " ;
            $status = false ;
            $code = 400 ;
        } else {
            $result= ['cards' => make_null($cards) , 'total' => $total];
            $message = "Cards List" ;
        }
        return response()->json([
            'message' => $message,
            'success' => $status,
            'result' => $result,
            'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
    }
    public function addCard(Request $request)
    {
        $result = [] ;
        $message = "Success" ;
        $status = true ;
        $code = 200 ;

        $rules = array(
            'user_id'=>'required',
            'token_id'=>'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $validation = $validator;
            $msgArr = $validator->messages()->toArray();
            $message = reset($msgArr)[0];
            $status = false;
            $code = 400;

            return response()->json([
                    'message' => $message,
                    'success' => $status,
                    'result' => $result,
                    'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
        }

        $user= JWTAuth::touser($request->header('authorization'));

        if ($user->id == $request->user_id) {
            $SECRET_KEY = \config('admin.stripe.SECRET_KEY');
            if ($user->stripe_account_type == "local") {
                $SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
            }
            $stripe=\Stripe::make($SECRET_KEY);

            if (!$user->stripe_id || $user->stripe_id == "") {
                try {
                    $customer = $stripe->customers()->create([
                        'email' => $user->email,
                    ]);
                } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
                    $message = $e->getMessage();
                    $status = false ;
                    $code = $e->getCode();

                    return response()->json([
                        'message' => $message,
                        'success' => $status,
                        'result' => $result,
                        'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
                }
                $user->stripe_id = $customer['id'];
                $user->save();
            }

            try {
                $cardRes = $stripe->cards()->create($user->stripe_id, $request->token_id);
            } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
                $message = $e->getMessage();
                $status = false ;
                $code = $e->getCode();

                return response()->json([
                    'message' => $message,
                    'success' => $status,
                    'result' => $result,
                    'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
            }

            if (isset($cardRes['id'])) {
                try {
                    $customerupdate = $stripe->customers()->update($user->stripe_id, [
                        'default_source' => $cardRes['id']
                    ]);
                } catch (\Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\BadRequestException	| \Cartalyst\Stripe\Exception\UnauthorizedException | \Cartalyst\Stripe\Exception\InvalidRequestException | \Cartalyst\Stripe\Exception\NotFoundException | \Cartalyst\Stripe\Exception\CardErrorException | \Cartalyst\Stripe\Exception\ServerErrorException | \Cartalyst\Stripe\Exception\MissingParameterException | \Cartalyst\Stripe\Exception\StripeException | Exception $e) {
                    $message = $e->getMessage();
                    $status = false ;
                    $code = $e->getCode();

                    return response()->json([
                        'message' => $message,
                        'success' => $status,
                        'result' => $result,
                        'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
                }

                $cardRes['default'] = 1;

                Cards::where("stripe_id", $user->stripe_id)->update(['default'=>0]);

                $saved_card = Cards::saveCard($cardRes, $user->stripe_id);

                $result['card_id'] = $saved_card->id ;

                $message = RT::rtext("success_card_added");
                $status = true;
                $code = 200;
            } else {
                $message = RT::rtext("error_default");
                $status = true;
                $code = 400;
            }
        } else {
            $message = RT::rtext("warning_user_data_not_found") ;
            $status = false ;
            $code = 400 ;
        }

        return response()->json([
            'message' => $message,
            'success' => $status,
            'result' => $result,
            'status' => $code ], ($code != 200) ? RESPONSE_ERROR_CODE : 200);
    }


    public function unsubscribeCurrentPlanByUserId($user_id, $except_id)
    {
        $orders=Order::where('child_id', $user_id)->where("trans_status", 'active')->get();

        foreach ($orders as $key => $order) {
            if ($order && $order->child && $order->id != $except_id) {
                $child = $order->child;

                if ($order->subscription_id === 0 || $order->subscription_id == "" || $order->subscription_id == "0" || !$order->subscription_id) {
                } else {
                    $SECRET_KEY = \config('admin.stripe.SECRET_KEY');
                    if ($child->stripe_acount_type == "local") {
                        $SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY');
                    }
                    $stripe=\Stripe::make($SECRET_KEY);

                    $subscription = $stripe->subscriptions()->cancel($child->stripe_id, $order->subscription_id, true);
                    $order->unsubscription_ob = json_encode($subscription);
                }

                $order->status=0;
                $order->trans_status="cancelled";
                $order->save();

                $plan = json_decode($order->plan_ob);
                $subject = RT::rtext("mail_subject_stop_subscription_success");
                $user = $order->parent;
                if ($user && $plan) {
                    $mdata = ['action'=>'unsubscription_success','user'=>$user,'subject'=>$subject,'order'=>$order,'plan'=>$plan,'view'=>'email.billing.unsubscribe-success','to'=>$user->email];
                    SendEmailJob::dispatch($mdata)->onConnection('database')->onQueue('emails');
                }
            }
        }
    }

    public function getPlanlistForUser(Request $request)
    {
        $code = 200;
        $message = "";
        $result =['data'=>[],'current_plan'=>'','child'=>""];

        $rules = array(
            'child_id'=>'required'
        );

        $validator = \Validator::make($request->all(), $rules, []);

        if ($validator->fails()) {
            $msgArr = $validator->messages()->toArray();
            $message = reset($msgArr)[0];
            $code = 400;
        } else {
            $user= JWTAuth::touser($request->header('authorization'));
            $child = User::where('id', $request->child_id)->where('parent_id', $user->id)->first();

            if (!$user || !$child) {
                $code = 400;
                $message = RT::rtext("warning_user_data_not_found");
            } else {
                $order=Order::where('child_id', $request->child_id)->where("trans_status", 'active')->orderby('updated_at', 'DESC')->first();
                $current_plan = 0 ;
                $current_plan_id = 0;
                if ($order) {
                    $current_plan_id = $order->plan_id ;
                    $current_plan = Plan::where("id", $current_plan_id)->first();
                    if ($current_plan) {
                        $child->subscription_id = $order->subscription_id;
                    }
                }
                $result['data'] = Plan::where("status", "1")->where("id", "!=", $current_plan_id)->where("type", "!=", 'free')->get();
                $result['current_plan'] =$current_plan;
                $result['child'] = $child;
            }
        }

        $res_code = 200;
        $status = true;
        if ($code != 200) {
            $res_code = RESPONSE_ERROR_CODE;
            $status = false;
        }

        return response()->json([
            'result' => $result,
            'message' => $message,
            'success' => $status,
            'status' => $code,
        ], $res_code);
    }
}
