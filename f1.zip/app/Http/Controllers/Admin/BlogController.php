<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Http\Request;
use App\Blog;
use DB;

class BlogController extends Controller
{
    protected $blog;
    public function __construct() {
        $this->context = 'blog';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context);
    }

    function validationrule(){

        return [

            'title' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.title_required'),
                ]
            ],

            'detail' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.detail_required'),
                ]
            ],

            'short_desc' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.short_desc_required'),
                ]
            ],

            'post_date' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.post_date_required'),
                ]
            ],

            'type' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.type_required'),
                ]
            ],


        ];

    }

    public function changeStatus(Request $request)
    {
        Blog::where("id", $request->blog_id)->update(['status' => $request->status ]);

        return response()->json(['success'=>'Blog status changed successfully.']);
    }

}
