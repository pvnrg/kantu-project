<?php

namespace App\Http\Controllers\Admin;

use App\Plan;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Storage;
use DB;

class PlanController extends Controller
{
    public function __construct() {
        $this->context = 'plan';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context); 
    }
    
    function validationrule(){
 
        return [
            
            'title' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.title_required'),
                ]
            ], 
            
            'actual_amount' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.actual_amount_required'),
                ]
            ], 

            'show_amount' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.show_amount_required'),
                ]
            ], 

            'description' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.description_required'),
                ]
            ], 

            'type' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.type_required'),
                ]
            ],  
            
        ];
 
    }

    public function changeStatus(Request $request)
    {
        //return $request;
        DB::table("plans")->where("id", $request->plan_id)->update(['status' =>$request->status]);  
        return response()->json(['success'=>'Plan status change successfully.']);
    }

    public function generateStripePlan($id,Request $request)
    {
        $item = Plan::where("id",$id)->first(); 
        if(!$item){
            return redirect(route('admin.plan'))->with('error','No Plan Found.');
        }
        
        if($item->stripe_product_id && $item->stripe_product_id !=""){
            return redirect(route('admin.plan'))->with('error','Strip Plan Already Exist.');
        }
        
		//echo \config('admin.stripe.SECRET_KEY'); exit;
		
        $stripe = \Stripe::make(\config('admin.stripe.SECRET_KEY'));
        
		$uid = "MY_SAFETY_".$item->id;
        $plan = $stripe->plans()->create([
            'id' => $uid,
            'name' => $item->type,
            'amount' => $item->actual_amount,
            'currency' => 'USD',
            'interval' => config('admin.interval')[$item->type],
            'interval_count'=>  1,
            'statement_descriptor' => $item->type. " USD ".$item->actual_amount,
        ]);

        $item->stripe_product_id = $plan['product'];
		$item->plan_uid = $uid;
        $item->save();
        
        return redirect(route('admin.plan'))->with('success','Strip Plan Created.');
    }
}
