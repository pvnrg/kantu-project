<?php

namespace App\Http\Controllers\Admin;

use App\Faq;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use DataTables;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Hash;

class FaqsController extends Controller
{
    // protected $Faq;
    public function __construct() {
        $this->context = 'faq';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context);
    }

    function validationrule(){

        return [

            'question' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.question_required'),
                ]
            ],

            'answer' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.answer_required'),
                ]
            ],

        ];

    }

    public function changeStatus(Request $request)
    {
        Faq::where('id',$request->faq_id)->update(['status' => $request->status]);
        return response()->json(['success'=>'Faq status changed successfully.']);
    }
}
