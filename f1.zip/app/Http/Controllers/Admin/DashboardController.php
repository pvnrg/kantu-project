<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use App;
Use App\Rolls;
use App\Orders;
use App\User;

class DashboardController extends Controller
{

    public function __construct()
    {

    }

    public static function show(){

        $total_users = Rolls::where('title','User')->whereHas('userrolls')->first()->userrolls()->whereHas('user')->count();

        // $total_emp = Rolls::where('title','Employee')->whereHas('userrolls')->first()->userrolls()->whereHas('user')->count() ;

        $subscribers = Orders::whereHas('user')->whereNotNull('subscription_id')->where('subscription_id','!=',"0")->where('subscription_id','!=', "")->whereTransStatus('active');

        $total_subscribers = $subscribers->count();

        $total_subscription_amount = $subscribers->sum('amount');

        $total_one_time_fees = Orders::whereHas('user')->whereNotNull('one_time_charge_id')->where('one_time_charge_id','!=', "0")->where('one_time_charge_id','!=', '')->whereTransStatus('active')->sum('one_time_fee') ;

        return view('admin.dashboard.index', compact('total_users', 'total_subscribers','total_subscription_amount','total_one_time_fees'));
    }

}
