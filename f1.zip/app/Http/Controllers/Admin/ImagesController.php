<?php

namespace App\Http\Controllers\Admin;

use App\Images;
use DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Storage;

class ImagesController extends Controller
{
    public function __construct() {
        $this->context = 'images';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context);
    }

    function validationrule(){

        return [

            'image' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.image_required'),
                ]
            ],

        ];

    }

}
