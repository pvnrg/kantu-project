<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use DataTables;
use DB;
use App\User;
use App\EventsImages ;

class EventsImagesController extends Controller
{
    public function __construct() {
        $this->context = 'events_images';
        $this->modal = 'App\EventsImages';
        //parent::__construct();
        View::share('context',  $this->context);
    }

    public function datatable(Request $request){

        $record = $this->modal::whereHas('user')->with('event:id,title','safe_image','unsafe_image','choosen_image', 'user:id,first_name,last_name')->where("id",">",0);

        if ($request->has('user_id') && $request->get('user_id') != '' ) {

            $record = $record->where('user_id', $request->user_id);
        }
        $record = $record->orderBy('created_at','desc')->get();
        return DataTables::of($record)->make(true);
    }


}
