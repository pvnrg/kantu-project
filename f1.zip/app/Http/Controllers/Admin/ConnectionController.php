<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use DataTables;

class ConnectionController extends Controller
{
    protected $connection;
    public function __construct() {
        $this->context = 'connection';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context);
    }

    public function datatable(Request $request){

        $record = $this->modal::whereHas('sender')->whereHas('receiver')->with('sender:id,first_name,last_name','receiver:id,first_name,last_name')->where("id",">",0);

        if ($request->has('filter') && $request->get('filter') != '' &&  $request->get('filter') != 'all') {

            $record = $record->where('status', $request->filter);
        }
        $record = $record->orderBy('created_at','desc')->get();
        return DataTables::of($record)->make(true);
    }

}
