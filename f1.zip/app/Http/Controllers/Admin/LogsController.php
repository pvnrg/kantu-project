<?php

namespace App\Http\Controllers\Admin;

use App\Logs;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Storage;

class LogsController extends Controller
{
    public function __construct() {
        $this->context = 'logs';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context); 
    }
}
