<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon as Carbon;
use App\Employee;
use App\User;
use App\Userrolls;
use App\Rolls;
use App\BadgeApprove;
use App\Transactionlogs;
use App\Settings;
use DB, Auth, Session, Mail, DataTables ;

class EmployeeController extends Controller
{
    public function __construct() {
        $this->context = 'employee';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context);

        $setting = Settings::pluck('fvalue','fkey')->toArray();
        session(['setting' => $setting]);

        view()->share('route', 'employee');
        view()->share('module', 'Employee');
    }

    public function index(Request $request)
    {
		$to_date = null;
		$from_date = null;

		$users = User::select([
                    'users.*','employees.try_count','employees.is_setup','employees.approved_count', 'user_rolls.user_id'
                ])
                ->join('employees','employees.user_id','=','users.id')
                ->join('user_rolls','user_rolls.user_id','=','users.id')
                ->orderBy('id','DESC')
                ->get();
		$total_approved_child = 0;

        //return $users; die;

		foreach($users as $i =>$user){
            $badgeapprove = BadgeApprove::where("badge_approve_by",$user->id);
            if($request->has('from_date') && $request->has('to_date') && $request->get('from_date') !="" && $request->get('to_date') != "" )
            {
				 $to_date = \Carbon\Carbon::createFromFormat('Y-m-d',$request->get('to_date'))->endOfDay();
				 $from_date = \Carbon\Carbon::createFromFormat('Y-m-d',$request->get('from_date'))->startOfDay();
                 $badgeapprove->whereBetween('created_at', array($from_date, $to_date));
			}
			$badgeapprove->whereIn("status",["approved","disapproved"]);
            $badgeapprove = $badgeapprove->get();

			$total_approved_child = $total_approved_child + $badgeapprove->count();
            $user->badgeapprove = $badgeapprove;
        }

        $unit_sum = Transactionlogs::sum('unit');
        $for_user_sum = Transactionlogs::sum('for_user');

        if($request->has('from_date') && $request->has('to_date') && $request->get('from_date') !="" && $request->get('to_date') != "" ){

            $to_date = \Carbon\Carbon::createFromFormat('Y-m-d',$request->get('to_date'))->endOfDay();
            $from_date = \Carbon\Carbon::createFromFormat('Y-m-d',$request->get('from_date'))->startOfDay();

            $unit_sum = Transactionlogs::whereBetween('created_at', array($from_date, $to_date))->sum('unit');
            $for_user_sum = Transactionlogs::whereBetween('created_at', array($from_date, $to_date))->sum('for_user');
        }

        $approve_count = Employee::sum('approved_count');

        $setting = Settings::where('fkey','amount_per_user_approve')->first();
		if($setting){
			$peruser = $setting->fvalue;
		}else{
			$peruser = 0;
		}

        //return $from_date; die;
        return view('admin.employee.index',compact('users','from_date','to_date','unit_sum','for_user_sum','total_approved_child','approve_count','peruser'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email|unique:users',
            // 'password' => 'required',
            'phone' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/'
        ]);

        $data = $request->except('password') ;
        $data['password'] = Hash::make($request->password) ;

        $user = User::create($data) ;
        $email = $user->email;
        if($user &&  $role = Rolls::where('title',$request->rolls)->first() ){
            $token = str_random(40);
            Userrolls::create([
                'user_id' => $user->id,
                'roll_id' => $role->id
            ]);
            $user->employee()->create([
                'email' => $email,
                "token" => $token,
                "try_count"=>1,
                "approved_count"=>0,
                "is_setup"=>"no",
            ]);
        }

        try {
            $subject = \config('app.name')." Employee Account Activation";
            \Mail::send('email.employee-activation', compact(['user']), function ($message) use ($subject,$email) {
                    $message->to($email)->subject($subject);
            });
        } catch (\Throwable $th) {
            add_logs("error","exception_".$request->path(),$th->getMessage(),$th->getCode(),$th->getLine(),$th->getFile());
        }

        return redirect(route('admin.employee'))->with('success','Employee Created & activation link has been mailed!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function show($id, Request $request)
    {
        $to_date = null;
        $from_date = null;

        $users = User::where('users.id', $id)
        ->leftJoin('employees', 'users.id', '=', 'employees.user_id')
        ->select('users.*', 'employees.*')
        ->first();

        $badgeapprove = BadgeApprove::where("badge_approve_by",$id);
        //return $badgeapprove; die;
        if($request->has('from_date') && $request->has('to_date') && $request->get('from_date') !="" && $request->get('to_date') != "" )
        {
			 $to_date = \Carbon\Carbon::createFromFormat('Y-m-d',$request->get('to_date'))->endOfDay();
             $from_date = \Carbon\Carbon::createFromFormat('Y-m-d',$request->get('from_date'))->startOfDay();
			 $badgeapprove->whereBetween('created_at', array($from_date, $to_date));
		}

		$badgeapprove->where("status","approved");
        $badgeapprove = $badgeapprove->get();
        $item = $users;

        //return $from_date; die;

        return view('admin.employee.show', compact('item','badgeapprove','from_date','to_date'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function edit($id, Request $request)
    {
        $item = User::whereHas('employee')->where('id', $id)->first();
        return view('admin.employee.edit', compact('item'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function update($id, Request $request)
    {
        //return $id; die;
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
            'phone' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/'
            //'password' => 'required'
        ]);

        $employee = Employee::find($id);
        $employee->email = $request->input('email');
        $employee->save();

        $user = User::where('id', $employee->user_id)->first();
        $user->name = $request->input('first_name') .' '. $request->input('last_name');
        $user->first_name = $request->input('first_name');
        $user->last_name = $request->input('last_name');
        $user->email = $request->input('email');
        $user->password = Hash::make($request->password);
        $user->phone = $request->input('phone');
        $user->save();

        return redirect(route('admin.employee'))->with('success','Employee Created Successfully.');
    }
    public function destroy($id, Request $request)
    {
        $user=User::find($id);
		if($user && $user->employee){
			$user->employee->delete();
		}
		User::where('id',$id)->delete();
    }

    public function approvedBy($id, Request $request)
    {
        //return $id; die;
        $data = User::where('users.id', $id)->select('users.badge_approved_by')->first();
        $approved_by = User::where('users.id', $data->badge_approved_by)->select('users.*')->first();
        return redirect()->to('admin/users/'.$approved_by->id);
    }

    public function resendmail($id, Request $request)
    {
        $user=User::find($id);
        if($user)
        {
            $employee = Employee::where("user_id",$user->id)->first();
			if(!$employee){
				$employee = new Employee();
				$employee->user_id = $user->id;
				$employee->email = $user->email;
				$employee->try_count = 1;
				$employee->approved_count = 0;
				$employee->is_setup = "no";
			}else{
				$employee->try_count = 1 + $employee->try_count;
			}
			$employee->token = str_random(40);
			$employee->save();

            $email = $user->email;
            try {
                $subject = \config('app.name')." Employee Account Activation";
                \Mail::send('email.employee-activation', ['user' => $user], function ($message) use ($subject,$email) {
                        $message->to($email)->subject($subject);
                });
                \Session::flash('flash_success', 'Activation mail sent');
            } catch (\Throwable $th) {
                add_logs("error","exception_".$request->path(),$th->getMessage(),$th->getCode(),$th->getLine(),$th->getFile());
                \Session::flash('flash_success', 'Activation mail not sent');
            }
		}else{
            \Session::flash('flash_error', 'Employee data not found !');

        }
		 return redirect('admin/employee');
    }

    public function activationForm(Request $request,$email,$token)
    {
        $employee = Employee::where('token', $token)->where('email',$email)->first();

		if(isset($employee) && $employee->user){
			$user = $employee->user;
			return view('auth.employee-paassword', compact('user','employee'));
		}else{
			return redirect('admin/employee')->with('flash_error','Invalid token or its expired contact admin for mor detail');
		}

	}

    public function activationSubmit(Request $request)
    {
		$rule = [
            'password' => 'required|min:6|max:20|same:confirm_password',
            'email' => 'required|email'
        ];
		$this->validate($request, $rule);

		$employee = Employee::where('token', $request->_vtoken)->where('email',$request->email)->first();

		if(isset($employee) && $employee->user){
			$employee->is_setup = "yes";
			$employee->token = str_random(10);
			$employee->save();

			$user = $employee->user;
			$user->password = bcrypt($request->password);
			$user->save();
			return redirect('admin/login')->with('flash_success','Password set successfully.');
		}else{
			return redirect('/')->with('flash_error','Invalid token or its expired contact admin for mor detail');
		}

    }


	public function paymentdatatable(Request $request,$uid){
         $user_id = $uid;
         if(\Auth::user()->hasRole('AU')){
             $user_id = $uid;
         }else{
             $user_id = \Auth::user()->id;
         }

         $users = Transactionlogs::where("user_id",$user_id)->with('creator')->get();

         return DataTables::of($users)
             ->make(true);
     }


    public function showMyPayment($id=0){
		$user_id = \Auth::user()->id;


        $user = User::with(['roles'])->find($user_id);

		if(!$user || !$user->hasRole('EU')){
            return redirect('admin/employee')->with('flash_error', 'User Not Found!');
        }

        return view('admin.employee.my-payments', compact('user'));
    }

    public function paymentForm(Request $request,$uid)
    {
		$employee = Employee::where('user_id',$uid)->first();
		$setting = Setting::where('key','amount_per_user_approve')->first();
		if($setting){
			$peruser = $setting->value;
		}else{
			$peruser = 0;
		}

		if(isset($employee) && $employee->user){

			if($employee->approved_count <= 0){
				return redirect('admin/employee/'.$uid)->with('flash_error','Employee has not enough credit  for payment');
			}
			$user = $employee->user;
			return view('admin.employee.payment', compact('user','employee','peruser'));
		}else{
			return redirect('admin/employee')->with('flash_error','Invalid User Id');
		}

	}
	public function paymentSubmit(Request $request)
    {

		$rule = [
            'total_child' => 'required',
            'amount' => 'required',
            'user_id' => 'required'
        ];

        $this->validate($request, $rule);

		$employee = Employee::where('user_id',$request->user_id)->first();

		if(isset($employee) && $employee->user){
			$user = $employee->user;
			if($employee->approved_count <= 0 || $employee->approved_count < $request->total_child){
				return redirect('admin/employee/'.$uid)->with('flash_success','Employee has not enough child process count  for payment');
			}

			$paydata = [
				"user_id"=>$user->id,
				"unit_type"=>'transfer',
				"unit"=>$request->amount,
				"comment"=>$request->comment,
				"for_user"=>$request->total_child,
				"reference"=>'admin_transfer',
				"created_by"=>\Auth::user()->id,
				"updated_by"=>\Auth::user()->id,
			];
			$employee->approved_count = $employee->approved_count - $request->total_child;
			$employee->save();

			$transaction = Transactionlogs::create($paydata);

			$mdata = ['action'=>'pay_employee','subject'=>"",'transaction'=>$transaction,'view'=>'email.employee-pay-notification','to'=>\config('admin.mail_to_admin')];
			SendEmailJob::dispatch($mdata)->onConnection('database')->onQueue('emails');

			return redirect('admin/employee/'.$user->id)->with('flash_success','Payment Detail saved success!');
		}else{
			return redirect()->back()->with('flash_error','Invalid User Id');
		}

	}
}
