<?php

namespace App\Http\Controllers\Admin;

use App\Orders;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Cache ;
use DB;
use DataTables ;
use App\User ;

class OrdersController extends Controller
{
    protected $order;
    public function __construct() {
        $this->context = 'orders';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context);
    }

    public function datatable(Request $request) {

        if ($request->has('user_id') && $request->get('user_id') != '' ) {
            $user = User::find($request->user_id);
            $record = $user ? $user->orders()->whereHas('user')->with('user')->get() : [];
        }else{
            $record = $this->modal::whereHas('user')->with('user:id,first_name,last_name')->where('id','>',0);
            if($request->has('type') && $request->get('type') != ''){
                if($request->type == 'one-time'){
                    $record->whereNotNull('one_time_charge_id')->where('one_time_charge_id','!=', "0")->where('one_time_charge_id','!=', '');
                }
                if($request->type == 'subscription'){
                    $record->whereNotNull('subscription_id')->where('subscription_id','!=',"0")->where('subscription_id','!=', '');
                }
            }
        }

        return DataTables::of($record)->make(true);
    }

    public function changeStatus(Request $request)
    {
        DB::table("orders")->where("id", $request->order_id)->update(['status' =>$request->status]);

        return response()->json(['success'=>'Order status change successfully.']);
    }
}
