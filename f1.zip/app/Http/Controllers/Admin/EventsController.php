<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use DataTables;
use DB;
use App\User;
use App\EventsImages ;

class EventsController extends Controller
{
    public function __construct() {
        $this->context = 'events';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context);
    }

    public function datatable(Request $request) {

        if ($request->has('user_id') && $request->get('user_id') != '' ) {
            $user = User::find($request->user_id);
            $record = $user ? $user->events()->whereHas('user')->with('user:id,first_name,last_name')->merge($user->invite_events()->whereHas('user')->with('user:id,first_name,last_name')->where('approval_status','accept')->get())->sortBy('created_at') : [];
        }else{

            $record = $this->modal::whereHas('user')->with('user:id,first_name,last_name')->where("id",">",0);
            if ($request->has('status') && $request->get('status') != 'all' && $request->get('status') != '') {
                $record = $record->where('status',$request->get('status'));
            }
            if ($request->has('id') && $request->get('id') != '' ) {
                $record =  $record->where('id',$request->get('id'));
            }
            if($request->has('enable_deleted') && $request->enable_deleted == 1){
                $record =  $record->onlyTrashed();
            }
            $record = $record->orderBy('created_at','desc');
        }

        return DataTables::of($record)->make(true);
    }



    public function emergency_list(Request $request){

       return view('admin.events.emergency_list', compact('events'));

    }

    public function emergency_list_datatable(Request $request){

        $record = EventsImages::where("id",">",0);

        if ($request->has('user_id') && $request->get('user_id') != '' ) {

            $record = $record->where('user_id', $request->user_id);
        }
        $record = $record->orderBy('created_at','desc')->get();
        return DataTables::of($record)->make(true);
    }


}
