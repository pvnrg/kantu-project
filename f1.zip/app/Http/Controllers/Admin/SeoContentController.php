<?php

namespace App\Http\Controllers\Admin;

use App\SeoContent;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Storage;

class SeoContentController extends Controller
{
    //protected $seo;
    public function __construct() {
        $this->context = 'seoContent';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context); 
    }
}
