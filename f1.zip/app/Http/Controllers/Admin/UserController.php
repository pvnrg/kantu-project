<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\Controller;
use App;
use App\Rolls;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use App\Userrolls;
use Auth;
use Illuminate\Support\Facades\Hash;
use DataTables;
use App\User;
use App\Connection;
use DB;
use App\BadgeApprove;
use App\Employee;
use App\Orders;
use Carbon\Carbon;

class UserController extends Controller
{
    protected $user;
    public function __construct() {

        $this->context = 'user';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context);

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    // public function index()
    // {
    //     $users = User::all();
    //     //return $users;
    //     return view('admin.users.show')->with('users',$users);
    // }

    /**
     * Display the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    // public function show(User $user)
    // {
    //     return view('admin.users.view')->with('user',$user);
    // }

    public function changeStatus(Request $request)
    {
        //return $request;
        $user = User::find($request->user_id);
        $user->status = $request->status;
        $user->save();

        return response()->json(['success'=>'User status change successfully.']);
    }

    // public function showConnectedUser($id, Request $request) {

    //     $user = User::with('connect_from', 'connect_to')->find($id);
    //     $connections = $user->connect_from->merge($user->connect_to);

    //     return view('admin.user.showConnectedUser', compact('connections', 'id', 'user'));
    // } 

    public function datatable(Request $request) {

        $is_super_admin = getSess('is_super_admin');
        $roll = Rolls::find(1)->userrolls->pluck('user_id');

        $user_roll = Rolls::where('title','User')->first()->userrolls->pluck('user_id');

        $subscribers = Orders::whereHas('user')->whereNotNull('subscription_id')->whereTransStatus('active')->pluck('user_id');

        $record = $this->modal::where("users.id",">",0);

        if($is_super_admin  &&  $roll && $user_roll){
            $record->whereNotIn("users.id",$roll);
        }

        if ($request->has('type') && $request->get('type') != '' && $request->type == 'subscribers' ) {
            $record->whereIn('users.id',$subscribers);
        }else{
            $record->whereIn('users.id', $user_roll );
        }

		if ($request->has('status') && $request->get('status') != 'all' && $request->get('status') != '') {
            $record->where('status',$request->get('status'));
        }
		if ($request->has('id') && $request->get('id') != '' ) {
            $record->where('users.id',$request->get('id'));
        }
		if($request->has('enable_deleted') && $request->enable_deleted == 1){
            $record->onlyTrashed();
        }

        // $record->orderBy('created_at', 'desc');
        return DataTables::of($record)->make(true);
    }


    public function create(Request $request)
    {
        $rolls = Rolls::get();
        return view('admin.'.$this->context.'.create',[
            'rolls'=>$rolls
        ]);

    }


    public function store(Request $request)
    {
        $result = array();
        $rule = [
            'first_name' => 'required|max:191',
            'last_name' => 'required|max:191',
            'email' => 'required|email|unique:users,deleted_at,NULL|max:191',
            'username' => 'required|unique:users,deleted_at,NULL|max:191',
            'password' => 'required|min:6',
            'pan_number' => 'required',
            'phone' => 'required|regex:/^(?=.*[0-9])[ +()0-9]+$/|unique:users,phone,NULL,id,deleted_at,NULL',
            // 'documents' => 'required|max:20000',  //mimes:jpg,jpeg,png,pdf,doc,docx,xls,xlsx,ppt
            'gender'=>'required|in:male,female',
            'dob'=>'required|date_format:Y-m-d|before:'.Carbon::parse($request->get('dob'))->startOfDay()->gte(Carbon::now()->subYears(15)),
        ];

        $msg= [
            'dob.before' => "Age must be atleast 15 years old"
        ];

        $this->validate($request, $rule, $msg);

        $input = $request->except(['']);
        $input['name'] = $request->first_name .' '. $request->last_name;
        $input['password'] =  Hash::make($request->password);
        $input['email_verified_at'] =  date('Y-m-d H:i:s');
        $item = $this->modal::create($input);

        if($item){
            // $rolls = $request->rolls;
            // foreach($rolls as $roll){
            //     Userrolls::create([
            //         'user_id' => $item->id,
            //         'roll_id' => $roll
            //     ]);
            // }
            $roll = Rolls::where('title','User')->first();
            if($roll){
                Userrolls::create([
                    'user_id' => $item->id,
                    'roll_id' => $roll->id
                ]);
            }

            $result['message'] = trans('common.response_msg.record_created_succes');
            $result['code'] = 200;
        }else{
            $result['message'] = trans('common.response_msg.something_went_wr');
            $result['code'] = 400;
        }

        $files = $request->file();
        if($files){
            foreach($files as $fkey=>$file){
                if(is_array($file)){
                    $ufile = $request->file($fkey);
                    uploadModalReferenceFile($ufile,$item,'document_type',[]);
                }else{
                    $ufile = [$request->file($fkey)];
                    uploadModalReferenceFile($ufile,$item,'profile_pic_type',[],false);
                }
            }
        }

        if($request->ajax()){
            return response()->json($result, $result['code']);
        }else{
            Session::flash('flash_message',$result['message']);
            return redirect()->route('admin.'.$this->context.'s');
        }

    }


    public function edit($id,Request $request)
    {
        $result = array();
        $rolls = Rolls::get();
        $item = $this->modal::findOrFail($id);
        if($item){
            $result['data'] = $item;
            $result['code'] = 200;
        }else{
            $result['message'] = trans('common.response_msg.something_went_wr');
            $result['code'] = 400;
			Session::flash('flash_error',trans('common.response_msg.data_not_found'));
            return redirect()->route('admin.'.$this->context.'s');
        }
		if($request->ajax()){
            return response()->json($result, $result['code']);
        }else{
            return view('admin.'.$this->context.'.edit', compact('item','rolls'));
        }
    }


    public function update($id, Request $request)
    {

        $result = array();
        $rule = [
            'first_name' => 'required|max:191',
            'last_name' => 'required|max:191',
            'phone' => 'required|regex:/^(?=.*[0-9])[ +()0-9]+$/|unique:users,phone,NULL,'.$id.',deleted_at,NULL',
            'gender'=>'required|in:male,female',
            'dob'=>'required|date_format:Y-m-d|before:'.Carbon::parse($request->get('dob'))->startOfDay()->gte(Carbon::now()->subYears(15)),
            // 'documents' => 'sometimes|max:20000',
        ];

        $msg= [
            'dob.before' => "Age must be atleast 15 years old "
        ];

        $this->validate($request, $rule , $msg);
        $item = $this->modal::where("id",$id)->first();
        $requestData = $request->all();
        $requestData['name'] = $request->first_name .' '. $request->last_name;


		if($item){
            $item->update($requestData);
            // Userrolls::where('user_id',$item->id)->each(function ($item, $key) {
            //     $item->delete();
            // });

            // $rolls = $request->rolls;

            // foreach($rolls as $roll){
            //     Userrolls::create([
            //         'user_id' => $item->id,
            //         'roll_id' => $roll
            //     ]);
            // }


            $files = $request->file();
            if($files){
                foreach($files as $fkey=>$file){
                    if(is_array($file)){
                        $ufile = $request->file($fkey);
                        uploadModalReferenceFile($ufile,$item,'document_type',[]);
                    }else{
                        $ufile = [$request->file($fkey)];
                        uploadModalReferenceFile($ufile,$item,'profile_pic_type',[],false);
                    }
                }
            } 

            $result['message'] = trans('common.response_msg.record_updated_succes');
            $result['code'] = 200;
        }else{
            $result['message'] = trans('common.response_msg.something_went_wr');
            $result['code'] = 400;
        }
        if($request->ajax()){
            return response()->json($result, $result['code']);
        }else{
            Session::flash('flash_message',$result['message']);
			if($request->has('previous_url') && $request->previous_url != ""){
				return redirect($request->previous_url);
			}
            return redirect()->route('admin.'.$this->context.'s',['id',$item->id]);
        }
    }

    public function editProfile(Request $request)
    {
        $user = Auth::user();
        return view('admin.profile.edit')->with('user',$user);
    }

    public function updateProfile(Request $request, User $user)
    {
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            // 'email' => 'required|email',
            'phone' => 'required|numeric'
        ]);

        $user->update($request->all());
        return redirect(route('admin.edit.profile'))->with('success','Profile Updated Successfully.');
    }

    public function changePassword(Request $request){
        $user = Auth::user();
        return view('admin.profile.changepassword')->with('user',$user);
    }

    public function updatePassword(Request $request, User $user)
    {
        $this->validate($request, [
            'password' => 'required',
            'confirm_password' => 'required|same:password',
        ]);

        $user->password = $request->input('password');
        User::find(auth()->user()->id)->update(['password'=> Hash::make($request->password)]);
        //$user->save();
        return redirect(route('admin.change.password'))->with('success','Password Updated Successfully.');
    }

    public function approveBadge($id, Request $request)
    {
        $badge = new BadgeApprove();
		$badge->badge_approve_by = \Auth::user()->id;
		$badge->user_id = $id;
        $badge->status = User::BADGE_APPROVE;
        $badge->save();

        $user = User::find($id);
        $user->badge_approved_by = \Auth::user()->id;
        $user->badge_status = User::BADGE_APPROVE ;
        $user->batch_id = time();
        $user->save();

        $emp = Employee::where("user_id", $id)->first();
		if($emp){
            $emp->approved_count = $emp->approved_count + 1;
            $emp->approve_count_total = $emp->approve_count_total + 1;
            $emp->save();
        }
        Session::flash('flash_message','Users badge has been approved successfully!');
        return redirect()->route('admin.'.$this->context.'s');
    }

    public function disapproveBadge($id, Request $request)
    {
        $badge = BadgeApprove::where("user_id",$id)->first();

        if(!$badge){
            $badge = new BadgeApprove();
            $badge->badge_approve_by = \Auth::user()->id;
            $badge->user_id = $id;
        }

        $badge->status = User::BADGE_DISAPPROVE ;
        $badge->save();

        $user = User::find($id);
        $user->badge_approved_by = \Auth::user()->id;
        $user->badge_status = User::BADGE_DISAPPROVE;
        $user->save();

        $emp = Employee::where("user_id", $id)->first();
        if($emp){
            $emp->approved_count = $emp->approved_count - 1;
            $emp->approve_count_total = $emp->approve_count_total - 1;
            $emp->save();
        }

        Session::flash('flash_message','Users badge has been disapproved!');
        return redirect()->route('admin.'.$this->context.'s');
    }

    public function deletefile($id)
    {
        $doc = \App\Refefile::where('id',$id)->first();
        if($doc){
            if($doc->refe_file_path && \File::exists(public_path()."/".$doc->refe_file_path)){
				unlink(public_path()."/".$doc->refe_file_path);
			}
			$doc->delete();
			\Session::flash('flash_success', 'Document deleted!');
		}else{
            \Session::flash('flash_error', 'Document not found!');
        }
		return redirect()->back();
    }

    public function unsubscribe($id, Request $request)
    {
		$SECRET_KEY = \config('admin.stripe.SECRET_KEY');

        $order = \App\Orders::whereId($id)->first();

        if(!$order){
			\Session::flash('flash_error', 'User detail not found !');
		}else{
                $user = $order->user;
                if($user->stripe_acount_type == "local"){ $SECRET_KEY = \config('admin.stripe_citrus.SECRET_KEY'); }

				if($order->subscription_id === 0 || $order->subscription_id == ""){

                }else{
                    $stripe=\Stripe::make($SECRET_KEY);

                    try {
                        $subscription = $stripe->subscriptions()->cancel($user->stripe_id, $order->subscription_id, true);
                        $order->unsubscription_ob = json_encode($subscription);
                    } catch (\Throwable $th) {
                        \Session::flash('flash_error', $th->getMessage() );
                        add_logs("error","exception_"."unsubscribeCurrentPlanByUserId",$th->getMessage(),$th->getCode(),$th->getLine(),$th->getFile());
                        \Log::error($th);
                        \Log::info("{$order->subscription_id} not cancelled for user {$user->id}");
                    }

				}

                $order->status=0;
                $order->trans_status="cancelled";
                $order->save();

				// Make user inactive if no active order
				$orderc=\App\Orders::where('user_id',$user->id)->where("trans_status",'active')->orderby('updated_at','DESC')->first();
				if(!$orderc){
					User::where('id',$user->id)->update(['status'=>'inactive']);
				}

			\Session::flash('flash_success', 'Unsubscription success !');
        }


        return redirect()->back();
    }
}
