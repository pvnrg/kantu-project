<?php

namespace App\Http\Controllers\Admin;

use App\ResponseText;
use Illuminate\Http\Request;
use App\Http\Controllers\Admin\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Storage;

class ResponseTextController extends Controller
{
    public function __construct() {
        $this->context = 'responseText';
        $this->modal = 'App\\'.ucfirst($this->context);
        //parent::__construct();
        View::share('context',  $this->context); 
    }

    function validationrule(){
 
        return [
            
            'desc' => [
                'rule' =>'required',
                'message' => [
                    'required' => trans($this->context.'.validation.desc_required'),
                ]
            ],             
            
        ];
 
    }
}
