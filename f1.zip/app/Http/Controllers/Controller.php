<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
	
	public function JsonResponse($parameter)
    {
		$rescode = $parameter["code"];
		if($parameter["code"] != 200){
			$rescode =  RESPONSE_ERROR_CODE;

		}
		
        return response()->json([
            'message' => $parameter["message"],
            'data' => $parameter["data"],
            'status' => ($parameter["code"] == 200)? true : false,
            'code' => $parameter["code"]
        ],$rescode);
		
    }
}
