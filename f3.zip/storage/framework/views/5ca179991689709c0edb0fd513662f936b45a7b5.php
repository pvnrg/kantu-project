<?php $__env->startSection('title',trans('issue.label.issues')); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="content-wrapper">
        <section id="basic-form-layouts">
            <div class="row">
                <div class="col-sm-12">
                    <div class="content-header"> <?php echo app('translator')->getFromJson($context.'.edit.title'); ?> </div>
                    
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo e(route('admin.'.$context.'s')); ?>">
                                <button type="button" class="btn btn-raised btn-success btn-min-width mr-1 mb-1">
                                    <i class="fa fa-angle-left"></i> <?php echo app('translator')->getFromJson($context.'.title'); ?>
                                </button>
                            </a>
                            <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => [ route('admin.'.$context.'s'), $item->id],
                            'style' => 'display:inline'
                            ]); ?>

                            <?php echo Form::button('<i class="fa fa-trash" aria-hidden="true"></i> '.trans('common.delete'), array(
                            'type' => 'submit',
                            'class' => 'btn btn-raised btn-danger btn-min-width mr-1 mb-1',
                            'title' => trans('common.delete'),
                            'onclick'=>"return confirm('".trans('common.js_msg.confirm_for_delete_data')."')"
                            )); ?>

                            <?php echo Form::close(); ?>

                        </div>
                        <div class="card-body">
                            <div class="px-3">
                                <?php echo Form::model($item, [
                                'method' => 'PATCH',
                                'url' => [route('admin.'.$context.'s.update',['roll'=>$item->id]), ],
                                'class' => 'form-horizontal',
                                'files' => true,
                                'autocomplete'=>'off'
                                ]); ?>

                                <?php echo $__env->make('admin.'.$context.'.form', ['submitButtonText' => trans('common.update')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo Form::close(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>