<?php $__env->startSection('title',trans('common.page.title.create.'.$context)); ?>
<?php $__env->startSection('content'); ?>
 <div class="main-content">
    <div class="content-wrapper">
    <section id="basic-form-layouts">
	<div class="row">
		<div class="col-sm-12">
			<div class="content-header"> <?php echo app('translator')->getFromJson(trans('common.page.title.create.'.$context)); ?> </div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<div class="actions pull-right">
                    </div>
                    <a href="<?php echo e(route('admin.'.$context)); ?>">
                        <button type="button" class="btn btn-raised btn-success btn-min-width mr-1 mb-1">
                            <i class="fa fa-angle-left"></i> <?php echo app('translator')->getFromJson($context.'.title'); ?>
                        </button>
                    </a>
				</div>
				<div class="card-body">
					<div class="px-3">
						<?php echo Form::open(['url' => route('admin.'.$context), 'class' => 'form-horizontal group-border-dashed','id' => 'module_form','autocomplete'=>'off','files'=>true]); ?>

							<?php echo Form::hidden('action',null,['id'=>'form_action','class'=>'form_action']); ?>

							<?php echo $__env->make('admin.'.$context.'.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<?php echo Form::close(); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
	</div>
</div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>

    $(document).ready(function () {
        $(".create").on('click',function(){
            $('.form_action').val('create');
        });
        $(".createandclose").on('click',function(){
            $('.form_action').val('createandclose');
        });
        $(".createandnew").on('click',function(){
            $('.form_action').val('createandnew');
        });
        $("#clear").on('click',function(){
            var textarea = $('textarea').attr('id') ;
            CKEDITOR.instances.textarea.setData('', function() { this.updateElement(); } )
        });
        $(".datepicker").datepicker();
    });
</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/system/create.blade.php ENDPATH**/ ?>