
<div class="form-group <?php echo e($errors->has($name) ? 'has-error' : ''); ?>">
    <label for="<?php echo e($name); ?>" class="">
        <span class="field_compulsory">*</span>
        <?php echo app('translator')->getFromJson($context.'.label.'.$name); ?> 
    </label>
    <div class="clear"></div>
    <div class="custom-control custom-checkbox">
        <?php echo Form::checkbox($name, $value, $selected, array_merge(['id'=>$name] , $attributes )  ); ?>

        
        
        <label for="<?php echo e($name); ?>" class="custom-control-label">
            <span class="field_compulsory">*</span>
            <?php echo app('translator')->getFromJson($context.'.form.'.$name); ?> 
        </label>
      </div> 
    <?php echo $errors->first($name, '<p class="help-block text-danger">:message</p>'); ?>

</div><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/components/form/checkbox.blade.php ENDPATH**/ ?>