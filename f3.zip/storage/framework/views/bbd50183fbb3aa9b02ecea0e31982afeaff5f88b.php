<?php $__env->startSection('title',trans('common.page.title.view.'.$context)); ?>

<?php $__env->startSection('content'); ?>



<div class="main-content">
    <div class="content-wrapper">
        <section id="basic-form-layouts">
            <div class="row">
                <div class="col-sm-12">
                    <div class="content-header"> <?php echo app('translator')->getFromJson('common.page.title.view.'.$context); ?> <?php if($item->name): ?> (<?php echo e($item->name); ?>) <?php endif; ?></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo e(route('admin.'.$context)); ?>">
                                <button type="button" class="btn btn-raised btn-success btn-min-width mr-1 mb-1">
                                    <i class="fa fa-angle-left"></i> <?php echo app('translator')->getFromJson($context.'.title'); ?>
                                </button>
                            </a>
                            <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['admin/'.$context, $item->id],
                            'style' => 'display:inline'
                            ]); ?>


                            <?php echo Form::button('<i class="fa fa-trash" aria-hidden="true"></i> '.trans('common.delete'), array(
                            'type' => 'submit',
                            'class' => 'btn btn-raised btn-danger btn-min-width mr-1 mb-1',
                            'title' => trans('common.delete'),
                            'onclick'=>"return confirm('".trans('common.js_msg.confirm_for_delete_data')."')"
                            )); ?>

                            <?php echo Form::close(); ?>

                        </div>
                        <div class="card-body">
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        <div class="table-responsive">


                                            <?php echo $__env->yieldContent('table'); ?>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/system/show.blade.php ENDPATH**/ ?>