
<div class="form-group <?php echo e($errors->has($name) ? 'has-error' : ''); ?>">
    <label for="<?php echo e($name); ?>" class="">
        <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.label.'.$name); ?> 
    </label>
    <?php echo Form::textarea($name, $value,array_merge(['id'=>$name] , $attributes )); ?>

    <?php echo $errors->first($name, '<p class="help-block text-danger">:message</p>'); ?>

</div><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/components/form/textarea.blade.php ENDPATH**/ ?>