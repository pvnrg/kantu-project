<div class="sidebar-content">
    <div class="nav-container">
        <ul id="main-menu-navigation" data-menu="menu-navigation" data-scroll-to-active="true" class="navigation navigation-main">
            <li class=" nav-item">
                <a href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="ft-home"></i>
                    <span data-i18n="" class="menu-title">Dashboard</span>
                </a>
            </li>
        </ul>
        <?php
            $menuItems = json_decode(getSession('admin-menu-json',''));
            if($menuItems != null && count($menuItems) > 0){
            echo renderAdminMenu($menuItems);
            }
        ?>
    </div>
</div>





<?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/layouts/admin/shared/sidebar.blade.php ENDPATH**/ ?>