<?php $__env->startSection('body_class',' pace-done'); ?>

<?php $__env->startSection('title',trans($context.'.title')); ?>

<?php $__env->startSection('content'); ?>

<div class="main-content">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-sm-12">
                <div class="content-header"> <?php echo app('translator')->getFromJson($context.'.title'); ?> <?php echo csrf_field(); ?> </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="col-md-6">
                            <a href="<?php echo e(url('/admin/employee/create')); ?>" title="Create">
                                <button class="btn btn-sm btn-space btn-success ">Add Employee</button>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <form method="GET" action="<?php echo e(\Request::url()); ?>"  id="filter_form">
                                <?php echo Form::hidden('from_date',$from_date, ['class' => 'form-control','id'=>'from_date']); ?>

                                <?php echo Form::hidden('to_date',$to_date, ['class' => 'form-control','id'=>'to_date']); ?>

                                    <div style="width: 100%">
                                        <div id="reportrange"  style="background: transparent; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%;height: 32px;">
                                            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                            <span></span> <b class="caret"></b>
                                        </div>
                                    </div>
                            </form>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="px-3">
                            <div class="box-content ">
                                <div class="row">
                                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                                        <aside class="profile-nav alt">
                                            <section class="card">
                                                <div class="card-body">
                                                    <div class="stat-widget-one employee">
                                                        <div class="stat-icon dib"><i class="fa fa-usd text-success border-success"></i></div>
                                                        <div class="stat-content dib">
                                                            <div class="stat-text">Amount Paid / Total User</div>
                                                            <div class="stat-digit">$<?php echo e($unit_sum); ?> / <?php echo e($for_user_sum); ?> <span class="font-size-12 duration_filter" > </span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </aside>
                                    </div>
                                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                                        <aside class="profile-nav alt">
                                            <section class="card">
                                                <div class="card-body">
                                                    <div class="stat-widget-one employee">
                                                        <div class="stat-icon dib"><i class="fa fa-usd text-success border-success"></i></div>
                                                        <div class="stat-content dib">
                                                            <div class="stat-text">Payable Amount / Total User</div>
                                                            <div class="stat-digit">$<?php echo e($approve_count*$peruser); ?> / <?php echo e($approve_count); ?></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </aside>
                                    </div>
                                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                                        <aside class="profile-nav alt">
                                            <section class="card">
                                                <div class="card-body">
                                                    <div class="stat-widget-one employee">
                                                        <div class="stat-icon dib"><i class="fa fa-user text-success border-success"></i></div>
                                                        <div class="stat-content dib">
                                                            <div class="stat-text">User Processed</div>
                                                            <div class="stat-digit"><?php echo e($total_approved_child); ?> <span class="font-size-12 duration_filter" > </span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </aside>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="px-3">
                            <div class="box-content ">
                                <div class="row">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                                        <aside class="profile-nav alt">
                                            <section class="card">
                                                <div class="card-header user-header alt bg-dark">
                                                    <div class="media">
                                                        <div class="media-body">
                                                            <h4 class="text-light display-6"><?php echo e($user->name); ?></h4>
                                                            <p>#<?php echo e($user->id); ?> <?php echo e($user->email); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <ul class="list-group list-group-flush">
                                                    <li class="list-group-item">
                                                        <?php if($user->employee->approve_count_total >0 ): ?>
                                                            <a title="User List Processed By Employee" href="<?php echo e(url('admin/employee/approvedBy/')); ?>/<?php echo e($user->id); ?>">
                                                                <i class="fa fa-bars"></i> Total User Processed
                                                                <span class="badge badge-success pull-right"><?php echo e($user->employee->approve_count_total); ?></span>
                                                            </a>
                                                        <?php else: ?>
                                                            <a href="#"> <i class="fa fa-bars"></i> Total User Processed
                                                                <span class="badge badge-primary pull-right"><?php echo e($user->employee->approve_count_total); ?></span>
                                                            </a>
                                                        <?php endif; ?>

                                                    </li>
                                                    <li class="list-group-item">
                                                        <a href="#"> <i class="fa fa-tasks"></i> User Processed(Not Paid) <span class="badge badge-danger pull-right"><?php echo e($user->employee->approved_count); ?></span></a>
                                                    </li>
                                                    <?php if($to_date && $from_date): ?>
                                                    <li class="list-group-item">
                                                        <a href="#"> <i class="fa fa-calendar"></i>  Processed <br/>(<?php echo e($from_date->format('M d,Y')); ?> - <?php echo e($to_date->format('M d,Y')); ?>)
                                                        <span class="badge badge-warning  pull-right"><?php echo e($user->badgeapprove->count()); ?></span>
                                                        </a>
                                                    </li>

                                                    <?php endif; ?>
                                                    <li class="list-group-item">
                                                        <?php if($user->employee->approved_count > 0): ?>
                                                        <a href="<?php echo e(url('admin/employee/payment', $user->id)); ?>" title="Click to pay employee" class="btn btn-success btn-sm " >
                                                            <i class="fa fa-money" aria-hidden="true"></i>
                                                        </a>&nbsp;
                                                        <?php else: ?>
                                                        <a href="javacript:void(0)" title="No enough credit for payment" class="btn btn-success btn-sm " >
                                                            <i class="fa fa-money" aria-hidden="true"></i>
                                                        </a>&nbsp;
                                                        <?php endif; ?>
                                                        <a href="<?php echo e(url('admin/employee')); ?>/<?php echo e($user->id); ?>">
                                                        <button class="btn btn-warning btn-sm" title="View">
                                                            <i class="fa fa-eye"></i></button>
                                                        </a>&nbsp;
                                                        <a href="<?php echo e(url('admin/employee')); ?>/<?php echo e($user->id); ?>/edit" class="btn btn-info btn-sm">
                                                            <i class="fa fa-pencil"></i>
                                                        </a>&nbsp;
                                                        <a href="javascript:void(0);" data-url=<?php echo e(url('admin/employee')); ?> data-msg='user' class="btn btn-danger btn-sm del-item" data-toggle="modal" data-target="#danger" data-id="<?php echo e($user->id); ?>"
                                                        data-url="#" data-msg="user" data-backdrop="static" data-keyboard="false">
                                                            <i class="fa fa-trash" aria-hidden="true"></i>
                                                        </a>&nbsp;

                                                    </li>
                                                </ul>
                                            </section>
                                        </aside>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
<script src="<?php echo e(asset('app-assets/vendors/js/sweetalert2.min.js')); ?>" type="text/javascript"></script>
<script src="https://secure.mysafetynet.info/backend/assets/js/moment.min.js"></script>
<script src="https://secure.mysafetynet.info/backend/assets/js/daterangepicker.js"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/sweetalert2.min.css')); ?>">
<link rel="stylesheet" href="https://secure.mysafetynet.info/backend/assets/css/themify-icons.css">
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
var url ="<?php echo e(url('/admin/employee/datatable')); ?>";
        var edit_url = "<?php echo e(url('/admin/employee')); ?>";
        var auth_check = "<?php echo e(Auth::check()); ?>";

        /*************************daterange selection*****************/

	var range_start = "";
    var range_end = "";

    var start = moment.utc('2017-01-01','YYYY-MM-DD');
    var end = moment();

	if($('#from_date').val() && $('#from_date').val() !="" && $('#to_date').val() && $('#to_date').val() !="" ){
		start = moment.utc($('#from_date').val(),'YYYY-MM-DD');
		end = moment.utc($('#to_date').val(),'YYYY-MM-DD');
	}
	$('.duration_filter').html("("+start.format('MMM D, YYYY') + ' - ' + end.format('MMM D, YYYY')+")");

    function cb(start, end) {
        $('#reportrange span').html(start.format('MMM D, YYYY') + ' - ' + end.format('MMM D, YYYY'));
        if(range_start==""){
            range_start = start.format('YYYY-MM-DD');
            range_end = end.format('YYYY-MM-DD');
        }else{
            range_start = start.format('YYYY-MM-DD');
            range_end = end.format('YYYY-MM-DD');

			$('#to_date').val(range_end);
			$('#from_date').val(range_start);

			$('#filter_form').submit();



            //datatable.fnDraw();
        }
		$('#to_date').val(range_end);
		$('#from_date').val(range_start);

    }

    $('#reportrange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
            "All":[moment.utc('2017-01-01','YYYY-MM-DD'),moment()],
            "Today": [moment(), moment()],
            "This Week": [moment().startOf('week'), moment().endOf('week')],
            "Last Week": [moment().subtract(1, 'week').startOf('week'), moment().subtract(1, 'week').endOf('week')],
            "This Month": [moment().startOf('month'), moment().endOf('month')],
            "Last Month": [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]

        }
    }, cb);

       cb(start, end);



    $(document).on('click', '.del-item', function (e) {
        var id = $(this).attr('data-id');
        swal({
            title: 'Are you sure?',
            text: "<?php echo app('translator')->getFromJson('common.js_msg.confirm_for_delete_data'); ?>",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#0CC27E',
            cancelButtonColor: '#FF586B',
            confirmButtonText: 'Yes',
            cancelButtonText: "No, cancel"
        }).then(function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    type: "DELETE",
                    url: "<?php echo e(route('admin.'.$context)); ?>" + "/" + id,
                    headers: {
                        "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                    },
                    success: function (data) {
                        window.location = "<?php echo e(route('admin.'.$context)); ?>"
                        swal({
                            type: 'success',
                            title: "Success",
                            text: "<?php echo app('translator')->getFromJson('common.js_msg.action_success'); ?>",
                            timer: 2000,
                            showConfirmButton: false
                        });
                    },
                    error: function (xhr, status, error) {
                        swal({
                            type: 'error',
                            title: "Error",
                            text: "<?php echo app('translator')->getFromJson('common.js_msg.action_not_procede'); ?>",
                            timer: 2000,
                            showConfirmButton: false
                        });
                    }
                });
            }
        }).catch(swal.noop);
    });


</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/employee/index.blade.php ENDPATH**/ ?>