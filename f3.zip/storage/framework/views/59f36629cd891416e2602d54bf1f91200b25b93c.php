

<?php
    $attributes = array_merge(['id'=>$name] , $attributes );
?>
<div class="form-group <?php echo e($errors->has($name) ? 'has-error' : ''); ?>">
    <label for="<?php echo e($attributes['id']); ?>" class="">
        <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.label.'.$attributes['id']); ?> 
    </label>
    <?php echo Form::text($name, $value , $attributes  ); ?>

    <?php echo $errors->first($name, '<p class="help-block text-danger">:message</p>'); ?>

</div><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/components/form/text.blade.php ENDPATH**/ ?>