<div class="row ">
    <div class="col-md-6">
            
            <?php echo e(Form::cbText('title')); ?>


            <?php echo e(Form::cbButtons(trans($context.'.form.create'), trans($context.'.form.clear') )); ?>    
    </div>
</div>
<?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/permissions/form.blade.php ENDPATH**/ ?>