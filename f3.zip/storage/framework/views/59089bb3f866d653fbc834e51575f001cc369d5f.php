<?php $__env->startSection('table'); ?>
    

<table class="table table-striped">
    <tbody>
      
               
        <tr>
            <th><?php echo app('translator')->getFromJson('common.title'); ?></th>
            <td><?php echo e($item->title); ?></td>
        </tr>
   
        <tr>
            <th><?php echo app('translator')->getFromJson('common.admin'); ?></th>
            <td><?php echo e($item->admin); ?></td>
        </tr>

       
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.system.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/rolls/show.blade.php ENDPATH**/ ?>