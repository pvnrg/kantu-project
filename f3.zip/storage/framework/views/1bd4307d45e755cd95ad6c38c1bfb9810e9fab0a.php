<div class="row ">

    <div class="col-md-6">
		<div class="form-group <?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
            <label for="first_name" >
                <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.create.field.first_name'); ?>
            </label>
            <div >
			<?php echo Form::text('first_name', @$item->first_name , ['class' => 'first_name form-control','id'=>'first_name','style'=>'width:100%']); ?>


				<?php echo $errors->first('first_name', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
            <label for="last_name" >
                <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.create.field.last_name'); ?>
            </label>
            <div >
			<?php echo Form::text('last_name', @$item->last_name, ['class' => 'last_name form-control','id'=>'last_name','style'=>'width:100%']); ?>


				<?php echo $errors->first('last_name', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <label for="email" >
                <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.create.field.email'); ?>
            </label>
            <div >
			<?php echo Form::text('email', @$item->email , ['class' => 'email form-control','id'=>'email','style'=>'width:100%', 'disabled' => isset($item->email) ? true : false ]); ?>


				<?php echo $errors->first('email', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
    </div>

    <?php if( !isset($item) ): ?>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <label for="password" >
                <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.create.field.password'); ?>
            </label>
            <div >
            <?php echo Form::password('password', ['class' => 'password form-control','id'=>'password','style'=>'width:100%']); ?>


                <?php echo $errors->first('password', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
            <label for="username" >
                <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.create.field.username'); ?>
            </label>
            <div >
			<?php echo Form::text('username', @$item->username, ['class' => 'form-control','style'=>'width:100%']); ?>


			<?php echo $errors->first('username', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
            <label for="phone" >
                <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.create.field.phone'); ?>
            </label>
            <div >
			<?php echo Form::text('phone', @$item->phone, ['class' => 'form-control','style'=>'width:100%']); ?>


			<?php echo $errors->first('phone', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
            <label for="gender" >
                <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.create.field.gender'); ?>
            </label>
            <div >
            Male <?php echo Form::radio('gender','male', isset($item->gender) && $item->gender == "male" ? true : false ); ?>

            Female <?php echo Form::radio('gender','female', isset($item->gender) && $item->gender == "female" ? true : false); ?>


			<?php echo $errors->first('gender', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('pan_number') ? ' has-error' : ''); ?>">
            <label for="pan_number" >
                <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.create.field.pan_number'); ?>
            </label>
            <div >
            <?php echo Form::text('pan_number', @$item->pan_number, ['class' => 'form-control','style'=>'width:100%']); ?>


			<?php echo $errors->first('pan_number', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('dob') ? ' has-error' : ''); ?>">
            <label for="dob" >
                <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.create.field.dob'); ?>
            </label>
            <div >
			<?php echo Form::text('dob', @$item->dob, ['class' => 'datepicker form-control','readonly'=>true,'style'=>'width:100%']); ?>


				<?php echo $errors->first('dob', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
    </div>

    <div class="col-md-6" style="display:none;">
        <div class="form-group <?php echo e($errors->has('documents') ? ' has-error' : ''); ?>">
            <label for="documents" >
                <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson($context.'.create.field.documents'); ?>
            </label>
            <div >
			<?php echo Form::file('documents[]', ['class' => 'form-control', 'multiple'=>true ]); ?>

			<?php echo $errors->first('documents', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
        <?php if(isset($item)): ?>
        <?php $__currentLoopData = $item->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refefile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($refefile->file_url): ?>
            <table>
                <tr>
                    <th> <a href="<?php echo e(url(''.$refefile->file_url)); ?>" title="View Document" target="_blank" > <?php echo e($refefile->refe_file_name); ?> </a> </th>
                    
                </tr>
            </table>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
            <label for="image" >
                <?php echo app('translator')->getFromJson('Profile image'); ?>
            </label>
            <div >
			<?php echo Form::file('image', null, ['class' => 'image form-control' ,'id'=>'image','style'=>'width:100%']); ?>

				<?php echo $errors->first('image', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
        <?php if(isset($item) && $item->profileimg): ?><a href="<?php echo e($item->profile_pic_thumb); ?>" target="_blank"><img src="<?php echo e($item->profile_pic_thumb); ?>" class="user-img" /></a> <?php endif; ?>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : trans('common.create'), ['class' => 'btn btn-primary form_submit image_submit_btn']); ?>

            <?php if(!isset($submitButtonText)): ?>
            <?php echo e(Form::reset(trans('common.clear_form'), ['class' => 'btn btn-light'])); ?>

            <?php endif; ?>
        </div>
    </div>

      




</div>






<?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/user/form.blade.php ENDPATH**/ ?>