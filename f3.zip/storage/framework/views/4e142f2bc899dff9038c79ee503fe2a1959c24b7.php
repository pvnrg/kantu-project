<div class="row ">
    <div class="col-md-6">

            <?php echo e(Form::cbText('title')); ?>


            <?php echo e(Form::cbNumber('actual_amount')); ?>


            <?php echo e(Form::cbNumber('show_amount')); ?>


            <?php echo e(Form::cbTextarea('description')); ?>


            <?php echo e(Form::cbSelect('type', ['' => 'Select Type','free' => 'Free', 'yearly' => 'Yearly', 'daily' => 'Daily', 'weekly' => 'Weekly', 'special_yearly' =>'Special Yearly', 'special_lifetime' => 'Special Lifetime'])); ?>


            <?php echo e(Form::cbSelect('status', Config::get('admin.status'))); ?>


            <?php echo e(isset($submitButtonText) ?  Form::cbButtons($submitButtonText) :  Form::cbButtons()); ?>

    </div>
</div>
<?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/plan/form.blade.php ENDPATH**/ ?>