<?php $__env->startSection('fields'); ?> 
    <?php

        $fields = [
            
                 'title' => [
                        'data'=> '"title"',
                        'name'=> '"title"',
                        'searchable'=> 'true', 
                        'orderable'=> 'true'
                    ],

                 'admin' => [
                        'data'=> '"admin"',
                        'name'=> '"admin"',
                        'searchable'=> 'true', 
                        'orderable'=> 'true'
                    ],

        ];
    ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.system.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/rolls/index.blade.php ENDPATH**/ ?>