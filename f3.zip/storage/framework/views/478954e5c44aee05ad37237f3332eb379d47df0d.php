<?php $__env->startSection('body_class',' pace-done'); ?>

<?php $__env->startSection('title',trans($context.'.title')); ?>

<?php $__env->startSection('content'); ?>

<!-- <div class="row">
    <div class="col-sm-12">
        <div class="content-header"> <?php echo app('translator')->getFromJson($context.'.title'); ?> </div>

    </div>
</div> -->
<div class="main-content">

    <div class="content-wrapper">

        <div class="row">
            <div class="col-sm-12">
                <div class="content-header"> <?php echo app('translator')->getFromJson($context.'.title'); ?> <?php echo e($module); ?> </div>

            </div>
        </div>

        <section id="configuration">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">

                            <div class="row">

                                <div class="col-6">
                                    <div class="actions pull-left">

                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="card-body collapse show">

                            <div class="card-block card-dashboard">


                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped datatable responsive">
                                        <thead>
                                            <tr>
                                                <th>  </th>
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th> <?php echo e($permission->title); ?> </th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $rolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                    <td>
                                                        <?php echo e($roll->title); ?>

                                                    </td>
                                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td>

                                                        <input type="checkbox" class="changepermission" data-roll="<?php echo e($roll->id); ?>" data-permission="<?php echo e($permission->id); ?>" data-module="<?php echo e($module); ?>" <?php echo e(checkpermission($roll->id,$permission->id,$module) ? 'checked="checked"':''); ?>  />

                                                    </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##


<script src="<?php echo e(asset('app-assets/vendors/js/datatable/datatables.min.js')); ?>" type="text/javascript"></script>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/tables/datatable/datatables.min.css')); ?>">

<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
<script>
jQuery(document).ready(function () {
    $('.changepermission').on("click",function(){

        var roll = $(this).attr('data-roll');
        var permission = $(this).attr('data-permission');
        var module = $(this).attr('data-module');
        var check = $(this).is(':checked');

        console.log(check);

        $.ajax({
            method: "POST",
            url: "<?php echo e(route('admin.rollpermissions.update')); ?>",
            data : {
            'roll' : roll,
            'permission' : permission,
            'module' : module,
            'check' : check,
            '_token' : '<?php echo e(csrf_token()); ?>'
            }
        })
        .done(function( html ) {
            $( "#results" ).append( html );
        });

    });
});

</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/rollpermission/index.blade.php ENDPATH**/ ?>