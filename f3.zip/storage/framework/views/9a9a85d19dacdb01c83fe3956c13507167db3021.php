<!DOCTYPE html>
<html lang="en" class="loading">
  <!-- BEGIN : Head-->
<head>
<?php $__env->startSection('head'); ?>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('/app-assets/img/ico/apple-icon-60.png')); ?>">
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('/app-assets/img/ico/apple-icon-76.png')); ?>">
  <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('/app-assets/img/ico/apple-icon-120.png')); ?>">
  <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('/app-assets/img/ico/apple-icon-152.png')); ?>">
  
  <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('/app-assets/img/ico/favicon.png')); ?>">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-touch-fullscreen" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="default">
<?php echo $__env->yieldSection(); ?>

<?php $__env->startSection('seo'); ?>

  <title><?php echo $__env->yieldContent('title'); ?><?php echo e(@$seo['title'].' | '.config('app.name', 'BSE')); ?></title>
  <meta name="description" content="<?php echo e(@$seo['description']); ?>">
  <meta name="author" content="Citrusbug Technolabs">
  <!-- Facebook -->
  <meta property="og:title" content="<?php echo e(@$seo['title']); ?>"/>
  <meta property="og:type" content="<?php echo e(@$seo['og_type']); ?>"/>
  <meta property="og:url" content="<?php echo e(@$seo['url']); ?>"/>
  <meta property="og:image" content="<?php echo e(@$seo['og_image']); ?>"/>
  <meta property="fb:admins" content="<?php echo e(@$seo['fb_admins']); ?>"/>
  <meta property="fb:app_id" content="<?php echo e(@$seo['fb_admins']); ?>"/>
  <meta property="og:site_name" content="<?php echo e(@$seo['site_name']); ?>"/>
  <meta property="og:description" content="<?php echo e(@$seo['description']); ?>"/>
  <!-- Twitter -->
  <meta name="twitter:card" content="<?php echo e(@$seo['twitter_card']); ?>" />
  <meta name="twitter:site" content="<?php echo e('@'.@$seo['site_name']); ?>" />
  <meta name="twitter:title" content="<?php echo e(@$seo['title']); ?>" />
  <meta name="twitter:description" content="<?php echo e(@$seo['description']); ?>" />
  <meta name="twitter:image" content="<?php echo e(@$seo['og_image']); ?>" />
<?php echo $__env->yieldSection(); ?>

<?php $__env->startSection('css'); ?>
  <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700,900|Montserrat:300,400,500,600,700,800,900" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/admin/admin.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/admin/bootstrap-datepicker.css')); ?>">
<?php echo $__env->yieldSection(); ?>
<?php echo $__env->yieldPushContent('css'); ?>


</head>

    <body data-col="2-columns" class= "2-columns    <?php echo e((getSession('theme-layout') == 'transparent' )  ? ( ' layout-dark '.'layout-'.getSession('theme-layout').' '.getSession('theme-transparent-bg', 'bg-glass-1') )  : ( 'layout-'.getSession('theme-layout'))); ?> ">

        <div class="wrapper <?php echo e(getSession('compact-menu') == '1' ? 'nav-collapsed menu-collapsed' : ''); ?> <?php echo e(getSession('sidebar-width')); ?>">

            <!-- Image loader -->
            <div id='loader' style='display: none;'>
            <img src='<?php echo e(asset('assets/images/loading.gif')); ?>'>
            </div>

            <!-- main menu-->
            <!--.main-menu(class="#{menuColor} #{menuOpenType}", class=(menuShadow == true ? 'menu-shadow' : ''))-->
            <div data-active-color="<?php echo e(getSession('theme-layout') == 'transparent' ? 'black' : getSession('bg-color')); ?>" data-background-color="<?php echo e(getSession('theme-layout') == 'transparent' ? 'black' : getSession('bg-color')); ?>" data-image="<?php echo e(getSession('theme-layout') == 'transparent' ? '' : asset( getSession('sidebar-background') )); ?>" class="app-sidebar">

                <!-- main menu header-->
                <!-- Sidebar Header starts-->
                <?php echo $__env->make('layouts.admin.shared.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Sidebar Header Ends-->
                <!-- / main menu header-->
                <!-- main menu content-->
                <?php echo $__env->make('layouts.admin.shared.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- main menu content-->
                <div class="sidebar-background" style="background-image: url('<?php echo e(getSession('theme-layout') == 'transparent' ? '' : asset( getSession('sidebar-background') )); ?>')" ></div>
                <!-- main menu footer-->
                <!-- include includes/menu-footer-->
                <!-- main menu footer-->
            </div>
            <!-- / main menu-->

            <?php echo $__env->make('layouts.admin.shared.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main-panel">
            <!-- BEGIN : Main Content-->
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>


    <?php echo $__env->make('layouts.admin.shared.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.admin.shared.customizer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('/js/admin/admin.js')); ?>" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/admin/bootstrap/bootstrap-datepicker.js')); ?>"></script>

    <?php echo $__env->yieldSection(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <div class="modal fade text-left" id="media-manager" tabindex="-1" role="dialog" aria-labelledby="myModalLabel5" aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
          <div class="modal-content">
            <div class="modal-body">
              <iframe src="/media-manager?type=Images" width="100%" height="700px" frameborder="0"></iframe>
            </div>
          </div>
        </div>
    </div>
    <div class="modal fade text-left" id="file-manager" tabindex="-1" role="dialog" aria-labelledby="myModalLabel5" aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
          <div class="modal-content">
            <div class="modal-body">
              <iframe src="/media-manager?type=Files" width="100%" height="700px" frameborder="0"></iframe>
            </div>
          </div>
        </div>
    </div>
</body>


<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('js/admin/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<!-- DataTables -->
<script src="<?php echo e(asset('js/admin/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin/datatables-bs4/js/dataTables.bootstrap4.js')); ?>"></script>

<script>
    CKEDITOR.replace( 'article-ckeditor' );
</script>

</html>
<?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/layouts/admin/index.blade.php ENDPATH**/ ?>