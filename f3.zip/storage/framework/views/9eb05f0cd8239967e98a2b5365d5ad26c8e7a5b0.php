<?php $__env->startSection('body_class',' pace-done'); ?>

<?php $__env->startSection('title',trans($context.'.title')); ?>

<?php $__env->startSection('content'); ?>

<!-- <div class="row">
    <div class="col-sm-12">
        <div class="content-header"> <?php echo app('translator')->getFromJson($context.'.title'); ?> </div>

    </div>
</div> -->
<div class="main-content">

    <div class="content-wrapper">

        <div class="row">
            <div class="col-sm-12">
                <div class="content-header"> <?php echo app('translator')->getFromJson($context.'.title'); ?> <?php echo csrf_field(); ?> </div>

            </div>
        </div>

        <section id="configuration">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">

                            <div class="row">

                                <div class="col-6">
                                    <div class="actions pull-left">

                                    </div>
                                </div>
                                <div class="col-6">
                                    <?php echo $__env->make("layouts.admin.shared.filter_deleted", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-body collapse show">

                            <div class="card-block card-dashboard">


                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped datatable responsive">
                                        <thead>
                                            <tr>
                                                <th># <?php echo app('translator')->getFromJson('common.id'); ?></th>
                                                <th><?php echo app('translator')->getFromJson('common.log_type'); ?></th>
                                                <th><?php echo app('translator')->getFromJson('common.status_code'); ?></th>
                                                <th><?php echo app('translator')->getFromJson('common.total_count'); ?></th>
                                                <th><?php echo app('translator')->getFromJson('common.slug'); ?></th>
                                                <th><?php echo app('translator')->getFromJson('common.created_at'); ?></th>
                                                <th><?php echo app('translator')->getFromJson('common.action'); ?></th>

                                            </tr>
                                        </thead>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
<script src="<?php echo e(asset('app-assets/vendors/js/datatable/datatables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('app-assets/vendors/js/sweetalert2.min.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/tables/datatable/datatables.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/sweetalert2.min.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('app-assets/js/moment.js')); ?>" type="text/javascript"></script>
<script>

	var statues = <?php echo json_encode(trans('survey.status')); ?>;
	var currency = <?php echo json_encode(trans('seos.currency')); ?>;


	var url ="<?php echo e(route('admin.'.$context)); ?>";
    var edit_url = "<?php echo e(route('admin.'.$context)); ?>";
    var auth_check = "<?php echo e(\Auth::check()); ?>";

	var auth_uid = <?php echo e(\Auth::user()->id); ?>;

    datatable = $('.datatable').dataTable({
        pagingType: "full_numbers",
        "language": {
            "emptyTable":"<?php echo app('translator')->getFromJson('common.datatable.emptyTable'); ?>",
            "infoEmpty":"<?php echo app('translator')->getFromJson('common.datatable.infoEmpty'); ?>",
            "search": "<?php echo app('translator')->getFromJson('common.datatable.search'); ?>",
            "sLengthMenu": "<?php echo app('translator')->getFromJson('common.datatable.show'); ?> _MENU_ <?php echo app('translator')->getFromJson('common.datatable.entries'); ?>",
            "sInfo": "<?php echo app('translator')->getFromJson('common.datatable.showing'); ?> _START_ <?php echo app('translator')->getFromJson('common.datatable.to'); ?> _END_ <?php echo app('translator')->getFromJson('common.datatable.of'); ?> _TOTAL_ <?php echo app('translator')->getFromJson('common.datatable.small_entries'); ?>",
            paginate: {
                next: '<?php echo app('translator')->getFromJson('common.datatable.paginate.next'); ?>',
                previous: '<?php echo app('translator')->getFromJson('common.datatable.paginate.previous'); ?>',
                first:'<?php echo app('translator')->getFromJson('common.datatable.paginate.first'); ?>',
                last:'<?php echo app('translator')->getFromJson('common.datatable.paginate.last'); ?>',
            }
        },
        processing: true,
        serverSide: true,
        autoWidth: false,
        stateSave: true,
        order: [0, "desc"],
        columns: [
                { data: 'id',name : 'id',"searchable": true, "orderable": true},
                { data: 'log_type',name : 'log_type',"searchable": true, "orderable": true},
                { data: 'status_code',name : 'status_code',"searchable": true, "orderable": true},
                { data: 'total_count',name : 'total_count',"searchable": true, "orderable": true},
                { data: 'slug',name : 'slug',"searchable": true, "orderable": true},
                {
                    "data": 'created_at',  "name": 'created_at', 'orderable' : true, "searchable": true,
                    "render": function(data, type) {
                        if(type == 'display')
                            return moment(data).format('Do MMMM  YYYY, h:mm a');
                        else
                            return data;
                    }
                },
                {
                    "data": null,
                    "searchable": false,
                    "orderable": false,
                    "width":150,
                    "render": function (o) {
                        var e=""; var v=""; var d= "";
                        v = "<a href='"+edit_url+"/"+o.id+"/' value="+o.id+" data-id="+o.id+" ><button class='btn btn-info btn-sm' title='<?php echo app('translator')->getFromJson('common.tooltip.icon.eye'); ?>' ><i class='fa fa-eye' ></i></button></a>&nbsp;";

                        d = "<a href='javascript:void(0);' class='btn btn-danger btn-sm del-log' title='<?php echo app('translator')->getFromJson('common.tooltip.icon.delete'); ?>'  data-id="+o.id+" ><i class='fa fa-trash' aria-hidden='true'></i></a>&nbsp;";
                        return v+e+d;
                    }

                }
         ],
        fnRowCallback: function (nRow, aData, iDisplayIndex) {
            $('td', nRow).attr('nowrap', 'nowrap');
            return nRow;
        },
        ajax: {
            url: "<?php echo e(route('admin.'.$context.'.datatable')); ?>", // json datasource
            type: "post", // method , by default get
            data: function (d) {
                <?php if(request()->has('force')): ?>
					d.enable_deleted = ($('#is_deleted_record').is(":checked")) ? 1 : 0;
                <?php endif; ?>
                d._token = '<?php echo e(csrf_token()); ?>'
            }
        }
    });

    $('.filter').change(function() {
        datatable.fnDraw();
    });
	$('#is_deleted_record').change(function() {
		datatable.fnDraw();
    });

    $(document).on('click', '.del-log', function (e) {
        var id = $(this).attr('data-id');
        swal({
            title: 'Are you sure?',
            text: "<?php echo app('translator')->getFromJson('common.js_msg.confirm_for_delete_data'); ?>",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#0CC27E',
            cancelButtonColor: '#FF586B',
            confirmButtonText: 'Yes',
            cancelButtonText: "No, cancel"
        }).then(function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    type: "DELETE",
                    url: "<?php echo e(route('admin.'.$context)); ?>" + "/" + id,
                    headers: {
                        "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                    },
                    success: function (data) {
                        datatable.fnDraw();
                        swal({
                            type: 'success',
                            title: "Success",
                            text: "<?php echo app('translator')->getFromJson('common.js_msg.action_success'); ?>",
                            timer: 2000,
                            showConfirmButton: false
                        });
                    },
                    error: function (xhr, status, error) {
                        swal({
                            type: 'error',
                            title: "Error",
                            text: "<?php echo app('translator')->getFromJson('common.js_msg.action_not_procede'); ?>",
                            timer: 2000,
                            showConfirmButton: false
                        });
                    }
                });
            }
        }).catch(swal.noop);
    });


</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/logs/index.blade.php ENDPATH**/ ?>