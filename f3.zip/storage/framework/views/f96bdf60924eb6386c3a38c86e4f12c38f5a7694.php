<?php $__env->startSection('title',trans($context.'.create.title')); ?>
<?php $__env->startPush('css'); ?>
<style>
    .user-img{
        width: 100px;
        height: 100px;
        border-radius: 50%;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
 <div class="main-content">
    <div class="content-wrapper">
    <section id="basic-form-layouts">
	<div class="row">
		<div class="col-sm-12">
			<div class="content-header"> <?php echo app('translator')->getFromJson($context.'.create.title'); ?> </div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<div class="actions pull-right">
					</div>
				</div>
				<div class="card-body">
					<div class="px-3">
						<?php echo Form::open(['url' => route('admin.'.$context.'s'), 'class' => 'form-horizontal group-border-dashed','id' => 'module_form','autocomplete'=>'off','files'=>true]); ?>

								<?php echo $__env->make('admin.'.$context.'.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<?php echo Form::close(); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $(".datepicker").datepicker({
            format : 'yyyy-mm-dd'
        });
    });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/user/create.blade.php ENDPATH**/ ?>