<div class="row ">


    <?php echo Form::hidden('module', $module ); ?>

   
    <div class="col-md-6">
      
        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
            <label for="url" class="">
                <span class="field_compulsory">*</span><?php echo app('translator')->getFromJson('settings.label.fkey'); ?>
            </label>

            <?php echo Form::text('fkey', null,['id'=>'fkey','class' => 'form-control']); ?>

            

			<?php echo $errors->first('url', '<p class="help-block text-danger">:message</p>'); ?>

        </div>
 
		
		<div class="form-group<?php echo e($errors->has('fvalue') ? ' has-error' : ''); ?>">
            <label for="description" >
                <span class="field_compulsory"></span><?php echo app('translator')->getFromJson('settings.label.fvalue'); ?>
            </label>
            <div >
                


                <?php if(@$item->ftype == 'text'): ?>
                <?php echo Form::text('fvalue', null , ['id'=>'fvalue','class' => 'form-control']); ?>

                <?php elseif(@$item->ftype == 'textarea'): ?>
                <?php echo Form::textarea('fvalue', null , ['id'=>'fvalue','class' => 'form-control']); ?>

                <?php elseif(@$item->ftype == 'editor'): ?>
                <?php echo Form::textarea('fvalue', null , ['id'=>'fvalue','class' => 'form-control editor']); ?>

                <?php elseif(@$item->ftype == 'image'): ?>
                
                 

                <div class="input-group">
                    <span class="input-group-btn">
                        <a id="lfm" data-input="fvalue" data-preview="holder" class="btn btn-primary">
                        <i class="fa fa-picture-o"></i> Choose
                        </a>
                    </span>
                    <input id="fvalue" name="fvalue" class="form-control" type="text" value="<?php echo e(@$item->fvalue); ?>" name="filepath">
                </div>
                <img id="holder" src="<?php echo e(@$item->fvalue); ?>"  style="margin-top:15px;max-height:100px;">

                <?php else: ?>
                <?php echo Form::textarea('fvalue', null , ['id'=>'fvalue','class' => 'form-control']); ?>

                <?php endif; ?>


				<?php echo $errors->first('fvalue', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group">
            <label for="description" >
                <span class=""></span><?php echo app('translator')->getFromJson('settings.label.finformation'); ?>
            </label>
            <?php if(getSess('is_super_admin')): ?>
            <div >
                <?php echo Form::textarea('finformation', null , ['id'=>'finformation','class' => 'form-control']); ?>

				<?php echo $errors->first('finformation', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
            <?php else: ?>
            <div >
                
                <?php echo @$item->finformation; ?>


            </div>
            <?php endif; ?>
            
        </div>

        <?php if(getSess('is_super_admin')): ?>
        <div class="form-group">
            <label for="description" >
                <span class=""></span><?php echo app('translator')->getFromJson('settings.label.ftype'); ?>
            </label>
            <div >
                <?php echo Form::select('ftype',array('text' => 'Text', 'textarea' => 'Textarea', 'image' => 'Image','editor' => 'Editor'), null , ['id'=>'ftype','class' => 'form-control','disabled'=> !getSess('is_super_admin')]); ?>

				<?php echo $errors->first('ftype', '<p class="help-block text-danger">:message</p>'); ?>

            </div>
        </div>
        <?php endif; ?>
		
		 
		
		<div class="form-group">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : trans('common.label.create'), ['class' => 'btn btn-primary']); ?>

        <?php echo e(Form::reset(trans('common.label.clear_form'), ['class' => 'btn btn-light'])); ?>

        </div>
   
        
    </div>
   
    
</div>


<?php if(@$item->ftype == 'editor'): ?>
<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
<script src="//cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
  var options = {
    filebrowserImageBrowseUrl: '/media-manager?type=Images',
    filebrowserImageUploadUrl: '/media-manager/upload?type=Images&_token=',
    filebrowserBrowseUrl: '/media-manager?type=Files',
    filebrowserUploadUrl: '/media-manager/upload?type=Files&_token='
  };
 
CKEDITOR.replace('fvalue', options);
// $('textarea#desc').ckeditor(options);
</script>
 
<?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/settings/form.blade.php ENDPATH**/ ?>