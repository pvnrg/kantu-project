<?php $__env->startSection('content'); ?>

<div class="main-content">

    <div class="content-wrapper">
        <!--Statistics cards Starts-->
        <div class="row">
            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
                <div class="card gradient-blackberry">
                    <a href="<?php echo e(route('admin.users')); ?>">
                    <div class="card-content">
                        <div class="card-body pt-2 pb-0">
                            <div class="media">
                                <div class="media-body white text-left">
                                    <h3 class="font-large-1 mb-0"><?php echo e($total_users); ?></h3>
                                    <span>Total Users</span>
                                </div>
                                <div class="media-right white text-right">
                                    <i class="icon-pie-chart font-large-1"></i>
                                </div>
                            </div>
                        </div>
                        <div id="Widget-line-chart" class="height-75 WidgetlineChart WidgetlineChartshadow mb-2">
                        </div>
                    </div>
                    </a>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
                <div class="card gradient-ibiza-sunset">
                    <a href="<?php echo e(route('admin.users').'?type=subscribers'); ?>">
                    <div class="card-content">
                        <div class="card-body pt-2 pb-0">
                            <div class="media">
                                <div class="media-body white text-left">
                                    <h3 class="font-large-1 mb-0"><?php echo e($total_subscribers); ?></h3>
                                    <span>Total Subscribers</span>
                                </div>
                                <div class="media-right white text-right">
                                    <i class="icon-bulb font-large-1"></i>
                                </div>
                            </div>
                        </div>
                        <div id="Widget-line-chart1" class="height-75 WidgetlineChart WidgetlineChartshadow mb-2">
                        </div>

                    </div>
                    </a>
                </div>
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
                <div class="card gradient-green-tea">
                    <a href="<?php echo e(route('admin.orders').'?type=one-time'); ?>">
                    <div class="card-content">
                        <div class="card-body pt-2 pb-0">
                            <div class="media">
                                <div class="media-body white text-left">
                                    <h3 class="font-large-1 mb-0">$ <?php echo e($total_one_time_fees); ?></h3>
                                    <span>Total One time Fees</span>
                                </div>
                                <div class="media-right white text-right">
                                    <i class="icon-graph font-large-1"></i>
                                </div>
                            </div>
                        </div>
                        <div id="Widget-line-chart2" class="height-75 WidgetlineChart WidgetlineChartshadow mb-2">
                        </div>
                    </div>
                    </a>
                </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
                <div class="card gradient-pomegranate">
                        <a href="<?php echo e(route('admin.orders').'?type=subscription'); ?>">
                    <div class="card-content">
                        <div class="card-body pt-2 pb-0">
                            <div class="media">
                                <div class="media-body white text-left">
                                    <h3 class="font-large-1 mb-0">$ <?php echo e($total_subscription_amount); ?></h3>
                                    <span>Total Subscription Amount</span>
                                </div>
                                <div class="media-right white text-right">
                                    <i class="icon-wallet font-large-1"></i>
                                </div>
                            </div>
                        </div>
                        <div id="Widget-line-chart3" class="height-75 WidgetlineChart WidgetlineChartshadow mb-2">
                        </div>
                    </div>
                        </a>
                </div>
            </div>
        </div>
        <!--Statistics cards Ends-->

        <!--Line with Area Chart 1 Starts-->
        
        <!--Line with Area Chart 1 Ends-->

        

        

        

    </div>
</div>
<!-- END : End Main Content-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
 ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
 <script src="<?php echo e(asset('app-assets/js/dashboard1.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
 ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
 <script src="<?php echo e(asset('app-assets/js/dashboard1.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>