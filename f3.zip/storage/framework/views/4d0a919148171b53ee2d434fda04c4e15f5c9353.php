<?php if(request()->has('force')): ?>
	<div class="pull-right">
		<label for="is_deleted_record" class="font-medium-2 text-bold-600 ml-1 "><?php echo app('translator')->getFromJson('common.label.deleted_decord'); ?></label>
		<input type="checkbox" id="is_deleted_record" class="switchery" />
	</div>
<?php endif; ?><?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/layouts/admin/shared/filter_deleted.blade.php ENDPATH**/ ?>