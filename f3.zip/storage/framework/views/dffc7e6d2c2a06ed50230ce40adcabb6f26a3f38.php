<div class="form-group">

    <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : trans('common.label.create'), array_merge(['id'=>'create', 'class'=>'btn btn-primary create'] , $attributes )); ?>

    <?php echo Form::submit( isset($submitButtonText) ? trans('common.label.updateandclose') : trans('common.label.createandclose'), array_merge(['id'=>'createandclose', 'class'=>'btn btn-dark createandclose'] , $attributes )); ?>

    <?php echo Form::submit( isset($submitButtonText) ? trans('common.label.updateandnew') : trans('common.label.createandnew'), array_merge(['id'=>'createandnew', 'class'=>'btn btn-dark createandnew'] , $attributes )); ?>

    <?php if(!isset($submitButtonText)): ?>
    <?php echo e(Form::reset(isset($clearButtonText) ? $clearButtonText : trans('common.label.clear_form'), array_merge(['id'=>'clear', 'class'=>'btn btn-secondary', "onClick" => "CKEDITOR.instances.detail.setData( '', function() { this.updateElement(); } ) " ] , $attributes ))); ?>

    <?php endif; ?>
</div>
<?php /**PATH G:\xampp\htdocs\mysafety-adult\resources\views/admin/components/form/buttons.blade.php ENDPATH**/ ?>