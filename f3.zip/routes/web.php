<?php


// $q = "UPDATE `users` SET `phone_verified` = 0 WHERE `email` LIKE '%jignesh.citrusbug@gmail.com%'" ;
// 			\DB::statement($q);
// 	/*
// 			$q = "UPDATE `users` SET `phone` = '9998543611' WHERE `users`.`phone` = '9998543618';" ;
// 			\DB::statement($q);
// 			*/
// 			dd($q);


Route::group(['prefix' => 'frontend'], function () {
	//return view('angular');
	 Route::get('/', 'HomeController@frontend');
	 Route::get('/{a}', 'HomeController@frontend');
	 Route::get('/{a}/{b}', 'HomeController@frontend');
	 Route::get('/{a}/{b}/{c}', 'HomeController@frontend');
	 Route::get('/{a}/{b}/{c}/{d}', 'HomeController@frontend');
	 Route::get('/{a}/{b}/{c}/{d}/{e}', 'HomeController@frontend');
});


Route::get('/', function(){
    return redirect()->route('admin.dashboard');
});


