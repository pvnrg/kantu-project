<?php

Route::get('/login',  'LoginController@index' )->name('admin.login');
Route::post('/login', 'LoginController@login')->name('admin.dologin');

Route::get('/employee/activation/{email}/{token}', 'EmployeeController@activationForm');
Route::post('/employee/activation', 'EmployeeController@activationSubmit');

Route::group(['middleware' => ['isAdmin'] ], function() {

    Route::post('/logout', 'LoginController@logout')->name('admin.logout');

    Route::get('/edit_profile', 'UserController@editProfile')->name('admin.edit.profile');
    Route::put('/edit_profile/{user}/update', 'UserController@updateProfile')->name('admin.update.profile');

    Route::get('/change_password', 'UserController@changePassword')->name('admin.change.password');
    Route::put('/change_password/{user}/update', 'UserController@updatePassword')->name('admin.update.password');

    Route::get('/',  'DashboardController@show' )->name('admin.dashboard');

    Route::get('/dashboard',  'DashboardController@show' )->name('admin.dashboard');

    Route::get('/menus',  'MenuController@index' )->name('admin.menu');

    Route::get('/setlang/{lang?}',  'SettingController@setlang' )->name('admin.setlang');

    Route::post('/ordering',  'Controller@ordering' )->name('admin.ordering');;

    Route::get('/settings/module/{module?}',  'SettingController@index' )->name('admin.settings.module');
    Route::post('/settings/storeAjax',  'SettingController@storeAjax' );
    Route::post('/settings/datatable', 'SettingController@datatable')->name('admin.settings.datatable');
    Route::resource('/settings', 'SettingController', ['names' => [
        'index' => 'admin.settings',
        'create' => 'admin.settings.create',
        'update' => 'admin.settings.update',
    ]]);

    Route::get('/users/search', 'UserController@search');
    Route::get('/users/datatable', 'UserController@datatable')->name('admin.users.datatable');
    Route::post('/users/recover', 'UserController@recover')->name('admin.users.recover');
    Route::resource('/users', 'UserController', ['names' => [
        'index' => 'admin.users',
        'create' => 'admin.users.create',
        'update' => 'admin.users.update',
    ]]);

    Route::get('/rolls/search', 'RollsController@search');
    Route::post('/rolls/datatable', 'RollsController@datatable')->name('admin.rolls.datatable');
    Route::post('/rolls/recover', 'RollsController@recover')->name('admin.rolls.recover');
    Route::resource('/rolls', 'RollsController', ['names' => [
        'index' => 'admin.rolls',
        'create' => 'admin.rolls.create',
        'update' => 'admin.rolls.update',
    ]]);

    Route::get('/permissions/search', 'PermissionsController@search');
    Route::post('/permissions/datatable', 'PermissionsController@datatable')->name('admin.permissions.datatable');
    Route::post('/permissions/recover', 'PermissionsController@recover')->name('admin.permissions.recover');
    Route::resource('/permissions', 'PermissionsController', ['names' => [
        'index' => 'admin.permissions',
        'create' => 'admin.permissions.create',
        'update' => 'admin.permissions.update',
    ]]);

	Route::get('/reference-file/{id}/delete', 'ReferenceController@destroy');

    Route::get('/rollpermissions/{module?}',  'RollpermissionsController@index' )->name('admin.rollpermissions');
    Route::post('/rollpermissions/update',  'RollpermissionsController@updateRollpermissions' )->name('admin.rollpermissions.update');

    Route::get('/generator', 'GeneratorController@index')->name('admin.generator');
    Route::post('/generator/getfields', 'GeneratorController@getfields')->name('admin.generator.getfields');
    Route::post('/generator/build', 'GeneratorController@build')->name('admin.generator.build');
    Route::get('/generator/build', 'GeneratorController@build')->name('admin.generator.build');

    //Blog Routes
    Route::get('/blog/search', 'BlogController@search');
    Route::post('/blog/datatable', 'BlogController@datatable')->name('admin.blog.datatable');
    Route::post('/blog/recover', 'BlogController@recover')->name('admin.blog.recover');
    Route::resource('/blog', 'BlogController', ['names' => [
        'index' => 'admin.blog',
        'create' => 'admin.blog.create',
        'update' => 'admin.blog.update'
    ]]);
    Route::get('blogChangeStatus', 'BlogController@ChangeStatus')->name('admin.blog.changeStatus');

    //Faq Routes
    Route::get('faqChangeStatus', 'FaqsController@ChangeStatus')->name('admin.faq.changeStatus');
    Route::get('/faq/search', 'FaqsController@search');
    Route::post('/faq/datatable', 'FaqsController@datatable')->name('admin.faq.datatable');
    Route::post('/faq/recover', 'FaqsController@recover')->name('admin.faq.recover');
    Route::resource('/faq', 'FaqsController', ['names' => [
        'index' => 'admin.faq',
        'create' => 'admin.faq.create',
        'update' => 'admin.faq.update',
    ]]);

    //Logs Routes
    Route::get('/logs/search', 'LogsController@search');
    Route::post('/logs/datatable', 'LogsController@datatable')->name('admin.logs.datatable');
    Route::post('/logs/recover', 'LogsController@recover')->name('admin.logs.recover');
    Route::resource('/logs', 'LogsController', ['names' => [
        'index' => 'admin.logs',
        'create' => 'admin.logs.create',
        'update' => 'admin.logs.update',
    ]]);

    //ResponseText Routes
    Route::get('/responseText/search', 'ResponseTextController@search');
    Route::post('/responseText/datatable', 'ResponseTextController@datatable')->name('admin.responseText.datatable');
    Route::post('/responseText/recover', 'ResponseTextController@recover')->name('admin.responseText.recover');
    Route::resource('/responseText', 'ResponseTextController', ['names' => [
        'index' => 'admin.responseText',
        'create' => 'admin.responseText.create',
        'update' => 'admin.responseText.update',
    ]]);

    //SeoContent Routes
    Route::get('/seoContent/search', 'SeoContentController@search');
    Route::post('/seoContent/datatable', 'SeoContentController@datatable')->name('admin.seoContent.datatable');
    Route::post('/seoContent/recover', 'SeoContentController@recover')->name('admin.seoContent.recover');
    Route::resource('/seoContent', 'SeoContentController', ['names' => [
        'index' => 'admin.seoContent',
        'create' => 'admin.seoContent.create',
        'update' => 'admin.seoContent.update',
    ]]);

    //Images Routes
    Route::get('/images/search', 'ImagesController@search');
    Route::post('/images/datatable', 'ImagesController@datatable')->name('admin.images.datatable');
    Route::post('/images/recover', 'ImagesController@recover')->name('admin.images.recover');
    Route::resource('/images', 'ImagesController', ['names' => [
        'index' => 'admin.images',
        'create' => 'admin.images.create',
        'update' => 'admin.images.update',
    ]]);

    //Evant Routes
    Route::get('/events/search', 'EventsController@search');
    Route::post('/events/datatable', 'EventsController@datatable')->name('admin.events.datatable');
    Route::post('/events/recover', 'EventsController@recover')->name('admin.events.recover');
    Route::resource('/events', 'EventsController', ['names' => [
        'index' => 'admin.events',
        'create' => 'admin.events.create',
        'update' => 'admin.events.update',
    ]]);

    // Event - Images Routes
    Route::post('/events_images/datatable', 'EventsImagesController@datatable')->name('admin.events_images.datatable');
    Route::post('/events_images/recover', 'EventsImagesController@recover')->name('admin.events_images.recover');
    Route::resource('/emergency-list', 'EventsImagesController', ['names' => [
        'index' => 'admin.events_images',
        'create' => 'admin.events_images.create',
        'update' => 'admin.events_images.update',
    ]]);

    //Contact-Us Routes
    Route::get('/contactUs/search', 'ContactUsController@search');
    Route::post('/contactUs/datatable', 'ContactUsController@datatable')->name('admin.contactUs.datatable');
    Route::post('/contactUs/recover', 'ContactUsController@recover')->name('admin.contactUs.recover');
    Route::resource('/contactUs', 'ContactUsController', ['names' => [
        'index' => 'admin.contactUs',
        'create' => 'admin.contactUs.create',
        'update' => 'admin.contactUs.update',
    ]]);

    //Plan Routes
    Route::get('/plan/search', 'PlanController@search');
    Route::post('/plan/datatable', 'PlanController@datatable')->name('admin.plan.datatable');
    Route::post('/plan/recover', 'PlanController@recover')->name('admin.plan.recover');
    Route::resource('/plan', 'PlanController', ['names' => [
        'index' => 'admin.plan',
        'create' => 'admin.plan.create',
        'update' => 'admin.plan.update',
    ]]);
    Route::get('plan/generate-stripe-plan/{id}', 'PlanController@generateStripePlan');
    Route::get('planChangeStatus', 'PlanController@ChangeStatus')->name('admin.plan.changeStatus');

    //Employee Routes
    Route::get('/employee/search', 'EmployeeController@search');
    Route::post('/employee/datatable', 'EmployeeController@datatable')->name('admin.employee.datatable');
    Route::post('/employee/recover', 'EmployeeController@recover')->name('admin.employee.recover');
    Route::resource('/employee', 'EmployeeController', ['names' => [
        'index' => 'admin.employee',
        'create' => 'admin.employee.create',
        'update' => 'admin.employee.update',
    ]]);
    //Route::get('employee/approvedBy', 'EmployeeController@approvedBy')->name('admin.employee.approvedBy');
    Route::get('employee/approvedBy/{id}', 'EmployeeController@approvedBy');
    Route::get('/employee/activation-resend/{uid}', 'EmployeeController@resendmail');


    Route::get('/employee-payment', 'EmployeeController@showMyPayment');
    Route::get('/employee-payment/datatable/{uid}', 'EmployeeController@paymentdatatable');
    Route::get('/employee/payment/{uid}', 'EmployeeController@paymentForm');
    Route::post('/employee/payment', 'EmployeeController@paymentSubmit');






    //Connection Routes
    Route::get('/connection/search', 'ConnectionController@search');
    Route::post('/connection/datatable', 'ConnectionController@datatable')->name('admin.connection.datatable');
    Route::post('/connection/recover', 'ConnectionController@recover')->name('admin.connection.recover');
    Route::resource('/connection', 'ConnectionController', ['names' => [
        'index' => 'admin.connection',
        'create' => 'admin.connection.create',
        'update' => 'admin.connection.update',
    ]]);

    //Orders Routes
    Route::get('/orders/search', 'OrdersController@search');
    Route::post('/orders/datatable', 'OrdersController@datatable')->name('admin.orders.datatable');
    Route::post('/orders/recover', 'OrdersController@recover')->name('admin.orders.recover');
    Route::resource('/orders', 'OrdersController', ['names' => [
        'index' => 'admin.orders',
        'create' => 'admin.orders.create',
        'update' => 'admin.orders.update',
    ]]);
    Route::get('orderChangeStatus', 'OrdersController@ChangeStatus')->name('admin.orders.changeStatus');


    Route::get('/users/{id}/connections', 'UserController@showConnectedUser')->name('admin.users.connections');
    Route::get('/users/approveBadge/{id}', 'UserController@approveBadge')->name('admin.users.approveBadge');
    Route::get('/users/disapproveBadge/{id}', 'UserController@disapproveBadge')->name('admin.users.disapproveBadge');
    Route::get('/users/file-delete/{id}', 'UserController@deletefile');
    Route::post('/users/unsubscribe/{id}', 'UserController@unsubscribe');

    //do not delete this comments
    //**GENERATOR_ROUTES**//

    // Route::get('/users/search', 'UsersController@search');
    // Route::post('/users/datatable', 'UsersController@datatable')->name('admin.users.datatable');
    // Route::post('/users/recover', 'UsersController@recover')->name('admin.users.recover');
     Route::resource('/users', 'UserController', ['names' => [
         'index' => 'admin.users',
         'create' => 'admin.users.create',
         'update' => 'admin.users.update',
         'destroy' => 'admin.users.destroy',
         'show' => 'admin.users.show'
     ]]);
     Route::get('userChangeStatus', 'UserController@ChangeStatus')->name('admin.users.changeStatus');



    //**GENERATOR_ROUTES**//

});
