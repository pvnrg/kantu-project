<?php
use App\Http\Middleware\Cros;
use Illuminate\Http\Request;



/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });



Route::group(['middleware' => ['set_globle_value'], 'prefix' => 'v1' , 'namespace' => 'Api\v1' ], function () {

    Route::post('login', 'LoginController@login');
    Route::post('forgot-password', 'LoginController@forgotPassword');
    Route::post('confirmOTP', 'LoginController@confirmOTP');
    Route::post('reset-password', 'LoginController@resetPassword');

	Route::post('register', 'RegisterController@register');
	Route::post('unique-field/{field}', 'RegisterController@uniqueField');

    Route::post('testNotification', 'ListController@testNotification');
    Route::get('getImageList', 'ListController@getImageList');
    Route::get('getBlogList', 'ListController@getBlogList');
    Route::get('getBlog/{slug}', 'ListController@getBlog');
    Route::get('getPageList', 'ListController@getPageList');
    Route::get('getPage/{slug}', 'ListController@getPage');
    Route::get('getFaqList', 'ListController@getFaqList');

	Route::post('call-response', 'TwillioController@callresponse')->name('call-response');
	Route::post('call-end', 'TwillioController@callStatus')->name('call-end');


    Route::group(['middleware' => 'jwt.verify'], function () {

        Route::get('getPlanList', 'ListController@getPlanList');
        Route::get('notifications', 'ListController@getNotificationList');
        Route::put('notifications/read', 'ListController@updateNotification');

		Route::post('get-phoneverification-code', 'TwillioController@getPhoneVerificationOtp');
		Route::post('phoneverification-call', 'TwillioController@phoneVerificationCall');
		Route::post('verify-email', 'RegisterController@verifyEmail');
		Route::post('verify-email-resend', 'RegisterController@verifyEmailResend');

		Route::post('send-request', 'ConnectionController@sendRequset')->name('sendRequset');
		Route::get('get-connections', 'ConnectionController@myConnection')->name('myConnection');
		Route::get('get-connection-detail', 'ConnectionController@myConnectionDetail')->name('myConnectionDetail');
        Route::post('action-on-request', 'ConnectionController@actionOnRequest')->name('actionOnRequest');
        Route::get('profile/{id}', 'ConnectionController@getConnectedUserProfile');

        Route::post('logout', 'LoginController@logout');
        Route::post('change-password', 'LoginController@changePassword');

        Route::get('profile', 'RegisterController@profile');
        Route::post('profile/update', 'RegisterController@updateProfile');

        Route::get('cards', 'CardsController@getMyCards');
        Route::post('card/add', 'CardsController@addCard');
        Route::put('card/default', 'CardsController@setDefaultCard');
        Route::delete('card/delete', 'CardsController@removeCard');

        Route::get('events', 'EventsController@all');
        Route::get('events/incoming', 'EventsController@incoming');
        Route::get('events/completed', 'EventsController@completed');
        Route::get('events/invites', 'EventsController@invites');
        Route::get('events/calendar', 'EventsController@calendarEvents');
        Route::get('event/{id}/view', 'EventsController@view');
        Route::post('event/add', 'EventsController@add');
        Route::post('event/{id}/update', 'EventsController@update');
        Route::put('event/{id}/accept-invite', 'EventsController@acceptInvite');
        Route::put('event/{id}/set-image', 'EventsController@setEventImage');
        Route::put('event/{id}/mark-complete', 'EventsController@markComplete');

        Route::post('upgradeSubscription', 'SubscriptionController@upgradeSubscription');


    });

});


// Route::group(['middleware' => 'set_globle_value'], function () {

//     Route::post('call-response', 'Api\TwillioController@callresponse')->name('call-response');
//     Route::post('call-end', 'Api\TwillioController@callStatus')->name('call-end');

//     Route::get('get-faqs', 'Api\FaqsController@allFaqs');

//     Route::get('get-page', 'Api\BlogController@page');
//     Route::get('all-pages', 'Api\BlogController@allPages');

//     Route::get('get-blog', 'Api\BlogController@blog');
//     Route::get('all-blogs', 'Api\BlogController@allBlogs');

//     Route::get('send_sms', 'Api\Child\RegisterController@send_sms');

//     Route::post('get-ebook', 'Api\ContactController@getEbook');
//     Route::post('contact-us', 'Api\ContactController@contact_us');
//     Route::post('complain', 'Api\ContactController@complain');
//     Route::post('referral-program', 'Api\ContactController@referral');

//     Route::get('get-seopage', 'Api\SeoController@getSeopage');

//     Route::post('register', 'Api\RegisterController@register');

//     Route::post('special-register', 'Api\DlinkController@register');
//     Route::post('parent-child-register', 'Api\DlinkController@ParentChildRegister');
//     Route::post('unique-field/{field}', 'Api\DlinkController@uniqueField');

//     Route::post('login', 'Api\LoginController@login');
//     Route::post('forgot-password', 'Api\LoginController@forgotPassword');
//     Route::post('confirmOTP', 'Api\LoginController@confirmOTP');
//     Route::post('reset-password', 'Api\LoginController@resetPassword');

//     //subscription plan list
//     Route::get('subscription-list', 'Api\RegisterController@subscriptionList');

//     Route::group(['middleware' => 'jwt.verify'], function () {

//         Route::post('logout', 'Api\LoginController@logout');
//         Route::post('change-password', 'Api\LoginController@changePassword');

//         Route::get('profile', 'Api\RegisterController@profile');
//         Route::put('profile/update', 'Api\RegisterController@updateProfile');

//         Route::post('updateChild', 'Api\RegisterController@updateChild');
//         Route::get('view_child', 'Api\RegisterController@viewChild');
//         Route::get('order_detail', 'Api\RegisterController@orderDetail');

//         Route::get('childDetail', 'Api\RegisterController@childDetail');
//         Route::post('unique_child_user_name', 'Api\RegisterController@unique_child');
//         Route::post('unique_child_number', 'Api\RegisterController@unique_child_number');

//         Route::post('child-register', 'Api\RegisterController@childRegister');
//         Route::post('unsubscribe', 'Api\RegisterController@unsubscribe');
//         Route::get('get_notification', 'Api\Child\RegisterController@get_notification');
//         Route::post('update_notification', 'Api\Child\RegisterController@update_notification');

//         Route::post('upload-document', 'Api\DocumentController@addDocument');

//         Route::group(['prefix' => 'plan'], function () {
//             Route::get('plan_list', 'Api\PlanController@index');
//         });

//         Route::post('upgrade-subscription', 'Api\SubscriptionController@upgradeSubscription');
//         Route::get('get-plans-for-child', 'Api\SubscriptionController@getPlanlistForUser');

//         Route::get('cards', 'Api\SubscriptionController@getMyCards');
//         Route::post('card/add', 'Api\SubscriptionController@addCard');
//         Route::post('card/default', 'Api\SubscriptionController@setDefaultCard');
//         Route::post('card/delete', 'Api\SubscriptionController@removeCard');

//         Route::get('get-phoneverification-code', 'Api\TwillioController@getPhoneVerificationOtp');


//     });

// });


