<?php
return [
    'product_sales' => 'VENTAS DE PRODUCTOS'
];

?>