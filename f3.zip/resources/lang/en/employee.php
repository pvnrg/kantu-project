<?php
return [
    'title' => 'Employee',
    
    'create' => [
        'title' => "Create New Employee",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'edit' => [
        'title' => "Edit Employee",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'label' => [
        'first_name' => 'First Name',
        'last_name' => 'Last Name',
        'email' => 'Email',
        'password' => 'Password',
        'phone' => 'Phone',
        'type' => 'Type',
        'status' => 'Status'
    ],
    'form' => [
        'create' => 'Create and Edit'
    ],
    'validation' => [
        'title_required' => 'The Title field is required.',
        'detail_required' => 'The Detail field is required.',
        'short_desc_required' => 'The Short Description field is required.',
        'post_date_required' => 'The Post Date field is required.',
        'type_required' => 'The Type field is required.',
    ]

];

?>