<?php
return [
    'title' => 'Image',

    'create' => [
        'title' => "Create New Image",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'edit' => [
        'title' => "Edit Image",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'label' => [
        'image' => 'Image',
    ],
    'form' => [
        'create' => 'Create and Edit'
    ],
    'validation' => [
        'image_required' => 'The Image field is required.'
    ]

];

?>
