<?php
return [
    'title' => 'Plan',
    
    'create' => [
        'title' => "Create New Plan",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'edit' => [
        'title' => "Edit Plan",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'label' => [
        'title' => 'Title',
        'actual_amount' => 'Actual Amount',
        'show_amount' => 'Show Amount',
        'description' => 'Description',
        'type' => 'Type',
        'status' => 'Status',
    ],
    'form' => [
        'create' => 'Create and Edit',
        'status' => 'Active Status'
    ],
    'validation' => [
        'title_required' => 'The Title field is required.',
        'actual_amount_required' => 'The Actual Amount field is required.',
        'show_amount_required' => 'The Show Amount field is required.',
        'description_required' => 'The Description field is required.',
        'type_required' => 'The Type field is required.',
    ]

];

?>