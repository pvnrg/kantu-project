<?php
return [
    'title' => 'Seo Content',

    'edit' => [
        'title' => "Edit Seo Content",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'label' => [
        'page_name' => 'Page Name',
        'title' => 'Title',
        'keywords' => 'Keywords (comma separated)',
        'description' => 'Description'
    ],
    'form' => [
        'create' => 'Create and Edit'
    ]

];

?>