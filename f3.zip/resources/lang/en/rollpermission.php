<?php
return [
    'title' => 'Permissions',
];

?>