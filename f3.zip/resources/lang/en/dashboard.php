<?php
return [
    'product_sales' => 'PRODUCTS SALES'
];

?>