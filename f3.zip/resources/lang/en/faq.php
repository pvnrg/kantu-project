<?php
return [
    'title' => 'Faq',
    
    'create' => [
        'title' => "Create New Faq",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'edit' => [
        'title' => "Edit Faq",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'label' => [
        'question' => 'Question',
        'answer' => 'Answer',
        'status' => 'Status'
    ],
    'form' => [
        'create' => 'Create and Edit',
        'status' => 'Active Status'
    ],
    'validation' => [
        'question_required' => 'The Question field is required.',
        'answer_required' => 'The Answer field is required.'
    ]

];

?>