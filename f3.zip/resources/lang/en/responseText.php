<?php
return [
    'title' => 'Response Text',
    
    'create' => [
        'title' => "Create New Response Text",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'edit' => [
        'title' => "Edit Response Text",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'label' => [
        'response_type' => 'Response Type',
        'slug' => 'Slug',
        'desc' => 'Description'
    ],
    'form' => [
        'create' => 'Create and Edit'
    ],
    'validation' => [
        'desc_required' => 'The Description field is required.',
    ]

];

?>