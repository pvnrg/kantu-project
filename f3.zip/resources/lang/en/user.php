<?php
return [
    'title' => 'User',

    'create' => [
        'title' => "Create New User",
        'field' =>[
            'title' => 'Title',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'email'=> 'Email',
            'password' => 'Password',
            'rolls' => 'Rolls',
            'phone' => 'Phone',
            'gender' => 'Gender',
            'dob' => 'Date of Birth',
            'username' => 'Username',
            'documents' => 'Documents',
            'pan_number' => 'Pan Card Number'
        ]
    ],
    'edit' => [
        'title' => "Edit User",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'label' => [
        'image' => 'Image',
        'title' => 'Title',
        'detail' => 'Detail',
        'short_desc' => 'Short Description',
        'post_date' => 'Post Date',
        'type' => 'Type',
        'status' => 'Status'
    ],
    'form' => [
        'create' => 'Create and Edit'
    ],
    'validation' => [
        'title_required' => 'The Title field is required.',
        'detail_required' => 'The Detail field is required.',
        'short_desc_required' => 'The Short Description field is required.',
        'post_date_required' => 'The Post Date field is required.',
        'type_required' => 'The Type field is required.',
    ],
    'tooltip'=>[
        'icon'=>[
            'event' => 'View Events',
            'connection' => 'View Connections',
            'order' => 'View Orders'
        ]
    ],

];

?>
