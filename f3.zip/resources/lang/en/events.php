<?php
return [
    'title' => 'Events',
    'form' => [
        'create' => 'Create and Edit'
    ],

];

?>