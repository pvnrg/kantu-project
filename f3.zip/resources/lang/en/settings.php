<?php
return [
    'label' => [
        'fkey' => "Foreign Key",
        'fvalue' => "Foreign Value",
        'finformation' => "Information For Value",
    ],
    'title' => "Settings",
    "edit" => [
        "title"=> "Edit Setting"
    ]
];