<?php
return [
    'title' => 'Blog',

    'create' => [
        'title' => "Create New Blog",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'edit' => [
        'title' => "Edit Blog",
        'field' =>[
            'title' => 'Title',
            'backendAccess'=> 'Can Access Backend'
        ]
    ],
    'label' => [
        'image' => 'Image',
        'title' => 'Title',
        'detail' => 'Detail',
        'short_desc' => 'Short Description',
        'post_date' => 'Post Date',
        'type' => 'Type',
        'status' => 'Status',
        'Page' => 'Page',
        'Blog' => 'Blog'
    ],
    'form' => [
        'create' => 'Create',
        'clear' => 'Clear',
        'update' => 'Update',
        'status' => 'Active Status'
    ],
    'validation' => [
        'title_required' => 'The Title field is required.',
        'detail_required' => 'The Detail field is required.',
        'short_desc_required' => 'The Short Description field is required.',
        'post_date_required' => 'The Post Date field is required.',
        'type_required' => 'The Type field is required.',
    ]

];

?>
