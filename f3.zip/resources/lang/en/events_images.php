<?php
return [
    'title' => 'Emergency List ',
];

?>
