@extends('layouts.admin.index')

@section('title',trans('View User'))

@push('css')
<style>
    .user-img{
        width: 100px;
        height: 100px;
        border-radius: 50%;
    }
</style>
@endpush

@section('content')

<div class="main-content">
    <div class="content-wrapper">
        @include('inc.messages')
        <section id="basic-form-layouts">
            <div class="row">
                <div class="col-sm-12">
                    <div class="content-header">  @if($item->name) {{$item->name}} @endif</div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <a href="{{ route('admin.'.$context.'s') }}">
                                <button type="button" class="btn btn-raised btn-success btn-min-width mr-1 mb-1">
                                    <i class="fa fa-angle-left"></i> @lang($context.'.title')
                                </button>
                            </a>
                            {!! Form::open([
                            'method'=>'DELETE',
                            'url' => ['admin/'.$context.'s', $item->id],
                            'style' => 'display:inline'
                            ]) !!}

                            {!! Form::button('<i class="fa fa-trash" aria-hidden="true"></i> '.trans('common.delete'), array(
                            'type' => 'submit',
                            'class' => 'btn btn-raised btn-danger btn-min-width mr-1 mb-1',
                            'title' => trans('common.delete'),
                            'onclick'=>"return confirm('".trans('common.js_msg.confirm_for_delete_data')."')"
                            ))!!}
                            {!! Form::close() !!}
                        </div>
                        <div class="card-body">
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <tbody>
                                                    <tr>
                                                        <th>@lang('common.name')</th>
                                                        <td>{{ $item->name }}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>@lang('common.email')</th>
                                                        <td>{{ $item->email }}  @if($item->email_verified_at != "")<span class="btn-sm btn-success"><i class="fa fa-check"></i></span> @endif</td>
                                                    </tr>
                                                    <tr>
                                                        <th>@lang('common.phone')</th>
                                                        <td>{{ $item->phone }} @if($item->phone_verified != "") <span class="btn-sm btn-success"><i class="fa fa-check"></i></span> @endif</td>
                                                    </tr>
                                                    <tr>
                                                        <th>@lang('common.age')</th>
                                                        <td>{{ $item->age }} Yrs</td>
                                                    </tr>
                                                    <tr>
                                                        <th>@lang('common.dob')</th>
                                                        <td>{{ $item->dob }}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>@lang('common.badge_id')</th>
                                                        <td>{{ $item->batch_id }}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>@lang('common.badge_status')</th>
                                                        <td>{{ $item->badge_status }}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>@lang('common.regi_reference')</th>
                                                        <td>{{ $item->regi_reference == 'site' ? 'Website' : $item->regi_reference }}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Profile Image </th>
                                                        <td>@if($item->profileimg)<a href="{{$item->profile_pic}}" target="_blank"><img src="{{$item->profile_pic_thumb}}" title="{{$item->name}}" width='100px' class="user-img"/></a>@endif</td>

                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <strong>Documents</strong>
                            @if($item->badge_status != App\User::BADGE_APPROVE)
                            <a href="{{ url('admin/users/approveBadge/') }}/{{$item->id}}" title="Approve child Badge">
                                <button class="btn btn-sm btn-space btn-success pull-right">Approve User Badge</button>
                            </a>
                            @endif
                            @if($item->badge_status != App\User::BADGE_DISAPPROVE )
                            <a href="{{ url('admin/users/disapproveBadge/') }}/{{$item->id}}" title="Disapproved">
                                <button class="btn btn-sm btn-space btn-danger pull-right">Disapprove</button>
                            </a>
                            @endif
                        </div>
                        <div class="card-body">
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table class="table table-striped dataTable">
                                                <thead>
                                                    <tr>
                                                        <th>File name</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($item->documents as $refefile)
                                                    @if($refefile->file_url)
                                                        <tr>
                                                            <th> <a href="{{ url(''.$refefile->file_url) }}" title="View Document" target="_blank" > {{$refefile->refe_file_name}} </a> </th>
                                                            <th>
                                                                <a href="{{ url('/admin/users/file-delete/'.$refefile->id) }}" onclick="return confirm('Are you sure to delete this document ?')">
                                                                    <button class="btn btn-warning btn-sm" title="Delete"><i class="fa fa-trash"></i></button>
                                                                </a>
                                                                <a href="{{ url(''.$refefile->file_url) }}" target="_blank" download>
                                                                    <button class="btn btn-warning btn-sm" title="Download"  ><i class="fa fa-download"></i></button>
                                                                </a>
                                                            </th>
                                                        </tr>
                                                    @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="card">
                            <div class="card-header">
                                <strong>Subscriptions / Orders</strong>
                            </div>
                            <div class="card-body">
                                <div class="px-3">
                                    <div class="box-content ">
                                        <div class="row">
                                            <div class="table-responsive">
                                                <table class="table table-striped dataTable">
                                                    <thead>
                                                        <tr>
                                                            <th>Plan Name</th>
                                                                <th>Status</th>
                                                                 <th>   Type </th>
                                                                <th>Duration</th>
                                                                <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach($item->orders as $order)

                                                        <tr>
                                                            <td>
                                                                @if($order->plan) <b> {{ $order->plan->title }} </b> | @if($order->plan->type != "free") $ {{ strtoupper($order->plan->actual_amount) }}-@endif {{ strtoupper($order->plan->type) }} @endif
                                                            </td>
                                                            <td>{{ strtoupper($order->trans_status) }} </td>
                                                            <td>
                                                                @if($order->one_time_charge_id != '' && $order->one_time_charge_id != null  && $order->one_time_charge_id != '0' ) One time Fee
                                                                @elseif($order->subscription_id != '' && $order->subscription_id != null && $order->subscription_id != '0') Subscription
                                                                @else
                                                                 @endif
                                                            </td>
                                                            <td>{{ $order->start_date_formated }} -  {{ $order->expiry_date_formated }} </td>
                                                            <td>
                                                                <a href="{{ url('/admin/orders/'.$order->id) }}" >
                                                                    <button class="btn btn-warning btn-sm" title="View"><i class="fa fa-eye"></i></button>
                                                                </a>
                                                                @if($order->subscription_id != '' && $order->subscription_id != null && $order->subscription_id != '0' && $order->trans_status == 'active' )
                                                                {!! Form::open([
                                                                    'method'=>'POST',
                                                                    'url' => ['/admin/users/unsubscribe', $order->id],
                                                                    'style' => 'display:inline'
                                                                ]) !!}
                                                                {!! Form::button('<i class="fa fa-undo"></i>', array(
                                                                        'type' => 'submit',
                                                                        'class' => 'btn btn-warning btn-sm',
                                                                        'title' => 'Unsubscribe',
                                                                        'onclick'=>'return confirm("Are you sure to unsubscribe User ? User will be Inactived on Unsubscribe.")'
                                                                )) !!}
                                                                {!! Form::close() !!}
                                                                @endif

                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </div>
</div>


@endsection
