@extends('layouts.admin.index')

@section('title',trans('Connections'))

@section('content')
@push('css')
<style>
    .user-img{
        width: 100px;
        height: 100px;
        border-radius: 50%;
    }
</style>
@endpush

<div class="main-content">
    <div class="content-wrapper">
        @include('inc.messages')
        <section id="basic-form-layouts">
            <div class="row">
                <div class="col-sm-12">
                     <div class="content-header"> Connections of {{ $user->name }} </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="{{ route('admin.'.$context.'s') }}">
                                <button type="button" class="btn btn-raised btn-success btn-min-width mr-1 mb-1">
                                    <i class="fa fa-angle-left"></i> @lang($context.'.title')
                                </button>
                            </a>
                        </div>
                        <div class="card-body">
                            @if($connections->count() == 0 ) No Connections Found @endif
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        @foreach($connections as $connect )
                                            @php($user = $connect->connected_user($id))
                                            @if($user)
                                            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
                                                <div class="card gradient-pomegranate">
                                                    <div class="card-content">
                                                        <div class="card-body pt-2 pb-0">
                                                                <button data-id="{{ $connect->id }}" class="btn btn-sm btn-default pull-right del-log"><i class="fa fa-close"></i>
                                                                </button>
                                                            <div class="media">
                                                                <div class="media-body white text-center">
                                                                    <img src="{{$user->profile_pic}}" title="{{$user->name}}" width='100px' class="user-img" />
                                                                    <h5 class="mb-0">{{$user->name}}</h3><br>
                                                                    <p><span>{{$user->email}}</span></p>
                                                                    <p><span>{{$user->phone}}</span></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            @endif
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>


@endsection

@push('scripts')
<script src="{{ asset('app-assets/vendors/js/sweetalert2.min.js') }}" type="text/javascript"></script>
<script>
     $(document).on('click', '.del-log', function (e) {
        var id = $(this).attr('data-id');
        swal({
            title: 'Are you sure?',
            text: "You want to delete this connection ?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#0CC27E',
            cancelButtonColor: '#FF586B',
            confirmButtonText: 'Yes',
            cancelButtonText: "No, cancel"
        }).then(function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    type: "DELETE",
                    url: "{{ route('admin.connection') }}" + "/" + id,
                    headers: {
                        "X-CSRF-TOKEN": "{{ csrf_token() }}"
                    },
                    success: function (data) {

                        swal({
                            type: 'success',
                            title: "Success",
                            text: "@lang('common.js_msg.action_success')",
                            timer: 2000,
                            showConfirmButton: false
                        });
                        location.reload();
                    },
                    error: function (xhr, status, error) {
                        swal({
                            type: 'error',
                            title: "Error",
                            text: "@lang('common.js_msg.action_not_procede')",
                            timer: 2000,
                            showConfirmButton: false
                        });
                    }
                });
            }
        }).catch(swal.noop);
    });

</script>
@endpush
