<div class="row ">

    <div class="col-md-6">
		<div class="form-group {{ $errors->has('first_name') ? ' has-error' : ''}}">
            <label for="first_name" >
                <span class="field_compulsory">*</span>@lang($context.'.create.field.first_name')
            </label>
            <div >
			{!! Form::text('first_name', @$item->first_name , ['class' => 'first_name form-control','id'=>'first_name','style'=>'width:100%']) !!}

				{!! $errors->first('first_name', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group {{ $errors->has('last_name') ? ' has-error' : ''}}">
            <label for="last_name" >
                <span class="field_compulsory">*</span>@lang($context.'.create.field.last_name')
            </label>
            <div >
			{!! Form::text('last_name', @$item->last_name, ['class' => 'last_name form-control','id'=>'last_name','style'=>'width:100%']) !!}

				{!! $errors->first('last_name', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group {{ $errors->has('email') ? ' has-error' : ''}}">
            <label for="email" >
                <span class="field_compulsory">*</span>@lang($context.'.create.field.email')
            </label>
            <div >
			{!! Form::text('email', @$item->email , ['class' => 'email form-control','id'=>'email','style'=>'width:100%', 'disabled' => isset($item->email) ? true : false ]) !!}

				{!! $errors->first('email', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
    </div>

    @if( !isset($item) )
    <div class="col-md-6">
        <div class="form-group {{ $errors->has('password') ? ' has-error' : ''}}">
            <label for="password" >
                <span class="field_compulsory">*</span>@lang($context.'.create.field.password')
            </label>
            <div >
            {!! Form::password('password', ['class' => 'password form-control','id'=>'password','style'=>'width:100%']) !!}

                {!! $errors->first('password', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
    </div>
    @endif

    <div class="col-md-6">
        <div class="form-group {{ $errors->has('username') ? ' has-error' : ''}}">
            <label for="username" >
                <span class="field_compulsory">*</span>@lang($context.'.create.field.username')
            </label>
            <div >
			{!! Form::text('username', @$item->username, ['class' => 'form-control','style'=>'width:100%']) !!}

			{!! $errors->first('username', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group {{ $errors->has('phone') ? ' has-error' : ''}}">
            <label for="phone" >
                <span class="field_compulsory">*</span>@lang($context.'.create.field.phone')
            </label>
            <div >
			{!! Form::text('phone', @$item->phone, ['class' => 'form-control','style'=>'width:100%']) !!}

			{!! $errors->first('phone', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group {{ $errors->has('gender') ? ' has-error' : ''}}">
            <label for="gender" >
                <span class="field_compulsory">*</span>@lang($context.'.create.field.gender')
            </label>
            <div >
            Male {!! Form::radio('gender','male', isset($item->gender) && $item->gender == "male" ? true : false ) !!}
            Female {!! Form::radio('gender','female', isset($item->gender) && $item->gender == "female" ? true : false) !!}

			{!! $errors->first('gender', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group {{ $errors->has('pan_number') ? ' has-error' : ''}}">
            <label for="pan_number" >
                <span class="field_compulsory">*</span>@lang($context.'.create.field.pan_number')
            </label>
            <div >
            {!! Form::text('pan_number', @$item->pan_number, ['class' => 'form-control','style'=>'width:100%']) !!}

			{!! $errors->first('pan_number', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group {{ $errors->has('dob') ? ' has-error' : ''}}">
            <label for="dob" >
                <span class="field_compulsory">*</span>@lang($context.'.create.field.dob')
            </label>
            <div >
			{!! Form::text('dob', @$item->dob, ['class' => 'datepicker form-control','readonly'=>true,'style'=>'width:100%']) !!}

				{!! $errors->first('dob', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
    </div>

    <div class="col-md-6" style="display:none;">
        <div class="form-group {{ $errors->has('documents') ? ' has-error' : ''}}">
            <label for="documents" >
                <span class="field_compulsory">*</span>@lang($context.'.create.field.documents')
            </label>
            <div >
			{!! Form::file('documents[]', ['class' => 'form-control', 'multiple'=>true ]) !!}
			{!! $errors->first('documents', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        @if(isset($item))
        @foreach($item->documents as $refefile)
            @if($refefile->file_url)
            <table>
                <tr>
                    <th> <a href="{{ url(''.$refefile->file_url) }}" title="View Document" target="_blank" > {{$refefile->refe_file_name}} </a> </th>
                    {{-- <th>
                        <a href="{{ url('/admin/users/file-delete/'.$refefile->id) }}" onclick="return confirm('Are you sure to delete this document ?')">
                            <button class="btn btn-warning btn-sm" title="Delete"><i class="fa fa-trash"></i></button>
                        </a>
                    </th> --}}
                </tr>
            </table>
            @endif
        @endforeach
        @endif
    </div>

    <div class="col-md-6">
        <div class="form-group {{ $errors->has('image') ? ' has-error' : ''}}">
            <label for="image" >
                @lang('Profile image')
            </label>
            <div >
			{!! Form::file('image', null, ['class' => 'image form-control' ,'id'=>'image','style'=>'width:100%']) !!}
				{!! $errors->first('image', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        @if(isset($item) && $item->profileimg)<a href="{{ $item->profile_pic_thumb }}" target="_blank"><img src="{{ $item->profile_pic_thumb }}" class="user-img" /></a> @endif
    </div>

    <div class="col-md-6">
        <div class="form-group">
            {!! Form::submit(isset($submitButtonText) ? $submitButtonText : trans('common.create'), ['class' => 'btn btn-primary form_submit image_submit_btn']) !!}
            @if(!isset($submitButtonText))
            {{ Form::reset(trans('common.clear_form'), ['class' => 'btn btn-light']) }}
            @endif
        </div>
    </div>

      {{-- <div class="form-group {{ $errors->has('rolls') ? ' has-error' : ''}}">
            <label for="rolls" >
                <span class="field_compulsory">*</span>@lang($context.'.create.field.rolls')
            </label>
        <div >
        <select name="rolls[]" multiple id="rolls" class="form-control item-menu">
            @foreach($rolls as $roll)
                <option value="{{ $roll->id}}" {{ (isset($item) && $item->rolls()->where('roll_id',$roll->id)->first()) ? 'selected="selected"' : ''  }}  >{{ $roll->title}}</option>
            @endforeach
        </select>

				{!! $errors->first('rolls', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div> --}}




</div>






