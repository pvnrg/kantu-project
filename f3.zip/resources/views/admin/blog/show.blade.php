
@extends('admin.system.show')
@section('table')


<table class="table table-striped">
    <tbody>

        <tr>
            <th>@lang('common.title')</th>
            <td>{{ $item->title }}</td>
        </tr>

        <tr>
            <th>@lang('common.detail')</th>
            <td>{!! $item->detail !!}</td>
        </tr>

        <tr>
            <th>@lang('common.short_desc')</th>
            <td>{{ $item->short_desc }}</td>
        </tr>

        <tr>
            <th>@lang('common.post_date')</th>
            <td>{{ $item->post_date }}</td>
        </tr>

        <tr>
            <th>@lang('common.type')</th>
            <td>{{ $item->type }}</td>
        </tr>

        <tr>
            <th>@lang('common.status')</th>
            <td>{{ Config::get('admin.status.'.$item->status) }}</td>
        </tr>

        <tr>
            <th>@lang('common.image')</th>
            <td>@if($item->image)<a href="{{ $item->thumb_image_url}}"><img src="{{ $item->thumb_image_url }}" width="150px" height="150px" /></a>@endif</td>
        </tr>


    </tbody>
</table>
@endsection
