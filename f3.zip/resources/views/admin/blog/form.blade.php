<div class="row ">
    <div class="col-md-6">
            {{ Form::cbImage("image", false , @$item, $context ) }}

            {{ Form::cbText('title') }}

            {{ Form::cbEditor('detail') }}

            {{ Form::cbText('short_desc') }}

            {{ Form::cbText('post_date', isset($item) ? \Carbon\Carbon::parse($item->post_date)->format('m/d/Y') :'' ,['class' => 'datepicker form-control', 'readonly' => true] ) }}

            {{ Form::cbRadioList('type', ['page' => 'Page', 'blog' => 'Blog']) }}

            {{ Form::cbSelect('status', Config::get('admin.status')) }}

            {{ isset($submitButtonText) ?  Form::cbButtons($submitButtonText) :  Form::cbButtons()    }}

    </div>
</div>

