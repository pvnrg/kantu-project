<div class="row ">
    <div class="col-md-6">

            {{ Form::cbText('title') }}

            {{ Form::cbNumber('actual_amount') }}

            {{ Form::cbNumber('show_amount') }}

            {{ Form::cbTextarea('description') }}

            {{ Form::cbSelect('type', ['' => 'Select Type','free' => 'Free', 'yearly' => 'Yearly', 'daily' => 'Daily', 'weekly' => 'Weekly', 'special_yearly' =>'Special Yearly', 'special_lifetime' => 'Special Lifetime']) }}

            {{ Form::cbSelect('status', Config::get('admin.status')) }}

            {{ isset($submitButtonText) ?  Form::cbButtons($submitButtonText) :  Form::cbButtons()    }}
    </div>
</div>
