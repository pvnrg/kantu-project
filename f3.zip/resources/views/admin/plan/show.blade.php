
@extends('admin.system.show')
@section('table')


<table class="table table-striped">
    <tbody>


        <tr>
            <th>@lang('common.stripe_product_id')</th>
            <td>{{ $item->stripe_product_id }}</td>
        </tr>

        <tr>
            <th>@lang('common.title')</th>
            <td>{{ $item->title }}</td>
        </tr>

        <tr>
            <th>@lang('common.description')</th>
            <td>{{ $item->description }}</td>
        </tr>

        <tr>
            <th>@lang('common.type')</th>
            <td>{{ $item->type }}</td>
        </tr>

        <tr>
            <th>@lang('common.actual_amount')</th>
            <td>{{ '$'.$item->actual_amount }}</td>
        </tr>

        <tr>
            <th>@lang('common.show_amount')</th>
            <td>{{ $item->show_amount }}</td>
        </tr>

        <tr>
            <th>@lang('common.status')</th>
            <td>{{ Config::get('admin.status.'.$item->status) }}</td>
        </tr>


    </tbody>
</table>
@endsection
