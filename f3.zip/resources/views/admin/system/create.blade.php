@extends('layouts.admin.index')
@section('title',trans('common.page.title.create.'.$context))
@section('content')
 <div class="main-content">
    <div class="content-wrapper">
    <section id="basic-form-layouts">
	<div class="row">
		<div class="col-sm-12">
			<div class="content-header"> @lang(trans('common.page.title.create.'.$context)) </div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<div class="actions pull-right">
                    </div>
                    <a href="{{ route('admin.'.$context) }}">
                        <button type="button" class="btn btn-raised btn-success btn-min-width mr-1 mb-1">
                            <i class="fa fa-angle-left"></i> @lang($context.'.title')
                        </button>
                    </a>
				</div>
				<div class="card-body">
					<div class="px-3">
						{!! Form::open(['url' => route('admin.'.$context), 'class' => 'form-horizontal group-border-dashed','id' => 'module_form','autocomplete'=>'off','files'=>true]) !!}
							{!! Form::hidden('action',null,['id'=>'form_action','class'=>'form_action']) !!}
							@include ('admin.'.$context.'.form')
						{!! Form::close() !!}
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
	</div>
</div>
@endsection




@section('js')
@parent

@endsection


@push('scripts')
<script>

    $(document).ready(function () {
        $(".create").on('click',function(){
            $('.form_action').val('create');
        });
        $(".createandclose").on('click',function(){
            $('.form_action').val('createandclose');
        });
        $(".createandnew").on('click',function(){
            $('.form_action').val('createandnew');
        });
        $("#clear").on('click',function(){
            var textarea = $('textarea').attr('id') ;
            CKEDITOR.instances.textarea.setData('', function() { this.updateElement(); } )
        });
        $(".datepicker").datepicker();
    });
</script>


@endpush
