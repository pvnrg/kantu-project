<div class="row ">
    <div class="col-md-6">            
            {{ Form::cbText('page_name') }}

            {{ Form::cbText('title') }}

            {{ Form::cbText('keywords') }}

            {{ Form::cbTextarea('description') }}

            {{ Form::cbButtons(trans($context.'.form.create'), trans($context.'.form.clear') ) }}    
    </div>
</div>
