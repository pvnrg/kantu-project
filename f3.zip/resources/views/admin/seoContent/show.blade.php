
@extends('admin.system.show')
@section('table')
    

<table class="table table-striped">
    <tbody>
      
               
        <tr>
            <th>@lang('common.page_name')</th>
            <td>{{ $item->page_name }}</td>
        </tr>
   
        <tr>
            <th>@lang('common.title')</th>
            <td>{{ $item->title }}</td>
        </tr>

        <tr>
            <th>@lang('common.keywords')</th>
            <td>{{ $item->keywords }}</td>
        </tr>

        <tr>
            <th>@lang('common.description')</th>
            <td>{{ $item->description }}</td>
        </tr>
       
    </tbody>
</table>
@endsection
