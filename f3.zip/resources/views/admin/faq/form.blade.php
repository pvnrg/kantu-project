<div class="row ">
    <div class="col-md-6">

            {{ Form::cbText('question') }}

            {{ Form::cbText('answer') }}

            {{ Form::cbSelect('status', Config::get('admin.status')) }}

            {{ isset($submitButtonText) ?  Form::cbButtons($submitButtonText) :  Form::cbButtons()    }}
    </div>
</div>
