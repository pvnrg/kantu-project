
@extends('admin.system.show')
@section('table')


<table class="table table-striped">
    <tbody>


        <tr>
            <th>@lang('common.question')</th>
            <td>{{ $item->question }}</td>
        </tr>

        <tr>
            <th>@lang('common.answer')</th>
            <td>{{ $item->answer }}</td>
        </tr>

        <tr>
            <th>@lang('common.status')</th>
            <td>{{ Config::get('admin.status.'.$item->status) }}</td>
        </tr>

    </tbody>
</table>
@endsection
