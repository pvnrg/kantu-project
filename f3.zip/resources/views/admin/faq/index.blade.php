@extends('layouts.admin.index')

@section('body_class',' pace-done')

@section('title',trans($context.'.title'))

@section('content')

<!-- <div class="row">
    <div class="col-sm-12">
        <div class="content-header"> @lang($context.'.title') </div>

    </div>
</div> -->
<div class="main-content">

    <div class="content-wrapper">

        <div class="row">
            <div class="col-sm-12">
                <div class="content-header"> @lang($context.'.title') @csrf </div>

            </div>
        </div>

        <section id="configuration">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">

                            <div class="row">

                                <div class="col-6">
                                    <div class="actions pull-left">
                                        <a href="{{ route('admin.'.$context.'.create') }}" class="btn btn-success btn-sm" title="@lang('common.add_new')">
                                            <i class="fa fa-plus" aria-hidden="true"></i> @lang('common.add_new')
                                        </a>

                                    </div>
                                </div>
                                <div class="col-6">
                                    @include("layouts.admin.shared.filter_deleted")
                                </div>
                            </div>
                        </div>
                        <div class="card-body collapse show">

                            <div class="card-block card-dashboard">


                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped datatable responsive">
                                        <thead>
                                            <tr>
                                                <th># @lang('common.id')</th>
                                                <th>@lang('common.question')</th>
                                                <th>@lang('common.answer')</th>
                                                <th>@lang('common.status')</th>
                                                <th>@lang('common.action')</th>

                                            </tr>
                                        </thead>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

@endsection



@section('js')
@parent
<script src="{{ asset('app-assets/vendors/js/datatable/datatables.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('app-assets/vendors/js/sweetalert2.min.js') }}" type="text/javascript"></script>
@endsection


@section('css')
@parent
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/tables/datatable/datatables.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/sweetalert2.min.css')}}">
@endsection


@push('scripts')
<script src="{{ asset('app-assets/js/moment.js')}}" type="text/javascript"></script>
<script>
    $(document).on('change', '.status-faq', function (e) {
        var status = $(this).prop('checked') == true ? 1 : 0;
        var faq_id = $(this).attr('data-id');

      $.ajax({
          type: "GET",
          dataType: "json",
          url: '{{ route('admin.faq.changeStatus') }}',
          data: {'status': status, 'faq_id': faq_id},
          beforeSend: function(){
            $("#loader").show();
          },
          success: function(data){
            //console.log(data.success);
            swal({
                type: 'success',
                title: "Success",
                text: "Faq status change successfully.",
                timer: 2000,
                showConfirmButton: false
            });
          },
          complete:function(data){
            // Hide image container
            $("#loader").hide();
          }
      });
    });

	var statues = <?php echo json_encode(trans('survey.status')); ?>;
	var currency = <?php echo json_encode(trans('seos.currency')); ?>;


	var url ="{{ route('admin.'.$context) }}";
    var edit_url = "{{ route('admin.'.$context) }}";
    var auth_check = "{{ \Auth::check() }}";

	var auth_uid = {{\Auth::user()->id}};

    datatable = $('.datatable').dataTable({
        pagingType: "full_numbers",
        "language": {
            "emptyTable":"@lang('common.datatable.emptyTable')",
            "infoEmpty":"@lang('common.datatable.infoEmpty')",
            "search": "@lang('common.datatable.search')",
            "sLengthMenu": "@lang('common.datatable.show') _MENU_ @lang('common.datatable.entries')",
            "sInfo": "@lang('common.datatable.showing') _START_ @lang('common.datatable.to') _END_ @lang('common.datatable.of') _TOTAL_ @lang('common.datatable.small_entries')",
            paginate: {
                next: '@lang('common.datatable.paginate.next')',
                previous: '@lang('common.datatable.paginate.previous')',
                first:'@lang('common.datatable.paginate.first')',
                last:'@lang('common.datatable.paginate.last')',
            }
        },
        processing: true,
        serverSide: true,
        autoWidth: false,
        stateSave: true,
        order: [0, "desc"],
        columns: [
                { data: 'id',name : 'id',"searchable": true, "orderable": true},
                { data: 'question',name : 'question',"searchable": true, "orderable": true},
                { data: 'answer',name : 'answer',"searchable": true, "orderable": true},
                {
                        "data": null,
                        "searchable": false,
                        "orderable": false,

                        "render": function (o) {
                            var status = '';
                            if(o.status == 1){
                                status = '<label class=\'switch\'><input type=\'checkbox\' data-id=\''+o.id+'\' class=\'status status-faq toggle-class\' value=\''+o.id+'\'  data-table=\'faq\' data-status=\''+o.slug+'\' checked   /> <span class=\'slider round\'></span> </label>';
                            } else {
                                status = '<label class=\'switch\'><input type=\'checkbox\' data-id=\''+o.id+'\' class=\'status status-faq toggle-class\' value=\''+o.id+'\'  data-table=\'faq\' data-status=\''+o.slug+'\' /> <span class=\'slider round\'></span></label>';
                            }
                            return status;
                        }
                    },
                {
                    "data": null,
                    "searchable": false,
                    "orderable": false,
                    "width":150,
                    "render": function (o) {
                        var e=""; var v=""; var d= "";
                        v = "<a href='"+edit_url+"/"+o.id+"/' value="+o.id+" data-id="+o.id+" ><button class='btn btn-info btn-sm' title='@lang('common.tooltip.icon.eye')' ><i class='fa fa-eye' ></i></button></a>&nbsp;";


                        e = "<a href='"+edit_url+"/"+o.id+"/edit/' value="+o.id+" data-id="+o.id+" title='@lang('common.tooltip.icon.edit')' class='btn btn-warning btn-sm'><i class='fa fa-pencil'></i></a>&nbsp;";


                        d = "<a href='javascript:void(0);' class='btn btn-danger btn-sm del-log' title='@lang('common.tooltip.icon.delete')'  data-id="+o.id+" ><i class='fa fa-trash' aria-hidden='true'></i></a>&nbsp;";
                        return v+e+d;
                    }

                }
         ],
        fnRowCallback: function (nRow, aData, iDisplayIndex) {
            $('td', nRow).attr('nowrap', 'nowrap');
            return nRow;
        },
        ajax: {
            url: "{{ route('admin.'.$context.'.datatable') }}", // json datasource
            type: "post", // method , by default get
            data: function (d) {
                @if(request()->has('force'))
					d.enable_deleted = ($('#is_deleted_record').is(":checked")) ? 1 : 0;
                @endif
                d._token = '{{ csrf_token() }}'
            }
        }
    });

    $('.filter').change(function() {
        datatable.fnDraw();
    });
	$('#is_deleted_record').change(function() {
		datatable.fnDraw();
    });

    $(document).on('click', '.del-log', function (e) {
        var id = $(this).attr('data-id');
        swal({
            title: 'Are you sure?',
            text: "@lang('common.js_msg.confirm_for_delete_data')",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#0CC27E',
            cancelButtonColor: '#FF586B',
            confirmButtonText: 'Yes',
            cancelButtonText: "No, cancel"
        }).then(function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    type: "DELETE",
                    url: "{{ route('admin.'.$context) }}" + "/" + id,
                    headers: {
                        "X-CSRF-TOKEN": "{{ csrf_token() }}"
                    },
                    success: function (data) {
                        datatable.fnDraw();
                        swal({
                            type: 'success',
                            title: "Success",
                            text: "@lang('common.js_msg.action_success')",
                            timer: 2000,
                            showConfirmButton: false
                        });
                    },
                    error: function (xhr, status, error) {
                        swal({
                            type: 'error',
                            title: "Error",
                            text: "@lang('common.js_msg.action_not_procede')",
                            timer: 2000,
                            showConfirmButton: false
                        });
                    }
                });
            }
        }).catch(swal.noop);
    });


</script>


@endpush
