@extends('layouts.admin.index')

@section('title',trans('Image'))

@section('content')

<div class="main-content">
    <div class="content-wrapper">
        @include('inc.messages')
        <section id="basic-form-layouts">
            <div class="row">
                <div class="col-sm-12">
                    <a href="{{route('admin.image.create')}}" class="btn btn-primary" style="float: right;">Add New Image </a>
                     <div class="content-header"> Images </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table id="example1" class="table table-striped dataTable">
                                                <thead>
                                                    <tr>
                                                        <th>Image</th>
                                                        <th>Type </th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                        @if(count($images) > 0)
                                                            @foreach($images as $image)
                                                            <tr>
                                                                <td>  <a href="{{ $image->image_url }}" target="_blank"><img src="{{ $image->thumb_image_url }}" height="55px" width="55px"/></a></td>
                                                               
                                                                <td>
                                                                    <a class="btn btn-primary btn-xs btnEdit clickable" href="{{route('admin.image.show', $image->id)}}"><i class="fa fa-eye"></i></a>
                                                                    <form id="delete-form-{{$image->id}}" method="post" action="{{route('admin.image.destroy', $image->id)}}" style="display:none;" >
                                                                        {{ csrf_field() }}
                                                                        {{ method_field('DELETE') }}
                                                                    </form>
                                                                    {{-- <a class="btn btn-danger btn-xs btnRemove clickable" href="#">Delete</a> --}}
                                                                    <a href="" onclick="
                                                                    if(confirm('Are you delete this?')) {
                                                                        event.preventDefault();
                                                                        document.getElementById('delete-form-{{$image->id}}').submit();
                                                                        }
                                                                        else
                                                                        {
                                                                        event.preventDefault();
                                                                        }
                                                                        "  class="btn btn-danger btn-xs btnRemove clickable"><i class='fa fa-trash' aria-hidden='true'></i></a>
                                                                </td>
                                                            </tr>
                                                            @endforeach
                                                        @else
                                                            <p>No images found</p>
                                                        @endif
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>


@endsection
