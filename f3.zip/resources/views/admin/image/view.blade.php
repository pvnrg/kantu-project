@extends('layouts.admin.index')

@section('title',trans('View Image'))

@section('content')

<div class="main-content">
    <div class="content-wrapper">
        @include('inc.messages')
        <section id="basic-form-layouts">
            <div class="row">
                <div class="col-sm-12">
                     <div class="content-header"> Image </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <a href="{{route('admin.image')}}" class="btn btn-primary">Back </a>
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <tbody>
                                                    <tr>
                                                        <th>Image </th>

                                                        <td>  <a href="{{ $image->image_url }}" target="_blank"> <img src="{{ $image->image_url }}" height="55px" width="55px"/></a></td>

                                                    </tr>
                                                   
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>


@endsection
