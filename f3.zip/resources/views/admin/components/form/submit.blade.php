
<div class="form-group">
     
    {!! Form::submit($name, array_merge(['id'=>$name] , $attributes )) !!}
    
</div>