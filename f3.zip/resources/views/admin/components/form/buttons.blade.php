<div class="form-group">

    {!! Form::submit(isset($submitButtonText) ? $submitButtonText : trans('common.label.create'), array_merge(['id'=>'create', 'class'=>'btn btn-primary create'] , $attributes )) !!}
    {!! Form::submit( isset($submitButtonText) ? trans('common.label.updateandclose') : trans('common.label.createandclose'), array_merge(['id'=>'createandclose', 'class'=>'btn btn-dark createandclose'] , $attributes )) !!}
    {!! Form::submit( isset($submitButtonText) ? trans('common.label.updateandnew') : trans('common.label.createandnew'), array_merge(['id'=>'createandnew', 'class'=>'btn btn-dark createandnew'] , $attributes )) !!}
    @if(!isset($submitButtonText))
    {{ Form::reset(isset($clearButtonText) ? $clearButtonText : trans('common.label.clear_form'), array_merge(['id'=>'clear', 'class'=>'btn btn-secondary', "onClick" => "CKEDITOR.instances.detail.setData( '', function() { this.updateElement(); } ) " ] , $attributes )) }}
    @endif
</div>
