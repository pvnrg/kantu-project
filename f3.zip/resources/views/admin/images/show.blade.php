
@extends('admin.system.show')
@section('table')


<table class="table table-striped">
    <tbody>


        <tr>
            <th>@lang('common.image')</th>
            <td><img src="{{ $item->image_url }}" title="image"/></td>
        </tr>


    </tbody>
</table>
@endsection
