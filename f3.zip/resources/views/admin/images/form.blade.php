<div class="row ">
    <div class="col-md-6">
            {{ Form::cbImage("image", false , @$item, $context ) }}

            {{ isset($submitButtonText) ?  Form::cbButtons($submitButtonText) :  Form::cbButtons()    }}
    </div>
</div>
