@extends('layouts.admin.index')

@section('title',trans('View User'))

@section('content')

<div class="main-content">
    <div class="content-wrapper">
        @include('inc.messages')
        <section id="basic-form-layouts">
            <div class="row">
                <div class="col-sm-12">                    
                     <div class="content-header"> User </div> 
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <a href="{{route('admin.users')}}" class="btn btn-primary">Back </a>
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <tbody>
                                                    <tr>
                                                        <th>Name </th> <td>{{$user->name}}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>First Name</th> <td>{{$user->first_name}}</td>
                                                    </tr>
                                                    <tr>
                                                        <th>Last Name </th> <td>{{$user->last_name}}</td>  
                                                    </tr>
                                                    <tr>
                                                        <th>Email </th> <td>{{$user->email}}</td>  
                                                    </tr>
                                                    <tr>
                                                        <th>Badge Status </th> <td>{{$user->badge_status}}</td>  
                                                    </tr>
                                                    <tr>
                                                        <th>Gender </th> <td>{{$user->gender}}</td>  
                                                    </tr>
                                                    <tr>
                                                        <th>Age </th> <td>{{$user->age}}</td>  
                                                    </tr>
                                                    <tr>
                                                        <th>Date Of Birth </th> <td>{{$user->dob}}</td>  
                                                    </tr>
                                                    <tr>
                                                        <th>Phone No </th> <td>{{$user->phone}}</td>  
                                                    </tr>
                                                    <tr>
                                                        <th>Batch Id </th> <td>{{$user->batch_id}}</td>  
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>


@endsection