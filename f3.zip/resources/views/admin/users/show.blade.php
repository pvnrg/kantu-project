@extends('layouts.admin.index')

@section('title',trans('User'))

@section('content')

<div class="main-content">
    <div class="content-wrapper">
        @include('inc.messages')
        <section id="basic-form-layouts">
            <div class="row">
                <div class="col-sm-12">
                     <div class="content-header"> Users </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table id="example1" class="table table-striped dataTable">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Email </th>
                                                        <th>Phone </th>
                                                        <th>Age </th>
                                                        <th>Badge Status </th>
                                                        <th>status </th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                        @if(count($users) > 0)
                                                            @foreach($users as $user)
                                                            <tr>
                                                                <td>{{$user->name}}</td>
                                                                <td>{{$user->email}}</td>
                                                                <td>{{$user->phone}}</td>
                                                                <td>{{$user->age}}</td>
                                                                <td>{{$user->badge_status}}</td>
                                                                <td>
                                                                    @if($user->status == 'active')
                                                                        <input type='checkbox' class='status status-user status-change' data-group-cls='btn-group-sm' checked data-table='user' data-status="{{$user->status}}" value="{{$user->id}}" data-id="{{$user->id}}">
                                                                    @else
                                                                        <input type='checkbox' class='status status-user status-change' data-group-cls='btn-group-sm' data-table='user' data-status="{{$user->status}}" value="{{$user->id}}" data-id="{{$user->id}}" >
                                                                    @endif
                                                                </td>
                                                                <td>
                                                                    <a class="btn btn-primary btn-xs btnEdit clickable" href="{{route('admin.users.show', $user->id)}}"><i class="fa fa-eye"></i></a>
                                                                    <form id="delete-form-{{$user->id}}" method="post" action="{{route('admin.users.destroy', $user->id)}}" style="display:none;" >
                                                                        {{ csrf_field() }}
                                                                        {{ method_field('DELETE') }}
                                                                    </form>
                                                                    {{-- <a class="btn btn-danger btn-xs btnRemove clickable" href="#">Delete</a> --}}
                                                                    <a href="" onclick="
                                                                    if(confirm('Are you delete this?')) {
                                                                        event.preventDefault();
                                                                        document.getElementById('delete-form-{{$user->id}}').submit();
                                                                        }
                                                                        else
                                                                        {
                                                                        event.preventDefault();
                                                                        }
                                                                        "  class="btn btn-danger btn-xs btnRemove clickable"><i class='fa fa-trash' aria-hidden='true'></i></a>
                                                                </td>
                                                            </tr>
                                                            @endforeach
                                                        @else
                                                            <p>No users found</p>
                                                        @endif
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>


@endsection
