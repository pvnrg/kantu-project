
@extends('layouts.admin.index')

@section('title',trans('common.page.title.index.'.$context))

@section('content')

@push('css')
<style>
    .event-img{
        width: 100px;
        height: 100px;
        border-radius: 50%;
    }
</style>
@endpush

<div class="main-content">
    <div class="content-wrapper">
        <section id="basic-form-layouts">
            <div class="row">
                <div class="col-sm-12">
                    <div class="content-header"> @lang('common.page.title.index.'.$context) </div>
                </div>
            </div>


            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Event Safety Details</strong>
                        </div>
                        <div class="card-body">
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <tbody>
                                                    <tr>
                                                        <th>Event</th>
                                                        <th>Name</th>
                                                        <th>Safety Images Selected On </th>
                                                        <th>Safe Image</th>
                                                        <th>Unsafe Image</th>
                                                        <th>Marked Complete</th>
                                                        <th>Completion Image</th>
                                                        <th>Marked Completed On</th>
                                                        <th>Status</th>
                                                    </tr>
                                                    @foreach($events as $item)
                                                    @foreach($item->events_images as $e_image)

                                                    <tr>
                                                        <td>{{ $item->title }}</td>
                                                        <td>{{ $e_image->user->name }}</td>
                                                        <td>{{ $e_image->created_at->format('m-d-Y H:i A') }}</td>
                                                        <td>@if($e_image->safe_image)<img src="{{ $e_image->safe_image->thumb_image_url }}" class="event-img" /> @endif</td>
                                                        <td>@if($e_image->unsafe_image)<img src="{{ $e_image->unsafe_image->thumb_image_url }}" class="event-img" />@endif</td>
                                                        <td>{{ $e_image->status }}</td>
                                                        <td>@if($e_image->choosen_image)<img src="{{ $e_image->choosen_image->thumb_image_url }}" class="event-img" />@endif</td>
                                                        <td>{{ $e_image->choosen_image_on ? \Carbon\Carbon::parse($e_image->choosen_image_on)->format('m-d-Y') : '' }}</td>
                                                        <td>
                                                            @if($e_image->status != 'completed' )
                                                                <span class="btn btn-info">Pending</span>
                                                            @elseif($e_image->user_status == 'safe')
                                                                <span class="btn btn-success">Safe</span>
                                                            @elseif($e_image->user_status == 'unsafe')
                                                                <span class="btn btn-danger">Danger</span>
                                                            @else
                                                            @endif
                                                        </td>
                                                    </tr>

                                                    @endforeach
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

@endsection
