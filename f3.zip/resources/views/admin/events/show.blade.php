
@extends('layouts.admin.index')

@section('title',trans('common.page.title.view.'.$context))

@section('content')

@push('css')
<style>
    .event-img{
        width: 100px;
        height: 100px;
        border-radius: 50%;
    }
</style>
@endpush

<div class="main-content">
    <div class="content-wrapper">
        <section id="basic-form-layouts">
            <div class="row">
                <div class="col-sm-12">
                    <div class="content-header"> @lang('common.page.title.view.'.$context) @if($item->title) ({{$item->title}}) @endif</div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <a href="{{ route('admin.'.$context) }}">
                                <button type="button" class="btn btn-raised btn-success btn-min-width mr-1 mb-1">
                                    <i class="fa fa-angle-left"></i> @lang($context.'.title')
                                </button>
                            </a>
                            {!! Form::open([
                            'method'=>'DELETE',
                            'url' => ['admin/'.$context, $item->id],
                            'style' => 'display:inline'
                            ]) !!}

                            {!! Form::button('<i class="fa fa-trash" aria-hidden="true"></i> '.trans('common.delete'), array(
                            'type' => 'submit',
                            'class' => 'btn btn-raised btn-danger btn-min-width mr-1 mb-1',
                            'title' => trans('common.delete'),
                            'onclick'=>"return confirm('".trans('common.js_msg.confirm_for_delete_data')."')"
                            ))!!}
                            {!! Form::close() !!}
                        </div>
                        <div class="card-body">
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <tbody>
                                                    <tr>
                                                        <th>@lang('common.title')</th>
                                                        <td>{{ $item->title }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.description')</th>
                                                        <td>{{ $item->description }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.start_time')</th>
                                                        <td>{{ $item->start_time }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.end_time')</th>
                                                        <td>{{ $item->end_time }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.start_date')</th>
                                                        <td>{{ $item->start_date }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.end_date')</th>
                                                        <td>{{ $item->end_date }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.address')</th>
                                                        <td>{{ $item->address }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.city')</th>
                                                        <td>{{ $item->city }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.state')</th>
                                                        <td>{{ $item->state }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.status')</th>
                                                        <td>{{ $item->status }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.created_by')</th>
                                                        <td>{{ $item->created_by_name }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @if($item->events_users)
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <strong>Event User Details</strong>
                        </div>
                        <div class="card-body">
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <tbody>

                                                    <tr>
                                                        <th>@lang('common.created_by')</th>
                                                        <td>{{ $item->created_by_name }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.user_name')</th>
                                                        <td>{{ $item->events_users->connected_user ? $item->events_users->connected_user->name : '' }}</td>
                                                    </tr>

                                                    <tr>
                                                        <th>@lang('common.approval_status')</th>
                                                        <td>{{ $item->events_users->approval_status }}</td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endif
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong>Event Safety Details</strong>
                        </div>
                        <div class="card-body">
                            <div class="px-3">
                                <div class="box-content ">
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <tbody>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Safety Images Selected On </th>
                                                        <th>Safe Image</th>
                                                        <th>Unsafe Image</th>
                                                        <th>Marked Complete</th>
                                                        <th>Completion Image</th>
                                                        <th>Marked Completed On</th>
                                                        <th>Status</th>
                                                    </tr>

                                                    @foreach($item->events_images as $e_image)
                                                    <tr>
                                                        <td>{{ $e_image->user ? $e_image->user->name : ''  }}</td>
                                                        <td>{{ $e_image->created_at->format('m-d-Y H:i A') }}</td>
                                                        <td>@if($e_image->safe_image)<img src="{{ $e_image->safe_image->thumb_image_url }}" class="event-img" /> @endif</td>
                                                        <td>@if($e_image->unsafe_image)<img src="{{ $e_image->unsafe_image->thumb_image_url }}" class="event-img" />@endif</td>
                                                        <td>{{ $e_image->status }}</td>
                                                        <td>@if($e_image->choosen_image)<img src="{{ $e_image->choosen_image->thumb_image_url }}" class="event-img" />@endif</td>
                                                        <td>{{ $e_image->choosen_image_on ? \Carbon\Carbon::parse($e_image->choosen_image_on)->format('m-d-Y') : '' }}</td>
                                                        <td>
                                                            @if($e_image->status != 'completed' )
                                                                <span class="btn btn-info">Pending</span>
                                                            @elseif($e_image->user_status == 'safe')
                                                                <span class="btn btn-success">Safe</span>
                                                            @elseif($e_image->user_status == 'unsafe')
                                                                <span class="btn btn-danger">Danger</span>
                                                            @elseif($e_image->user_status == 'not-matched')
                                                                <span class="btn btn-warning">Not Matched</span>
                                                            @else
                                                            @endif
                                                        </td>
                                                    </tr>
                                                    @endforeach



                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

@endsection
