
@extends('admin.system.show')
@section('table')


<table class="table table-striped">
    <tbody>

        <tr>
            <th>@lang('common.from_user_name')</th>
            <td>{{ $item->sender->name }}</td>
        </tr>

        <tr>
            <th>@lang('common.to_user_name')</th>
            <td>{{ $item->receiver->name }}</td>
        </tr>

        <tr>
            <th>@lang('common.status')</th>
            <td>{{ $item->status_name }}</td>
        </tr>

        <tr>
            <th>@lang('common.connection_request_sent_on')</th>
            <td>{{ $item->created_at->format('m-d-Y H:i A') }}</td>
        </tr>

        <tr>
            <th>@lang('common.connection_request_accept_on')</th>
            <td>@if($item->status == App\Connection::STATUS_CONNECTED ){{ $item->updated_at->format('m-d-Y H:i A') }}@else  - @endif</td>
        </tr>

    </tbody>
</table>
@endsection
