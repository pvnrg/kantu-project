<div class="row ">
    <div class="col-md-6">

            {{ Form::cbText('first_name' ) }}

            {{ Form::cbText('last_name') }}

            {{ Form::cbEmail('email', null ,['disabled'=> isset($item) && $item->email ? true : false , 'class'=>'form-control'])  }}

            {{-- {{ Form::cbPassword('password') }} --}}

            {{ Form::cbText('phone') }}

            <input type="hidden" name="rolls" value="Employee">

            {{ isset($submitButtonText) ?  Form::cbButtons($submitButtonText) :  Form::cbButtons()    }}
    </div>
</div>
