@extends('layouts.admin.index')

@section('body_class',' pace-done')

@section('title',trans($context.'.title'))

@section('content')

<div class="main-content">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-sm-12">
                <div class="content-header"> @lang($context.'.title') @csrf </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="col-md-6">
                            <a href="{{ url('/admin/employee/create') }}" title="Create">
                                <button class="btn btn-sm btn-space btn-success ">Add Employee</button>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <form method="GET" action="{{ \Request::url() }}"  id="filter_form">
                                {!! Form::hidden('from_date',$from_date, ['class' => 'form-control','id'=>'from_date']) !!}
                                {!! Form::hidden('to_date',$to_date, ['class' => 'form-control','id'=>'to_date']) !!}
                                    <div style="width: 100%">
                                        <div id="reportrange"  style="background: transparent; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%;height: 32px;">
                                            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                            <span></span> <b class="caret"></b>
                                        </div>
                                    </div>
                            </form>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="px-3">
                            <div class="box-content ">
                                <div class="row">
                                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                                        <aside class="profile-nav alt">
                                            <section class="card">
                                                <div class="card-body">
                                                    <div class="stat-widget-one employee">
                                                        <div class="stat-icon dib"><i class="fa fa-usd text-success border-success"></i></div>
                                                        <div class="stat-content dib">
                                                            <div class="stat-text">Amount Paid / Total User</div>
                                                            <div class="stat-digit">${{$unit_sum}} / {{$for_user_sum}} <span class="font-size-12 duration_filter" > </span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </aside>
                                    </div>
                                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                                        <aside class="profile-nav alt">
                                            <section class="card">
                                                <div class="card-body">
                                                    <div class="stat-widget-one employee">
                                                        <div class="stat-icon dib"><i class="fa fa-usd text-success border-success"></i></div>
                                                        <div class="stat-content dib">
                                                            <div class="stat-text">Payable Amount / Total User</div>
                                                            <div class="stat-digit">${{$approve_count*$peruser}} / {{$approve_count}}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </aside>
                                    </div>
                                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                                        <aside class="profile-nav alt">
                                            <section class="card">
                                                <div class="card-body">
                                                    <div class="stat-widget-one employee">
                                                        <div class="stat-icon dib"><i class="fa fa-user text-success border-success"></i></div>
                                                        <div class="stat-content dib">
                                                            <div class="stat-text">User Processed</div>
                                                            <div class="stat-digit">{{$total_approved_child}} <span class="font-size-12 duration_filter" > </span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section>
                                        </aside>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="px-3">
                            <div class="box-content ">
                                <div class="row">
                                    @foreach($users as $user)
                                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                                        <aside class="profile-nav alt">
                                            <section class="card">
                                                <div class="card-header user-header alt bg-dark">
                                                    <div class="media">
                                                        <div class="media-body">
                                                            <h4 class="text-light display-6">{{ $user->name }}</h4>
                                                            <p>#{{ $user->id }} {{ $user->email }}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <ul class="list-group list-group-flush">
                                                    <li class="list-group-item">
                                                        @if($user->employee->approve_count_total >0 )
                                                            <a title="User List Processed By Employee" href="{{ url('admin/employee/approvedBy/') }}/{{$user->id}}">
                                                                <i class="fa fa-bars"></i> Total User Processed
                                                                <span class="badge badge-success pull-right">{{$user->employee->approve_count_total}}</span>
                                                            </a>
                                                        @else
                                                            <a href="#"> <i class="fa fa-bars"></i> Total User Processed
                                                                <span class="badge badge-primary pull-right">{{$user->employee->approve_count_total}}</span>
                                                            </a>
                                                        @endif

                                                    </li>
                                                    <li class="list-group-item">
                                                        <a href="#"> <i class="fa fa-tasks"></i> User Processed(Not Paid) <span class="badge badge-danger pull-right">{{ $user->employee->approved_count }}</span></a>
                                                    </li>
                                                    @if($to_date && $from_date)
                                                    <li class="list-group-item">
                                                        <a href="#"> <i class="fa fa-calendar"></i>  Processed <br/>({{$from_date->format('M d,Y') }} - {{$to_date->format('M d,Y')}})
                                                        <span class="badge badge-warning  pull-right">{{ $user->badgeapprove->count() }}</span>
                                                        </a>
                                                    </li>

                                                    @endif
                                                    <li class="list-group-item">
                                                        @if($user->employee->approved_count > 0)
                                                        <a href="{{url('admin/employee/payment', $user->id)}}" title="Click to pay employee" class="btn btn-success btn-sm " >
                                                            <i class="fa fa-money" aria-hidden="true"></i>
                                                        </a>&nbsp;
                                                        @else
                                                        <a href="javacript:void(0)" title="No enough credit for payment" class="btn btn-success btn-sm " >
                                                            <i class="fa fa-money" aria-hidden="true"></i>
                                                        </a>&nbsp;
                                                        @endif
                                                        <a href="{{ url('admin/employee') }}/{{ $user->id }}">
                                                        <button class="btn btn-warning btn-sm" title="View">
                                                            <i class="fa fa-eye"></i></button>
                                                        </a>&nbsp;
                                                        <a href="{{ url('admin/employee') }}/{{ $user->id }}/edit" class="btn btn-info btn-sm">
                                                            <i class="fa fa-pencil"></i>
                                                        </a>&nbsp;
                                                        <a href="javascript:void(0);" data-url={{url('admin/employee')}} data-msg='user' class="btn btn-danger btn-sm del-item" data-toggle="modal" data-target="#danger" data-id="{{ $user->id }}"
                                                        data-url="#" data-msg="user" data-backdrop="static" data-keyboard="false">
                                                            <i class="fa fa-trash" aria-hidden="true"></i>
                                                        </a>&nbsp;

                                                    </li>
                                                </ul>
                                            </section>
                                        </aside>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection



@section('js')
@parent
<script src="{{ asset('app-assets/vendors/js/sweetalert2.min.js') }}" type="text/javascript"></script>
<script src="https://secure.mysafetynet.info/backend/assets/js/moment.min.js"></script>
<script src="https://secure.mysafetynet.info/backend/assets/js/daterangepicker.js"></script>
@endsection


@section('css')
@parent
<link rel="stylesheet" type="text/css" href="{{ asset('app-assets/vendors/css/sweetalert2.min.css')}}">
<link rel="stylesheet" href="https://secure.mysafetynet.info/backend/assets/css/themify-icons.css">
@endsection


@push('scripts')
<script>
var url ="{{ url('/admin/employee/datatable') }}";
        var edit_url = "{{ url('/admin/employee') }}";
        var auth_check = "{{ Auth::check() }}";

        /*************************daterange selection*****************/

	var range_start = "";
    var range_end = "";

    var start = moment.utc('2017-01-01','YYYY-MM-DD');
    var end = moment();

	if($('#from_date').val() && $('#from_date').val() !="" && $('#to_date').val() && $('#to_date').val() !="" ){
		start = moment.utc($('#from_date').val(),'YYYY-MM-DD');
		end = moment.utc($('#to_date').val(),'YYYY-MM-DD');
	}
	$('.duration_filter').html("("+start.format('MMM D, YYYY') + ' - ' + end.format('MMM D, YYYY')+")");

    function cb(start, end) {
        $('#reportrange span').html(start.format('MMM D, YYYY') + ' - ' + end.format('MMM D, YYYY'));
        if(range_start==""){
            range_start = start.format('YYYY-MM-DD');
            range_end = end.format('YYYY-MM-DD');
        }else{
            range_start = start.format('YYYY-MM-DD');
            range_end = end.format('YYYY-MM-DD');

			$('#to_date').val(range_end);
			$('#from_date').val(range_start);

			$('#filter_form').submit();



            //datatable.fnDraw();
        }
		$('#to_date').val(range_end);
		$('#from_date').val(range_start);

    }

    $('#reportrange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
            "All":[moment.utc('2017-01-01','YYYY-MM-DD'),moment()],
            "Today": [moment(), moment()],
            "This Week": [moment().startOf('week'), moment().endOf('week')],
            "Last Week": [moment().subtract(1, 'week').startOf('week'), moment().subtract(1, 'week').endOf('week')],
            "This Month": [moment().startOf('month'), moment().endOf('month')],
            "Last Month": [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]

        }
    }, cb);

       cb(start, end);



    $(document).on('click', '.del-item', function (e) {
        var id = $(this).attr('data-id');
        swal({
            title: 'Are you sure?',
            text: "@lang('common.js_msg.confirm_for_delete_data')",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#0CC27E',
            cancelButtonColor: '#FF586B',
            confirmButtonText: 'Yes',
            cancelButtonText: "No, cancel"
        }).then(function (isConfirm) {
            if (isConfirm) {
                $.ajax({
                    type: "DELETE",
                    url: "{{ route('admin.'.$context) }}" + "/" + id,
                    headers: {
                        "X-CSRF-TOKEN": "{{ csrf_token() }}"
                    },
                    success: function (data) {
                        window.location = "{{ route('admin.'.$context) }}"
                        swal({
                            type: 'success',
                            title: "Success",
                            text: "@lang('common.js_msg.action_success')",
                            timer: 2000,
                            showConfirmButton: false
                        });
                    },
                    error: function (xhr, status, error) {
                        swal({
                            type: 'error',
                            title: "Error",
                            text: "@lang('common.js_msg.action_not_procede')",
                            timer: 2000,
                            showConfirmButton: false
                        });
                    }
                });
            }
        }).catch(swal.noop);
    });


</script>


@endpush
