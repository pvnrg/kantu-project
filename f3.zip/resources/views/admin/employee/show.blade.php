@extends('layouts.admin.index')

@section('body_class',' pace-done')

@section('title',trans($context.'.title'))

@section('content')
<div class="main-content">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12">
                <div class="card-body">
                    <div class="px-3">
                        <div class="box-content ">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header"><strong>Employee Detail</strong>
                                            <a href="{{ url('/admin/employee') }}" title="Parent List">
                                                <button class="btn btn-sm btn-space btn-warning pull-right">Back To Employee</button>
                                            </a>
                                        </div>
                                        <div class="card-body card-block">
                                            <table class="table table-bordered">
                                                <tbody>
                                                    <tr>
                                                        <td>First Name</td>
                                                        <td> {{ $item->first_name }} </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Last Name</td>
                                                        <td> {{ $item->last_name }} </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Email</td>
                                                        <td> {{ $item->email }} </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Phone No</td>
                                                        <td> {{ $item->phone }} </td>
                                                    </tr>

                                                    <tr>
                                                        <td>Total Email Send (to set Password)</td>
                                                        <td> {{ $item->try_count }} </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Number of User's Profile Activation (All)
                                                        @if($item->approve_count_total >0 )
                                                            <a href="{{ url('admin/employee/approvedBy/') }}/{{$item->user_id}}" class="pull-right" title="Child List Approve By Employee">
                                                                view
                                                            </a>
                                                            @endif
                                                        </td>
                                                        <td>
                                                            {{ $item->approve_count_total }}

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Number of User's Profile Activation (Not Paid)
                                                        </td>
                                                        <td>
                                                            {{ $item->approved_count }}

                                                            @if($item->approved_count >0 )
                                                            <a href="{{url('admin/employee/payment', $item->id)}}" title="Click to pay employee">
                                                                <button class="btn btn-sm btn-space btn-info pull-right">Pay Now !</button>
                                                            </a>
                                                            @endif

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Status</td>
                                                        <td>
                                                        @if($item->status)
                                                        Active
                                                        @else
                                                        Inactive
                                                        @endif
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Is Setup (Password)</td>
                                                        <td> {{ $item->is_setup }}
                                                            @if($item->is_setup == "no")
                                                            <a href="{{url('admin/employee/activation-resend', $item->user_id)}}" title="Resend Password and activation email">
                                                                <button class="btn btn-sm btn-space btn-info pull-right">Resend Email</button>
                                                            </a>
                                                            @endif
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header"><div class="col-sm-12"><strong>User's Profile And Badge Approve</strong></div>

                                        </div>
                                        <div class="card-body card-block">
                                            <table class="table table-bordered">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <form method="GET" action="{{ \Request::url() }}" >
                                                            {!! Form::hidden('user_id',$item->id, ['class' => 'form-control','id'=>'user_id']) !!}
                                                            {!! Form::hidden('from_date',$from_date, ['class' => 'form-control','id'=>'from_date']) !!}
                                                            {!! Form::hidden('to_date',$to_date, ['class' => 'form-control','id'=>'to_date']) !!}
                                                                <div style="width: 100%">
                                                                    <div id="reportrange"  style="background: transparent; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%;height: 32px;">
                                                                        <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                                                        <span></span> <b class="caret"></b>
                                                                    </div>

                                                                </div>

                                                                <button type="submit"  class="btn btn-sm btn-space btn-info pull-right">View Approve Count</button>
                                                                </form>
                                                        </td>
                                                    </tr>
                                                     <tr>
                                                        <td>
                                                            Approved Count : {{ $badgeapprove->count() }}

                                                            @if($badgeapprove->count() >0 )

                                                            @php( $q='' )
                                                            @if($from_date && $to_date)
                                                                @php( $q="?from_date=".$from_date."&to_date=".$to_date )
                                                            @endif
                                                            <a href="{{ url('admin/employee/approvedBy/') }}/{{$item->user_id}}{{ $q }}" class="pull-right" title="User List Approve By Employee">
                                                                view
                                                            </a>
                                                            @endif

                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header"><strong>Employee Payouts</strong>

                </div>
                <div class="card-body card-block">
                    <table id="datatable" class="table table-striped table-hover table-fw-widget">
                                <thead>
                                    <tr>
                                        <th>#ID</th>
                                        <th>Amount</th>
                                        <th>For Child</th>
                                        <th>Note </th>
                                        <th>Created</th>
                                        <th>Created By</th>
                                    </tr>
                                </thead>
                            </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('js')
@parent
<script src="{{ asset('app-assets/vendors/js/datatable/datatables.min.js') }}" type="text/javascript"></script>
<script src="https://secure.mysafetynet.info/backend/assets/js/moment.min.js"></script>
<script src="https://secure.mysafetynet.info/backend/assets/js/daterangepicker.js"></script>
@endsection


@push('scripts')

    <script>
        var url ="{{ url('/admin/employee-payment/datatable/'.$item->id) }}";
        var auth_check = "{{ Auth::check() }}";

        datatable = $('#datatable').DataTable({
            dom:
            "<'row be-datatable-header'<'col-sm-6'l><'col-sm-6'f>>" +
            "<'row be-datatable-body'<'col-sm-12'tr>>" +
            "<'row be-datatable-footer'<'col-sm-5'i><'col-sm-7'p>>",
            processing: true,
            serverSide: true,
            "caseInsensitive": false,
            "order": [[0,"DESC"]],
            ajax: {
                url:url,
                type:"get",
            },
            "drawCallback": function( settings ) {
               // statusChange();
            },
            columns: [
                { data: 'id',name : 'id',"searchable": false, "orderable": true},
                { data: 'unit',name : 'unit',"searchable": true, "orderable": true},
                { data: 'for_user',name : 'for_user',"searchable": true, "orderable": true},
                { data: 'comment',name : 'comment',"searchable": true, "orderable": true},
                { data: 'payment_created',name : 'payment_created',"searchable": true, "orderable": true},
                {
                    "data": null,
                    "name": 'created_by',
                    "searchable": false,
                    "render": function (o) {
                        var creatorname = "";
                        if(o.creator){
                            creatorname = o.creator.full_name;
                        }
                        return creatorname;
                    }
                },

            ]
        });

          /*************************daterange selection*****************/

	var range_start = "";
    var range_end = "";

    var start = moment.utc('2017-01-01','YYYY-MM-DD');
    var end = moment();

	if($('#from_date').val() && $('#from_date').val() !="" && $('#to_date').val() && $('#to_date').val() !="" ){
		start = moment.utc($('#from_date').val(),'YYYY-MM-DD');
		end = moment.utc($('#to_date').val(),'YYYY-MM-DD');
	}
    console.log(start);
    function cb(start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        if(range_start==""){
            range_start = start.format('YYYY-MM-DD');
            range_end = end.format('YYYY-MM-DD');
        }else{
            range_start = start.format('YYYY-MM-DD');
            range_end = end.format('YYYY-MM-DD');

            //datatable.fnDraw();
        }
		$('#to_date').val(range_end);
		$('#from_date').val(range_start);

    }

    $('#reportrange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
            "All":[moment.utc('2017-01-01','YYYY-MM-DD'),moment()],
            "Today": [moment(), moment()],
            "This Week": [moment().startOf('week'), moment().endOf('week')],
            "Last Week": [moment().subtract(1, 'week').startOf('week'), moment().subtract(1, 'week').endOf('week')],
            "This Month": [moment().startOf('month'), moment().endOf('month')],
            "Last Month": [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]

        }
    }, cb);

     cb(start, end);


	$('.filter').change(function() {
        datatable.fnDraw();
    });
</script>
@endpush
