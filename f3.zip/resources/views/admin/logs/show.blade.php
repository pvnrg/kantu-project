
@extends('admin.system.show')
@section('table')
    

<table class="table table-striped">
    <tbody>
      
               
        <tr>
            <th>@lang('common.log_type')</th>
            <td>{{ $item->log_type }}</td>
        </tr>
   
        <tr>
            <th>@lang('common.status_code')</th>
            <td>{{ $item->status_code }}</td>
        </tr>

        <tr>
            <th>@lang('common.line_no')</th>
            <td>{{ $item->line_no }}</td>
        </tr>

        <tr>
            <th>@lang('common.file_name')</th>
            <td>{{ $item->file_name }}</td>
        </tr>

        <tr>
            <th>@lang('common.total_count')</th>
            <td>{{ $item->total_count }}</td>
        </tr>

        <tr>
            <th>@lang('common.slug')</th>
            <td>{{ $item->slug }}</td>
        </tr>

        <tr>
            <th>@lang('common.created_at')</th>
            <td>{{ $item->created_at }}</td>
        </tr>
       
    </tbody>
</table>
@endsection
