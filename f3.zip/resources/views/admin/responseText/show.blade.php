
@extends('admin.system.show')
@section('table')
    

<table class="table table-striped">
    <tbody>
      
               
        <tr>
            <th>@lang('common.response_type')</th>
            <td>{{ $item->response_type }}</td>
        </tr>
   
        <tr>
            <th>@lang('common.slug')</th>
            <td>{{ $item->slug }}</td>
        </tr>

        <tr>
            <th>@lang('common.desc')</th>
            <td>{{ $item->desc }}</td>
        </tr>
       
    </tbody>
</table>
@endsection
