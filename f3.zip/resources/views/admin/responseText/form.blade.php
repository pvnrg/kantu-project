<div class="row ">
    <div class="col-md-6">

            {{ Form::cbSelect('response_type', config('admin.response_type')) }}

            {{ Form::cbSelect('slug', Lang::get('api.responce_msg')) }}

            {{ Form::cbTextarea('desc') }}

            {{ isset($submitButtonText) ?  Form::cbButtons($submitButtonText) :  Form::cbButtons()    }}
    </div>
</div>
