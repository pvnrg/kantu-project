<?php
 $user_id =	"";
 if(isset($user)){
     $user_id =	$user->id;
     //print_r($user); die;
 }
 ?>
{{-- {!! Form::open(['route' => 'admin.blog.store', 'method' => 'POST','enctype' => 'multipart/form-data']) !!} --}}
<div class="row ">
    <div class="col-md-6">	
        <div class="form-group {{ $errors->has('email') ? ' has-error' : ''}}">
            <label for="email" >
                <span class="field_compulsory">*</span>@lang($context.' email')
            </label>
            <div >
			{!! Form::text('email', $user_id != '' ? $user->email : '', ['class' => 'email','id'=>'email','style'=>'width:100%', 'disabled']) !!}			
				{!! $errors->first('title', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('password') ? ' has-error' : ''}}">
            <label for="password" >
                <span class="field_compulsory">*</span>@lang($context.' New password')
            </label>
            <div >
			{!! Form::text('password', '', ['class' => 'password','id'=>'password','style'=>'width:100%']) !!}			
				{!! $errors->first('title', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('confirm_password') ? ' has-error' : ''}}">
            <label for="confirm_password" >
                <span class="field_compulsory">*</span>@lang($context.' confirm password')
            </label>
            <div >
			{!! Form::text('confirm_password', '', ['class' => 'confirm_password','id'=>'confirm_password','style'=>'width:100%']) !!}			
				{!! $errors->first('title', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        <div class="form-group">
            {!! Form::submit(isset($submitButtonText) ? $submitButtonText : trans('Edit'), ['class' => 'btn btn-primary form_submit image_submit_btn']) !!}
            {{ Form::reset(trans('common.clear_form'), ['class' => 'btn btn-light']) }} 
        </div>     
    </div>
    {{-- <div class="col-md-6">
        <div class="form-group {{ $errors->has('short_desc') ? ' has-error' : ''}}">
            <label for="short_desc" >
                <span class="field_compulsory">*</span>@lang($context.' short Desc')
            </label>
            <div >
			{!! Form::text('short_desc', $user_id != '' ? $blog->short_desc : '', ['class' => 'short_desc','id'=>'short_desc','style'=>'width:100%']) !!}			
				{!! $errors->first('short_desc', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('type') ? ' has-error' : ''}}">
            <label for="type" >
                <span class="field_compulsory">*</span>@lang($context.' type')
            </label>
            <div >
			{!! Form::select('type', array('page' => 'Page', 'blog' => 'Blog'), $blog_id != '' ?  $blog->type : '') !!}			
				{!! $errors->first('type', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('status') ? ' has-error' : ''}}">
            <label for="status" >
                <span class="field_compulsory">*</span>@lang($context.' status')
            </label>
            <div >
			{!! Form::select('status', array('1' => 'Active', '0' => 'Inactive'), $blog_id != '' ?  $blog->status : '') !!}			
				{!! $errors->first('status', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
    </div> --}}
   
    
</div>

{{-- {{ form::close() }} --}}