<?php
 $user_id =	"";
 if(isset($user)){
     $user_id =	$user->id;
     //print_r($user); die;
 }
 ?>
{{-- {!! Form::open(['route' => 'admin.blog.store', 'method' => 'POST','enctype' => 'multipart/form-data']) !!} --}}
<div class="row ">
    <div class="col-md-6">
		<div class="form-group {{ $errors->has('first_name') ? ' has-error' : ''}}">
            <label for="first_name" >
                <span class="field_compulsory">*</span>@lang($context.' first name')
            </label>
            <div >
			{!! Form::text('first_name', $user_id != '' ? $user->first_name : '', ['class' => 'first_name','id'=>'first_name','style'=>'width:100%']) !!}
				{!! $errors->first('title', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('last_name') ? ' has-error' : ''}}">
            <label for="last_name" >
                <span class="field_compulsory">*</span>@lang($context.' last name')
            </label>
            <div >
			{!! Form::text('last_name', $user_id != '' ? $user->last_name : '', ['class' => 'last_name','id'=>'last_name','style'=>'width:100%']) !!}
				{!! $errors->first('title', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('email') ? ' has-error' : ''}}">
            <label for="email" >
                <span class="field_compulsory">*</span>@lang($context.' email')
            </label>
            <div >
			{!! Form::text('email', $user_id != '' ? $user->email : '', ['class' => 'email','id'=>'email','style'=>'width:100%', 'disabled' => true]) !!}
				{!! $errors->first('title', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        {{-- <div class="form-group {{ $errors->has('password') ? ' has-error' : ''}}">
            <label for="password" >
                <span class="field_compulsory">*</span>@lang($context.' password')
            </label>
            <div >
			{!! Form::text('password', $user_id != '' ? $user->password : '', ['class' => 'password','id'=>'password','style'=>'width:100%']) !!}
				{!! $errors->first('title', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div> --}}
        <div class="form-group {{ $errors->has('phone') ? ' has-error' : ''}}">
            <label for="phone" >
                <span class="field_compulsory">*</span>@lang($context.' phone')
            </label>
            <div >
			{!! Form::text('phone', $user_id != '' ? $user->phone : '', ['class' => 'phone','id'=>'phone','style'=>'width:100%']) !!}
				{!! $errors->first('title', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        <div class="form-group">
            {!! Form::submit(isset($submitButtonText) ? $submitButtonText : trans('Edit'), ['class' => 'btn btn-primary form_submit image_submit_btn']) !!}
            {{ Form::reset(trans('common.clear_form'), ['class' => 'btn btn-light']) }}
        </div>
    </div>
    {{-- <div class="col-md-6">
        <div class="form-group {{ $errors->has('short_desc') ? ' has-error' : ''}}">
            <label for="short_desc" >
                <span class="field_compulsory">*</span>@lang($context.' short Desc')
            </label>
            <div >
			{!! Form::text('short_desc', $user_id != '' ? $blog->short_desc : '', ['class' => 'short_desc','id'=>'short_desc','style'=>'width:100%']) !!}
				{!! $errors->first('short_desc', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('type') ? ' has-error' : ''}}">
            <label for="type" >
                <span class="field_compulsory">*</span>@lang($context.' type')
            </label>
            <div >
			{!! Form::select('type', array('page' => 'Page', 'blog' => 'Blog'), $blog_id != '' ?  $blog->type : '') !!}
				{!! $errors->first('type', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
        <div class="form-group {{ $errors->has('status') ? ' has-error' : ''}}">
            <label for="status" >
                <span class="field_compulsory">*</span>@lang($context.' status')
            </label>
            <div >
			{!! Form::select('status', array('1' => 'Active', '0' => 'Inactive'), $blog_id != '' ?  $blog->status : '') !!}
				{!! $errors->first('status', '<p class="help-block text-danger">:message</p>') !!}
            </div>
        </div>
    </div> --}}


</div>

{{-- {{ form::close() }} --}}
