@if(count($errors) > 0)
    @foreach($errors->all() as $error)
        <div class="alert alert-danger">
            {{$error}}
        </div>
    @endforeach
@endif

@if(session('success'))
    <div class="alert alert-success">
        {{session('success')}}
    </div>
@endif

@if(session('error'))
    <div class="alert alert-danger">
        {{session('error')}}
    </div>
@endif

@if(session('flash_success'))
    <div class="alert alert-success">
        {{session('flash_success')}}
    </div>
@endif

@if(session('flash_error'))
    <div class="alert alert-danger">
        {{session('flash_error')}}
    </div>
@endif
