  <!-- BEGIN : Footer-->
  <footer class="footer footer-static footer-light">
      <p class="clearfix text-muted text-sm-center px-2"><span>Copyright &copy; 2019 <a href="https://themeforest.net/user/pixinvent/portfolio?ref=pixinvent" id="pixinventLink" target="_blank" class="text-bold-800 primary darken-2">PIXINVENT </a>, All rights reserved. </span></p>
  </footer>
  <!-- End : Footer-->