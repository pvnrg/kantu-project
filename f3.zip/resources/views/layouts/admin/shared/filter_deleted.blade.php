@if(request()->has('force'))
	<div class="pull-right">
		<label for="is_deleted_record" class="font-medium-2 text-bold-600 ml-1 ">@lang('common.label.deleted_decord')</label>
		<input type="checkbox" id="is_deleted_record" class="switchery" />
	</div>
@endif