@extends('email.mailtemplate.cit')

@section('body')
    
        <h2 class="title">Hi  {{$contactUs->name}} </h2>
    

	 <p class="mb-">Thank you for contacting us.</p>
	 <p class="mb-">We have received your request to download eBook .</p>
	
	<p class="pr1">
		Please find the below attachment for eBook.
	</p>
	
	<br/>
	
	
	
@endsection



                
                                       
                                        
                                       
                                           
                            
                                     