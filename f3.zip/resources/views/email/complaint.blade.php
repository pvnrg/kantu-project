@extends('email.mailtemplate.cit')

@section('body')
    
        <h2 class="title">Hi  MySafetyNet Admin </h2>
    

	 <p class="mb-">You have one complaint or contact request,</p>
	
	 <p class="pr1">
	Request from :  {{$contactUs->name}} <br/>
	Email : @if($contactUs->email && $contactUs->email !="") {{$contactUs->email}}  @else N/A @endif  <br/>
	Phone : @if($contactUs->phone && $contactUs->phone !="") {{$contactUs->phone}}  @else N/A @endif <br/>
	Message : {{$contactUs->message }} <br/>
	</p>
	<br/>
	
	@if($contactUs->email && $contactUs->email != "")
        Reply to <a href="mailto:{{$contactUs->email}}?subject=Your complaint or contact request to MySafetyNet">{{$contactUs->email}}</a>
    @endif
	
@endsection



                
                                       
                                        
                                       
                                           
                            
                                     