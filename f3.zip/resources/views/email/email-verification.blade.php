@extends('email.mailtemplate.cit')

@section('body')
    @if(isset($user))
        <h2 class="title">Hi {{$user->full_name}}</h2>
    @endif

    <p>
        Welcome to MySafetyNet and MySafetyNet mobile App.  <br/><br/>
        
		Your one time password (otp) to verify  your email address is : <b> {{$user->otp}} </b>
		
        <br/>
		<br/>
		
        
		If you didn't request this then ignor this email or let us know.
		
		<br/>
    </p>
    
    <hr>
    
@endsection