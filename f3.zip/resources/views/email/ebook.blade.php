@extends('email.mailtemplate.cit')

@section('body')
    
        <h2 class="title">Hi  MySafetyNet Admin </h2>
    

	 <p class="mb-">You have received eBook download request.</p>
	
	 <p class="pr1">
	Request from :  {{$contactUs->name}} <br/>
	Email : @if($contactUs->email && $contactUs->email !="") {{$contactUs->email}}  @else N/A @endif  <br/>
	</p>
	<br/>
	
	@if($contactUs->email && $contactUs->email != "")
        Reply to <a href="mailto:{{$contactUs->email}}?subject=Download eBook-MySafetyNet">{{$contactUs->email}}</a>
    @endif
	
@endsection



                
                                       
                                        
                                       
                                           
                            
                                     